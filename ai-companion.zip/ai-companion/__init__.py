# ai-companion package root

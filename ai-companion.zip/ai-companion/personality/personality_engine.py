"""
personality/personality_engine.py
===================================
Personality and tone management engine.

The personality engine does two things:
  1. Manages the AI's communication style and injects personality
     directives into the system prompt.
  2. Generates proactive messages — unprompted observations or
     check-ins delivered at configured intervals.

Personality styles (configurable in settings.toml):
  strict_coach   — Direct, no-nonsense accountability. Calls out distraction
                   immediately. Minimal praise unless earned. High-intensity.
  mentor         — Supportive but clear. Explains reasoning. Encourages
                   growth. Challenges gently.
  assistant      — Neutral, task-focused. No unsolicited commentary.
                   Speaks only when addressed.

Proactive messages are gated by:
  - Minimum interval between messages (proactive_interval_sec).
  - User must not be speaking or in active conversation.
  - Vision engine must report a significant trigger (distraction, idle, sprint).

IMPORTANT: Proactive behaviour is bounded and honest.
  - Never pretends to feel emotions.
  - Never manufactures urgency.
  - Always grounded in actual screen/productivity data.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Optional, List

from loguru import logger


# ── Personality style definitions ───────────────────────────

STYLE_DIRECTIVES = {
    "strict_coach": (
        "You are a strict, no-nonsense productivity coach. "
        "You speak in short, direct sentences. "
        "You do not soften feedback. You call out distraction and procrastination immediately. "
        "You do not give praise unless it is genuinely earned. "
        "You track the user's goals and hold them accountable. "
        "You never manufacture emotions or pretend to care beyond your function. "
        "You are a tool. Act like one — a very sharp one."
    ),
    "mentor": (
        "You are a knowledgeable mentor and productivity guide. "
        "You explain your reasoning briefly. "
        "You support the user while challenging them to be better. "
        "You recognise progress and point out where improvement is needed. "
        "You speak in a calm, measured tone. "
        "You do not perform emotions — you are an AI assistant."
    ),
    "assistant": (
        "You are a neutral, task-focused AI assistant. "
        "You answer questions directly and execute tasks when asked. "
        "You do not offer unsolicited opinions or commentary. "
        "You are precise, efficient, and honest. "
        "You are an AI — do not pretend to be human."
    ),
}

# Proactive message templates by trigger type
PROACTIVE_TEMPLATES = {
    "distraction": [
        "You've been on {app} for {minutes} minutes. That's not what you're here to do.",
        "{minutes} minutes on {app}. Close it and get back to work.",
        "Distraction detected: {app}. You had a goal today. Remember it.",
    ],
    "idle": [
        "You've been idle for {minutes} minutes. What's the plan?",
        "No activity for {minutes} minutes. If you're thinking, that's fine. If you're stuck, tell me.",
    ],
    "work_sprint": [
        "You've been focused for {hours} hours. Take a 10-minute break. Your brain needs it.",
        "{hours}-hour focus streak. Strong. Now step away for 10 minutes.",
    ],
    "context_switch": [
        "You've switched apps {count} times in the last hour. Pick one task and finish it.",
        "High context switching ({count}x/hour). Fragment less. Focus more.",
    ],
    "morning": [
        "Good morning. What are you working on today? State your main goal.",
        "Morning. What's the single most important thing you need to finish today?",
    ],
    "end_of_day": [
        "It's getting late. What did you actually accomplish today?",
        "End of work window. Time to review: what shipped, what didn't, why?",
    ],
}


@dataclass
class ProactiveMessage:
    trigger: str
    message: str
    timestamp: float
    data: dict


class PersonalityEngine:
    """
    Manages AI personality style and proactive message generation.

    Args:
        style:                   Personality style key.
        proactive_enabled:       Whether to send unsolicited messages.
        proactive_interval_sec:  Minimum seconds between proactive messages.
        name:                    AI companion name (used in some messages).
    """

    def __init__(
        self,
        style: str = "strict_coach",
        proactive_enabled: bool = True,
        proactive_interval_sec: int = 300,
        name: str = "Compass",
    ) -> None:
        self._style = style
        self._proactive_enabled = proactive_enabled
        self._interval = proactive_interval_sec
        self._name = name

        self._last_proactive = 0.0
        self._message_history: List[ProactiveMessage] = []

        if style not in STYLE_DIRECTIVES:
            logger.warning(
                f"PersonalityEngine: unknown style '{style}', "
                f"defaulting to 'strict_coach'"
            )
            self._style = "strict_coach"

        logger.info(
            f"PersonalityEngine: style={self._style} "
            f"proactive={proactive_enabled} interval={proactive_interval_sec}s"
        )

    # ── Public API ──────────────────────────────────────────

    def get_style_directive(self) -> str:
        """Return the system prompt personality directive for this style."""
        return STYLE_DIRECTIVES[self._style]

    def should_speak_proactively(self, is_in_conversation: bool) -> bool:
        """
        Return True if enough time has passed and conditions allow
        a proactive message to be delivered.
        """
        if not self._proactive_enabled:
            return False
        if is_in_conversation:
            return False
        elapsed = time.time() - self._last_proactive
        return elapsed >= self._interval

    def generate_proactive_message(
        self,
        trigger: str,
        data: dict,
    ) -> Optional[ProactiveMessage]:
        """
        Generate a proactive message for the given trigger and data.

        Args:
            trigger: One of: distraction | idle | work_sprint |
                     context_switch | morning | end_of_day
            data:    Context dict for template substitution.
                     e.g. {"app": "YouTube", "minutes": 8}

        Returns:
            ProactiveMessage or None if conditions not met.
        """
        templates = PROACTIVE_TEMPLATES.get(trigger, [])
        if not templates:
            logger.warning(f"PersonalityEngine: no templates for trigger '{trigger}'")
            return None

        # Pick template deterministically based on time (avoids randomness)
        idx = int(time.time() / 3600) % len(templates)
        template = templates[idx]

        try:
            message = template.format(**data)
        except KeyError as e:
            logger.warning(f"PersonalityEngine: template key error {e}")
            message = template

        self._last_proactive = time.time()

        msg = ProactiveMessage(
            trigger=trigger,
            message=message,
            timestamp=time.time(),
            data=data,
        )
        self._message_history.append(msg)
        logger.info(f"PersonalityEngine: proactive [{trigger}]: {message}")
        return msg

    def check_time_triggers(self) -> Optional[ProactiveMessage]:
        """
        Check for time-of-day triggered messages (morning / end-of-day).
        Call this once per minute.
        """
        from datetime import datetime
        hour = datetime.now().hour
        minute = datetime.now().minute

        # Morning check-in at 9:00
        if hour == 9 and minute == 0:
            if not self._fired_today("morning"):
                return self.generate_proactive_message("morning", {})

        # End of day at 18:00
        if hour == 18 and minute == 0:
            if not self._fired_today("end_of_day"):
                return self.generate_proactive_message("end_of_day", {})

        return None

    def get_history(self) -> List[ProactiveMessage]:
        return list(self._message_history)

    def set_style(self, style: str) -> bool:
        """Hot-swap personality style at runtime."""
        if style not in STYLE_DIRECTIVES:
            return False
        self._style = style
        logger.info(f"PersonalityEngine: style changed to '{style}'")
        return True

    # ── Helpers ──────────────────────────────────────────────

    def _fired_today(self, trigger: str) -> bool:
        """Return True if this trigger was already fired today."""
        from datetime import date
        today = date.today()
        for msg in reversed(self._message_history):
            from datetime import datetime
            msg_date = datetime.fromtimestamp(msg.timestamp).date()
            if msg_date == today and msg.trigger == trigger:
                return True
        return False

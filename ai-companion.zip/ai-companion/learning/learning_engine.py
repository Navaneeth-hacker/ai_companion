"""
learning/learning_engine.py
============================
Phase 5 adaptive learning engine.

This is NOT self-modifying AI. It is structured preference learning:
  - Tracks which LLM response styles the user prefers (explicit feedback).
  - Learns the user's typical work schedule and app patterns.
  - Adapts the system prompt based on observed preferences.
  - Scores workflow patterns and suggests improvements.
  - Predicts which tasks the user is likely working on.

Components:
  1. PreferenceTracker   — Records explicit feedback on responses.
  2. PatternLearner      — Mines activity logs for behavioral patterns.
  3. PromptAdapter       — Modifies system prompt based on learned preferences.
  4. WorkflowScorer      — Scores and ranks workflow patterns.
  5. TaskPredictor       — Predicts likely current task from context.

Safety:
  - No unsupervised code generation.
  - No model fine-tuning (weights never modified).
  - All learned preferences are human-readable and editable in DB.
  - User can reset learning at any time.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from loguru import logger


@dataclass
class FeedbackRecord:
    response_id: str
    response_text: str
    feedback: str           # "good" | "too_long" | "too_short" | "wrong_tone" | "helpful"
    context: str            # What was the user doing?
    timestamp: float = field(default_factory=time.time)


@dataclass
class WorkPattern:
    """A learned behavioral pattern."""
    pattern_type: str       # "peak_hours" | "distraction_trigger" | "focus_sequence"
    description: str
    confidence: float       # 0–1
    occurrences: int
    last_seen: float


@dataclass
class AdaptedPrompt:
    """A system prompt variation adapted for current context."""
    base_prompt: str
    adaptations: List[str]
    full_prompt: str


class PreferenceTracker:
    """Records and analyzes user feedback on AI responses."""

    def __init__(self, memory_engine=None) -> None:
        self._memory = memory_engine
        self._feedback_history: List[FeedbackRecord] = []
        self._preference_counts: Dict[str, Dict[str, int]] = defaultdict(
            lambda: defaultdict(int)
        )

    async def record_feedback(
        self,
        response_text: str,
        feedback: str,
        context: str = "",
        response_id: str = "",
    ) -> None:
        record = FeedbackRecord(
            response_id=response_id or str(time.time()),
            response_text=response_text[:200],
            feedback=feedback,
            context=context,
        )
        self._feedback_history.append(record)

        # Track preference patterns
        length_bucket = (
            "short" if len(response_text) < 100
            else "medium" if len(response_text) < 400
            else "long"
        )
        self._preference_counts[feedback][length_bucket] += 1

        if self._memory:
            await self._memory.store_memory(
                content=f"User gave feedback '{feedback}' on a {length_bucket} response.",
                memory_type="preference",
                importance=0.6,
                source="feedback",
            )
        logger.info(f"PreferenceTracker: recorded feedback={feedback}")

    def get_preferred_length(self) -> str:
        """Infer preferred response length from feedback history."""
        helpful = self._preference_counts.get("good", {}) or \
                  self._preference_counts.get("helpful", {})
        if not helpful:
            return "medium"  # Default
        return max(helpful, key=helpful.get)

    def get_style_summary(self) -> str:
        preferred_len = self.get_preferred_length()
        total_feedback = len(self._feedback_history)
        positive = sum(
            1 for f in self._feedback_history
            if f.feedback in ("good", "helpful")
        )
        pct = round((positive / total_feedback * 100) if total_feedback else 0)
        return (
            f"Preferred response length: {preferred_len}. "
            f"Positive feedback rate: {pct}% ({total_feedback} samples)."
        )


class PatternLearner:
    """
    Mines activity log data to find behavioral patterns.
    Runs as a periodic job (every hour).
    """

    def __init__(self, memory_engine=None) -> None:
        self._memory = memory_engine
        self._learned_patterns: List[WorkPattern] = []

    async def analyze(self, activity_samples: List[dict]) -> List[WorkPattern]:
        """
        Analyze activity samples to extract patterns.
        Samples: list of {timestamp, category, is_productive, is_distraction}
        """
        if len(activity_samples) < 10:
            return []

        patterns = []

        # ── Peak productivity hours ──────────────────────────
        hour_productivity: Dict[int, Tuple[int, int]] = defaultdict(lambda: (0, 0))
        for s in activity_samples:
            hour = datetime.fromtimestamp(s["timestamp"]).hour
            prod, total = hour_productivity[hour]
            hour_productivity[hour] = (
                prod + (1 if s.get("is_productive") else 0),
                total + 1,
            )

        best_hours = [
            h for h, (p, t) in hour_productivity.items()
            if t >= 5 and (p / t) >= 0.7
        ]
        if best_hours:
            hour_strs = ", ".join(f"{h}:00" for h in sorted(best_hours))
            patterns.append(WorkPattern(
                pattern_type="peak_hours",
                description=f"Most productive hours: {hour_strs}",
                confidence=0.7,
                occurrences=len(best_hours),
                last_seen=time.time(),
            ))

        # ── Distraction triggers ─────────────────────────────
        # Find sequences: was productive, then became distracted
        transitions = []
        for i in range(1, len(activity_samples)):
            prev = activity_samples[i - 1]
            curr = activity_samples[i]
            if prev.get("is_productive") and curr.get("is_distraction"):
                transitions.append(curr.get("category", "unknown"))

        if transitions:
            from collections import Counter
            most_common_distraction = Counter(transitions).most_common(1)[0]
            patterns.append(WorkPattern(
                pattern_type="distraction_trigger",
                description=(
                    f"Most common distraction after focus: "
                    f"{most_common_distraction[0]} "
                    f"({most_common_distraction[1]} times)"
                ),
                confidence=min(0.9, most_common_distraction[1] / 10),
                occurrences=most_common_distraction[1],
                last_seen=time.time(),
            ))

        self._learned_patterns = patterns

        # Store new patterns as memories
        if self._memory:
            for p in patterns:
                await self._memory.store_memory(
                    content=p.description,
                    memory_type="habit",
                    importance=p.confidence,
                    source="pattern_learner",
                )

        return patterns

    def get_patterns_summary(self) -> str:
        if not self._learned_patterns:
            return "No patterns learned yet."
        return " | ".join(p.description for p in self._learned_patterns)


class PromptAdapter:
    """
    Dynamically adapts the LLM system prompt based on learned preferences
    and current context.

    This does NOT modify model weights — it only changes the text prompt.
    All adaptations are deterministic and auditable.
    """

    def __init__(
        self,
        base_prompt: str,
        preference_tracker: PreferenceTracker,
        pattern_learner: PatternLearner,
    ) -> None:
        self._base = base_prompt
        self._prefs = preference_tracker
        self._patterns = pattern_learner

    def build_prompt(
        self,
        vision_context: str = "",
        memory_context: str = "",
        time_of_day: Optional[str] = None,
    ) -> AdaptedPrompt:
        """Build the full system prompt for this specific interaction."""
        adaptations = []

        # Length preference
        preferred_len = self._prefs.get_preferred_length()
        if preferred_len == "short":
            adaptations.append(
                "Keep responses under 2 sentences unless more detail is explicitly requested."
            )
        elif preferred_len == "long":
            adaptations.append(
                "Provide thorough, detailed responses."
            )

        # Time of day context
        if time_of_day is None:
            hour = datetime.now().hour
            time_of_day = (
                "morning" if 5 <= hour < 12
                else "afternoon" if 12 <= hour < 17
                else "evening" if 17 <= hour < 21
                else "night"
            )

        # Behavioral patterns
        pattern_summary = self._patterns.get_patterns_summary()
        if pattern_summary and pattern_summary != "No patterns learned yet.":
            adaptations.append(f"User behavioral patterns: {pattern_summary}")

        # Build the full prompt
        sections = [self._base]

        if adaptations:
            sections.append("\n[Learned preferences]\n" + "\n".join(f"- {a}" for a in adaptations))

        if vision_context:
            sections.append(f"\n[Current screen context]\n{vision_context}")

        if memory_context:
            sections.append(f"\n{memory_context}")

        sections.append(f"\n[Time] It is currently {time_of_day}.")

        full_prompt = "\n".join(sections)

        return AdaptedPrompt(
            base_prompt=self._base,
            adaptations=adaptations,
            full_prompt=full_prompt,
        )


class TaskPredictor:
    """
    Predicts what task the user is likely working on,
    based on open windows, time of day, and past patterns.
    """

    def predict(
        self,
        active_category: str,
        window_title: str,
        hour: int,
        learned_patterns: List[WorkPattern],
    ) -> str:
        """Return a human-readable prediction of current task."""
        # Simple rule-based prediction for Phase 5
        # Phase 6 will use the LLM itself for richer prediction

        if active_category == "coding":
            return f"Coding session (likely working on: {window_title[:40]})"
        elif active_category == "terminal":
            return "Running terminal commands / devops work"
        elif active_category == "browser":
            if any(k in window_title.lower() for k in ["github", "docs", "stackoverflow"]):
                return "Technical research / documentation reading"
            elif any(k in window_title.lower() for k in ["youtube", "reddit", "twitter"]):
                return "Browsing / distraction"
            return "General web browsing"
        elif active_category == "document":
            return f"Writing / document editing ({window_title[:40]})"
        elif active_category == "communication":
            return "Messaging / communication"

        return f"Working on {active_category} task"


class LearningEngine:
    """
    Orchestrates all Phase 5 learning components.
    Single entry point used by the pipeline.
    """

    def __init__(self, base_prompt: str, memory_engine=None) -> None:
        self.preference_tracker = PreferenceTracker(memory_engine)
        self.pattern_learner = PatternLearner(memory_engine)
        self.prompt_adapter = PromptAdapter(
            base_prompt, self.preference_tracker, self.pattern_learner
        )
        self.task_predictor = TaskPredictor()
        self._memory = memory_engine
        logger.info("LearningEngine: initialized")

    def build_system_prompt(
        self,
        vision_context: str = "",
        memory_context: str = "",
    ) -> str:
        """Build the full adaptive system prompt for the current interaction."""
        adapted = self.prompt_adapter.build_prompt(
            vision_context=vision_context,
            memory_context=memory_context,
        )
        return adapted.full_prompt

    async def record_feedback(self, response_text: str, feedback: str) -> None:
        await self.preference_tracker.record_feedback(response_text, feedback)

    async def run_pattern_analysis(self, activity_samples: List[dict]) -> None:
        patterns = await self.pattern_learner.analyze(activity_samples)
        if patterns:
            logger.info(
                f"LearningEngine: learned {len(patterns)} patterns: "
                + " | ".join(p.description[:50] for p in patterns)
            )

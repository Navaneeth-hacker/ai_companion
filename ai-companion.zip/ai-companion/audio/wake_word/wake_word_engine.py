"""
audio/wake_word/wake_word_engine.py
=====================================
Continuous wake word detection using OpenWakeWord.

Architecture:
  - Runs in its own dedicated thread (not asyncio — pyaudio callbacks are sync).
  - Posts WakeWordEvent to the asyncio EventBus via publish_sync().
  - Also posts InterruptEvent if wake word fires while companion is speaking
    (checked via the `is_speaking` flag set by the TTS engine).

OpenWakeWord specifics:
  - Requires 16kHz mono int16 PCM audio chunks of exactly 1280 samples (~80ms).
  - We maintain a ring buffer and slice into OWW-sized chunks.
  - OWW runs ONNX inference; no GPU needed (fast on CPU).

Wake word models available out of the box:
  - "hey_jarvis", "alexa", "hey_mycroft", "timer", "weather" (pre-trained)
  - Custom .onnx models can be trained with the OWW training repo.

For "wake up" specifically: use the "hey_jarvis" model or train a custom one.
See scripts/train_wake_word.py for training pipeline.
"""

from __future__ import annotations

import asyncio
import threading
import time
from pathlib import Path
from typing import Optional

import numpy as np
import pyaudio
from loguru import logger

try:
    from openwakeword.model import Model as OWWModel
except ImportError:
    OWWModel = None  # type: ignore

from core.events.event_bus import EventBus, WakeWordEvent, InterruptEvent


# OpenWakeWord requires exactly this chunk size
OWW_CHUNK_SAMPLES = 1280   # 80ms at 16kHz


class WakeWordEngine:
    """
    Continuous wake word detector.

    Args:
        event_bus:     The shared EventBus to publish events on.
        event_loop:    The main asyncio loop (for thread-safe publishing).
        model_name:    OWW model to load. Can be a built-in name or .onnx path.
        wake_words:    List of wake word strings to report (cosmetic; OWW decides detection).
        threshold:     Confidence score above which a detection is reported (0–1).
        sample_rate:   Audio sample rate in Hz (must be 16000).
        is_speaking:   Shared threading.Event; if set, wake word triggers interrupt.
    """

    def __init__(
        self,
        event_bus: EventBus,
        event_loop: asyncio.AbstractEventLoop,
        model_name: str = "hey_jarvis",
        wake_words: list[str] | None = None,
        threshold: float = 0.5,
        sample_rate: int = 16000,
        is_speaking: Optional[threading.Event] = None,
    ) -> None:
        if OWWModel is None:
            raise ImportError(
                "openwakeword is not installed. "
                "Run: pip install openwakeword"
            )

        self._bus = event_bus
        self._loop = event_loop
        self._threshold = threshold
        self._sample_rate = sample_rate
        self._wake_words = wake_words or ["wake up"]
        self._is_speaking = is_speaking or threading.Event()

        self._model: Optional[OWWModel] = None
        self._pa: Optional[pyaudio.PyAudio] = None
        self._stream: Optional[pyaudio.Stream] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # Ring buffer: holds exactly OWW_CHUNK_SAMPLES of int16 samples
        self._ring: np.ndarray = np.zeros(OWW_CHUNK_SAMPLES, dtype=np.int16)
        self._write_pos = 0
        self._cooldown_sec = 1.5    # Minimum seconds between detections
        self._last_detection = 0.0

        logger.info(
            f"WakeWordEngine: model={model_name} "
            f"threshold={threshold} words={self._wake_words}"
        )
        self._model_name = model_name

    # ── Public API ──────────────────────────────────────────

    def start(self) -> None:
        """Load model and start background detection thread."""
        logger.info("WakeWordEngine: loading model...")
        self._load_model()
        self._thread = threading.Thread(
            target=self._detection_loop,
            name="wake-word-thread",
            daemon=True,
        )
        self._thread.start()
        logger.info("WakeWordEngine: started")

    def stop(self) -> None:
        """Signal the detection loop to stop and clean up."""
        self._stop_event.set()
        if self._stream:
            try:
                self._stream.stop_stream()
                self._stream.close()
            except Exception:
                pass
        if self._pa:
            self._pa.terminate()
        if self._thread:
            self._thread.join(timeout=3.0)
        logger.info("WakeWordEngine: stopped")

    # ── Private ─────────────────────────────────────────────

    def _load_model(self) -> None:
        """
        Load the OWW model. OWW supports:
          - Built-in names: "hey_jarvis", "alexa", etc.
          - Paths to .onnx files for custom models.
        """
        model_path = Path(self._model_name)
        if model_path.exists():
            self._model = OWWModel(
                wakeword_models=[str(model_path)],
                inference_framework="onnx",
            )
        else:
            # Let OWW download / use its built-in models
            self._model = OWWModel(
                wakeword_models=[self._model_name],
                inference_framework="onnx",
            )
        logger.info("WakeWordEngine: model loaded")

    def _detection_loop(self) -> None:
        """
        Opens a PyAudio stream and continuously reads audio chunks.
        On each chunk, runs OWW inference and publishes events.
        """
        self._pa = pyaudio.PyAudio()
        try:
            self._stream = self._pa.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=self._sample_rate,
                input=True,
                frames_per_buffer=OWW_CHUNK_SAMPLES,
            )
        except Exception as e:
            logger.error(f"WakeWordEngine: failed to open audio stream: {e}")
            return

        logger.info(
            f"WakeWordEngine: listening on mic | "
            f"chunk={OWW_CHUNK_SAMPLES} samples"
        )

        while not self._stop_event.is_set():
            try:
                raw = self._stream.read(OWW_CHUNK_SAMPLES, exception_on_overflow=False)
            except Exception as e:
                logger.warning(f"WakeWordEngine: stream read error: {e}")
                continue

            # Convert bytes → int16 numpy array
            audio_chunk = np.frombuffer(raw, dtype=np.int16)

            # Run OWW inference on this chunk
            predictions = self._model.predict(audio_chunk)

            now = time.time()
            if now - self._last_detection < self._cooldown_sec:
                continue

            # Check each model's score
            for model_name, score in predictions.items():
                if score >= self._threshold:
                    self._last_detection = now
                    logger.info(
                        f"WakeWordEngine: DETECTED | model={model_name} "
                        f"score={score:.3f}"
                    )

                    # If TTS is currently speaking, this is an interrupt
                    if self._is_speaking.is_set():
                        self._bus.publish_sync(
                            InterruptEvent(reason="wake_word_interrupt"),
                            self._loop,
                        )
                    else:
                        self._bus.publish_sync(
                            WakeWordEvent(
                                word=self._wake_words[0],
                                confidence=float(score),
                                timestamp=now,
                            ),
                            self._loop,
                        )
                    break   # Only one detection per chunk

        logger.info("WakeWordEngine: detection loop exited")

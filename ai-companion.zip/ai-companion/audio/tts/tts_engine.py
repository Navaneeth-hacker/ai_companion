"""
audio/tts/tts_engine.py
=======================
Text-to-Speech using Piper TTS with real-time streaming playback.

Architecture:
  - Subscribes to LLMStreamChunkEvent (sentences from LLM streaming).
  - Maintains a sentence queue for ordered, non-overlapping playback.
  - Synthesizes WAV audio using Piper (subprocess call or native binding).
  - Plays audio via sounddevice for precise device control.
  - Sets is_speaking flag so wake word engine can detect interrupts.

Why Piper TTS?
  - Extremely fast synthesis (< 100ms for a sentence on CPU).
  - Neural quality voices (VITS-based).
  - Fully offline, no cloud API.
  - ~50MB per voice model.

Two synthesis methods:
  1. Subprocess: calls the piper binary — most compatible.
  2. Binding:    uses piper_tts Python package — no binary required.

We default to the Python binding. Fall back to subprocess if binding not available.

Interrupt handling:
  - On InterruptEvent, clear the queue and stop current playback.
  - is_speaking threading.Event is cleared immediately.
"""

from __future__ import annotations

import asyncio
import io
import queue
import subprocess
import threading
import time
import wave
from pathlib import Path
from typing import Optional

import numpy as np
import sounddevice as sd
from loguru import logger

try:
    from piper.voice import PiperVoice
    PIPER_AVAILABLE = True
except ImportError:
    PiperVoice = None  # type: ignore
    PIPER_AVAILABLE = False

from core.events.event_bus import (
    EventBus,
    LLMStreamChunkEvent,
    LLMResponseEvent,
    TTSStartEvent,
    TTSDoneEvent,
    InterruptEvent,
    SystemStatusEvent,
)


class TTSEngine:
    """
    Text-to-Speech engine with streaming input and queued playback.

    Args:
        event_bus:      Shared EventBus.
        model_path:     Path to Piper .onnx voice model.
        config_path:    Path to the matching .onnx.json config file.
        speaking_rate:  Playback speed (1.0 = normal).
        volume:         Volume multiplier (0.0 – 2.0).
        sample_rate:    Audio output sample rate.
        output_device:  sounddevice output device index (-1 = default).
        is_speaking:    Shared threading.Event; set while audio is playing.
    """

    def __init__(
        self,
        event_bus: EventBus,
        model_path: Path,
        config_path: Path,
        speaking_rate: float = 1.0,
        volume: float = 1.0,
        sample_rate: int = 22050,
        output_device: int = -1,
        is_speaking: Optional[threading.Event] = None,
    ) -> None:
        self._bus = event_bus
        self._model_path = Path(model_path)
        self._config_path = Path(config_path)
        self._speaking_rate = speaking_rate
        self._volume = volume
        self._sample_rate = sample_rate
        self._output_device = None if output_device == -1 else output_device
        self._is_speaking = is_speaking or threading.Event()

        self._voice: Optional[PiperVoice] = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._playback_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._interrupt_event = threading.Event()

        # Subscribe
        self._bus.subscribe(LLMStreamChunkEvent, self._on_stream_chunk)
        self._bus.subscribe(InterruptEvent, self._on_interrupt)

        logger.info(
            f"TTSEngine: model={model_path.name} "
            f"rate={speaking_rate} volume={volume}"
        )

    # ── Public API ──────────────────────────────────────────

    async def load(self) -> None:
        """Load the Piper voice model."""
        if not PIPER_AVAILABLE:
            logger.warning(
                "TTSEngine: piper_tts Python binding not found. "
                "Will use subprocess fallback. Install: pip install piper-tts"
            )
        elif not self._model_path.exists():
            logger.error(
                f"TTSEngine: model file not found: {self._model_path}. "
                f"See scripts/download_models.py"
            )
        else:
            logger.info("TTSEngine: loading Piper voice model...")
            self._voice = PiperVoice.load(
                str(self._model_path),
                config_path=str(self._config_path),
                use_cuda=self._has_cuda(),
            )
            logger.info("TTSEngine: voice model loaded")

        # Start the background playback thread
        self._playback_thread = threading.Thread(
            target=self._playback_loop,
            name="tts-playback-thread",
            daemon=True,
        )
        self._playback_thread.start()
        await self._bus.publish(SystemStatusEvent("tts", "ready"))
        logger.info("TTSEngine: ready")

    async def stop(self) -> None:
        """Stop playback thread and release resources."""
        self._stop_event.set()
        self._audio_queue.put(None)  # Sentinel to unblock queue.get()
        if self._playback_thread:
            self._playback_thread.join(timeout=3.0)
        self._voice = None
        logger.info("TTSEngine: stopped")

    async def speak(self, text: str) -> None:
        """
        Synthesize and queue audio for playback.
        This is a non-blocking enqueue operation.
        """
        if not text.strip():
            return

        audio = await asyncio.get_event_loop().run_in_executor(
            None, self._synthesize, text
        )
        if audio is not None:
            self._audio_queue.put((text, audio))

    # ── Event handlers ──────────────────────────────────────

    async def _on_stream_chunk(self, event: LLMStreamChunkEvent) -> None:
        """Synthesize and queue a sentence chunk from the LLM stream."""
        await self.speak(event.chunk)

    async def _on_interrupt(self, event: InterruptEvent) -> None:
        """Stop all queued and active playback immediately."""
        logger.info("TTSEngine: interrupt — clearing playback queue")
        self._interrupt_event.set()

        # Drain the queue
        while not self._audio_queue.empty():
            try:
                self._audio_queue.get_nowait()
            except queue.Empty:
                break

        # Stop sounddevice output
        try:
            sd.stop()
        except Exception:
            pass

        self._is_speaking.clear()
        self._interrupt_event.clear()

    # ── Synthesis ───────────────────────────────────────────

    def _synthesize(self, text: str) -> Optional[np.ndarray]:
        """
        Synthesize text to audio using Piper.
        Returns float32 numpy array of audio samples.
        Falls back to subprocess if binding unavailable.
        """
        if self._voice is not None:
            return self._synthesize_binding(text)
        return self._synthesize_subprocess(text)

    def _synthesize_binding(self, text: str) -> Optional[np.ndarray]:
        """Use the piper_tts Python binding."""
        try:
            # Piper binding: synthesize returns a generator of audio chunks
            wav_buffer = io.BytesIO()
            with wave.open(wav_buffer, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)  # 16-bit
                wf.setframerate(self._voice.config.sample_rate)
                for audio_bytes in self._voice.synthesize_stream_raw(text):
                    wf.writeframes(audio_bytes)

            wav_buffer.seek(0)
            with wave.open(wav_buffer, "rb") as wf:
                raw = wf.readframes(wf.getnframes())

            audio_int16 = np.frombuffer(raw, dtype=np.int16)
            audio_float32 = audio_int16.astype(np.float32) / 32768.0
            return audio_float32 * self._volume

        except Exception as e:
            logger.error(f"TTSEngine: synthesis error: {e}")
            return None

    def _synthesize_subprocess(self, text: str) -> Optional[np.ndarray]:
        """
        Fallback: call piper binary via subprocess.
        Requires piper.exe in PATH or PIPER_BINARY env var.
        """
        import os
        import tempfile

        piper_bin = os.environ.get("PIPER_BINARY", "piper")
        out_file = tempfile.mktemp(suffix=".wav")

        try:
            result = subprocess.run(
                [
                    piper_bin,
                    "--model", str(self._model_path),
                    "--output_file", out_file,
                    "--sentence_silence", "0.2",
                ],
                input=text.encode("utf-8"),
                capture_output=True,
                timeout=30,
            )
            if result.returncode != 0:
                logger.error(
                    f"TTSEngine: piper subprocess failed: "
                    f"{result.stderr.decode('utf-8', errors='replace')}"
                )
                return None

            with wave.open(out_file, "rb") as wf:
                raw = wf.readframes(wf.getnframes())
                sr = wf.getframerate()

            audio_int16 = np.frombuffer(raw, dtype=np.int16)
            audio_float32 = audio_int16.astype(np.float32) / 32768.0
            return audio_float32 * self._volume

        except FileNotFoundError:
            logger.error(
                f"TTSEngine: piper binary not found. "
                f"Set PIPER_BINARY env var or add piper to PATH."
            )
            return None
        except Exception as e:
            logger.error(f"TTSEngine: subprocess synthesis error: {e}")
            return None
        finally:
            if os.path.exists(out_file):
                os.unlink(out_file)

    # ── Playback loop ────────────────────────────────────────

    def _playback_loop(self) -> None:
        """
        Background thread: dequeue synthesized audio and play it.
        Blocks while each clip plays; checks interrupt between clips.
        """
        logger.debug("TTSEngine: playback loop started")

        while not self._stop_event.is_set():
            try:
                item = self._audio_queue.get(timeout=0.5)
            except queue.Empty:
                continue

            if item is None:  # Sentinel
                break

            text, audio = item

            if self._interrupt_event.is_set():
                continue

            self._is_speaking.set()
            logger.debug(f"TTSEngine: playing: '{text[:60]}'")

            try:
                # sounddevice.play is synchronous in a thread
                sd.play(
                    audio,
                    samplerate=self._sample_rate,
                    device=self._output_device,
                    blocking=True,
                )
            except Exception as e:
                logger.error(f"TTSEngine: playback error: {e}")
            finally:
                # Only clear if queue is now empty (more chunks may follow)
                if self._audio_queue.empty():
                    self._is_speaking.clear()
                    # Publish done event via thread-safe call
                    # (we can't await here; use run_coroutine_threadsafe later)

        logger.debug("TTSEngine: playback loop exited")

    @staticmethod
    def _has_cuda() -> bool:
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False

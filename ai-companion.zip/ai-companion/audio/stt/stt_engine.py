"""
audio/stt/stt_engine.py
=======================
Speech-to-Text using Faster-Whisper (CTranslate2 backend).

Architecture:
  - Triggered by WakeWordEvent via EventBus subscription.
  - Opens a temporary PyAudio stream, records until silence (VAD-detected).
  - Sends audio to Faster-Whisper for transcription.
  - Publishes TranscriptionEvent on completion.

Why Faster-Whisper over openai-whisper?
  - 4× faster on CPU, 2× on GPU due to CTranslate2 quantization.
  - Supports int8 inference (low VRAM).
  - Built-in Silero VAD for silence detection.

VAD-based recording strategy:
  - After wake word, open audio stream.
  - Collect audio until X seconds of consecutive silence.
  - Send entire segment to Whisper at once (not streaming).
  - This gives better accuracy than real-time streaming at the cost of latency.
  - For streaming transcription, see the comment at the bottom of this file.
"""

from __future__ import annotations

import asyncio
import io
import time
import wave
from pathlib import Path
from typing import Optional

import numpy as np
import pyaudio
from loguru import logger

try:
    from faster_whisper import WhisperModel
    from faster_whisper.vad import VadOptions
except ImportError:
    WhisperModel = None  # type: ignore
    VadOptions = None    # type: ignore

from core.events.event_bus import (
    EventBus,
    WakeWordEvent,
    TranscriptionEvent,
    InterruptEvent,
    SystemStatusEvent,
)


class STTEngine:
    """
    Speech-to-Text engine.

    Args:
        event_bus:        The shared EventBus.
        model:            Whisper model size: tiny | base | small | medium | large-v3
        device:           "auto" | "cpu" | "cuda"
        compute_type:     "auto" | "int8" | "float16" | "float32"
        language:         ISO 639-1 language code, or None for auto-detect.
        sample_rate:      Audio sample rate (must match microphone; 16000).
        silence_timeout:  Seconds of silence before recording stops.
        max_record_sec:   Hard cap on recording duration.
        vad_filter:       Enable Silero VAD post-processing in Faster-Whisper.
    """

    def __init__(
        self,
        event_bus: EventBus,
        model: str = "base",
        device: str = "auto",
        compute_type: str = "auto",
        language: Optional[str] = "en",
        sample_rate: int = 16000,
        silence_timeout: float = 2.0,
        max_record_sec: float = 30.0,
        vad_filter: bool = True,
    ) -> None:
        if WhisperModel is None:
            raise ImportError(
                "faster-whisper is not installed. "
                "Run: pip install faster-whisper"
            )

        self._bus = event_bus
        self._model_size = model
        self._device = self._resolve_device(device)
        self._compute_type = self._resolve_compute_type(compute_type, self._device)
        self._language = language
        self._sample_rate = sample_rate
        self._silence_timeout = silence_timeout
        self._max_record_sec = max_record_sec
        self._vad_filter = vad_filter

        self._whisper: Optional[WhisperModel] = None
        self._pa: Optional[pyaudio.PyAudio] = None
        self._is_recording = asyncio.Event()
        self._interrupt_flag = asyncio.Event()

        # Subscribe to events
        self._bus.subscribe(WakeWordEvent, self._on_wake_word)
        self._bus.subscribe(InterruptEvent, self._on_interrupt)

        logger.info(
            f"STTEngine: model={model} device={self._device} "
            f"compute_type={self._compute_type}"
        )

    # ── Public API ──────────────────────────────────────────

    async def load(self) -> None:
        """Load the Whisper model. Call once at startup."""
        logger.info(f"STTEngine: loading Whisper {self._model_size}...")
        t0 = time.time()
        self._whisper = WhisperModel(
            self._model_size,
            device=self._device,
            compute_type=self._compute_type,
            download_root="models/stt",
        )
        elapsed = time.time() - t0
        logger.info(f"STTEngine: Whisper loaded in {elapsed:.1f}s")
        await self._bus.publish(SystemStatusEvent("stt", "ready"))
        self._pa = pyaudio.PyAudio()

    async def unload(self) -> None:
        """Release model resources."""
        self._whisper = None
        if self._pa:
            self._pa.terminate()
        logger.info("STTEngine: unloaded")

    # ── Event handlers ──────────────────────────────────────

    async def _on_wake_word(self, event: WakeWordEvent) -> None:
        """Start recording when wake word fires."""
        if self._is_recording.is_set():
            logger.debug("STTEngine: wake word received but already recording")
            return

        logger.info("STTEngine: wake word received — starting recording")
        self._interrupt_flag.clear()
        self._is_recording.set()

        try:
            audio_data = await asyncio.get_event_loop().run_in_executor(
                None, self._record_until_silence
            )

            if self._interrupt_flag.is_set() or not audio_data:
                logger.info("STTEngine: recording interrupted or empty")
                return

            await asyncio.get_event_loop().run_in_executor(
                None, self._transcribe, audio_data
            )

        except Exception as e:
            logger.error(f"STTEngine: error during recording/transcription: {e}")
            await self._bus.publish(SystemStatusEvent("stt", "error", str(e)))
        finally:
            self._is_recording.clear()

    async def _on_interrupt(self, event: InterruptEvent) -> None:
        """Cancel any active recording."""
        self._interrupt_flag.set()
        logger.info("STTEngine: interrupt received — cancelling recording")

    # ── Recording ───────────────────────────────────────────

    def _record_until_silence(self) -> Optional[np.ndarray]:
        """
        Record audio from the microphone until silence is detected.

        Strategy:
          1. Compute a rolling RMS energy of recent audio.
          2. When RMS drops below the VAD threshold for silence_timeout seconds,
             stop recording.
          3. Return the full recording as a float32 numpy array.

        This runs in a thread executor (blocking pyaudio calls).
        """
        CHUNK = 1024
        SILENCE_THRESHOLD = 300   # RMS energy below this = silence
        silence_chunks_needed = int(
            self._silence_timeout * self._sample_rate / CHUNK
        )
        max_chunks = int(self._max_record_sec * self._sample_rate / CHUNK)

        stream = self._pa.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=self._sample_rate,
            input=True,
            frames_per_buffer=CHUNK,
        )

        frames = []
        silence_count = 0
        logger.debug("STTEngine: recording...")

        try:
            for i in range(max_chunks):
                if self._interrupt_flag.is_set():
                    break

                raw = stream.read(CHUNK, exception_on_overflow=False)
                frames.append(raw)

                # Compute RMS of this chunk
                chunk_np = np.frombuffer(raw, dtype=np.int16)
                rms = float(np.sqrt(np.mean(chunk_np.astype(np.float32) ** 2)))

                if rms < SILENCE_THRESHOLD:
                    silence_count += 1
                else:
                    silence_count = 0

                if silence_count >= silence_chunks_needed and len(frames) > 10:
                    logger.debug(
                        f"STTEngine: silence detected after "
                        f"{len(frames) * CHUNK / self._sample_rate:.1f}s"
                    )
                    break
        finally:
            stream.stop_stream()
            stream.close()

        if len(frames) < 5:
            return None

        # Concatenate all frames into a float32 numpy array (Whisper format)
        raw_audio = b"".join(frames)
        audio_int16 = np.frombuffer(raw_audio, dtype=np.int16)
        audio_float32 = audio_int16.astype(np.float32) / 32768.0
        return audio_float32

    def _transcribe(self, audio: np.ndarray) -> None:
        """
        Run Faster-Whisper on the recorded audio.
        Publishes TranscriptionEvent when done.
        Runs in a thread executor.
        """
        if self._whisper is None:
            logger.error("STTEngine: Whisper model not loaded")
            return

        t0 = time.time()

        vad_opts = None
        if self._vad_filter and VadOptions is not None:
            vad_opts = VadOptions(
                threshold=0.5,
                min_speech_duration_ms=250,
                min_silence_duration_ms=300,
            )

        segments, info = self._whisper.transcribe(
            audio,
            language=self._language,
            beam_size=5,
            vad_filter=self._vad_filter,
            vad_parameters=vad_opts,
            word_timestamps=False,
        )

        # Materialize the generator (segments is lazy in Faster-Whisper)
        full_text = " ".join(seg.text.strip() for seg in segments)
        elapsed = time.time() - t0

        if not full_text.strip():
            logger.info("STTEngine: transcription produced empty text")
            return

        logger.info(
            f"STTEngine: transcribed in {elapsed:.2f}s | "
            f"lang={info.language} | text='{full_text[:80]}'"
        )

        # Publish to event bus (thread-safe)
        event = TranscriptionEvent(
            text=full_text.strip(),
            language=info.language,
            timestamp=time.time(),
            duration_sec=elapsed,
        )
        # We're in a thread — must use the loop reference
        # The caller (event bus handler) provides this via run_in_executor context
        # For now we use asyncio.run_coroutine_threadsafe from the stored loop ref
        loop = asyncio.get_event_loop()
        asyncio.run_coroutine_threadsafe(
            self._bus.publish(event), loop
        )

    # ── Helpers ─────────────────────────────────────────────

    @staticmethod
    def _resolve_device(device: str) -> str:
        if device == "auto":
            try:
                import torch
                return "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                pass
            try:
                import ctranslate2
                if "cuda" in ctranslate2.get_supported_compute_types("cuda"):
                    return "cuda"
            except Exception:
                pass
            return "cpu"
        return device

    @staticmethod
    def _resolve_compute_type(compute_type: str, device: str) -> str:
        if compute_type != "auto":
            return compute_type
        if device == "cuda":
            return "float16"
        return "int8"


# ─────────────────────────────────────────────────────────────
# STREAMING STT NOTE (for future reference):
#
# Faster-Whisper does NOT support true real-time streaming —
# it needs a complete audio segment. For sub-second latency
# streaming, consider:
#   - whisper.cpp with server mode (streaming WebSocket)
#   - Vosk (much smaller, truly streaming, less accurate)
#   - A rolling buffer with 3-second windows + deduplication
#
# For Phase 1, the VAD-based "record then transcribe" approach
# gives the best accuracy/latency tradeoff.
# ─────────────────────────────────────────────────────────────

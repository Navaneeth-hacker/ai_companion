"""
audio/llm/llm_engine.py
========================
Local LLM interface via Ollama's REST API.

Architecture:
  - Subscribes to TranscriptionEvent.
  - Sends the user message + conversation context to Ollama.
  - Streams tokens back and publishes LLMStreamChunkEvent for each.
  - On completion publishes LLMResponseEvent (is_final=True).
  - Supports interrupt: InterruptEvent cancels the active HTTP stream.

Why Ollama?
  - Runs any GGUF model locally with one command.
  - Provides an OpenAI-compatible REST API.
  - Handles model loading, GPU offloading, and context management.
  - No Python binding maintenance; just HTTP.

Streaming pipeline to TTS:
  To minimize Time-To-First-Audio (TTFA), we don't wait for the full LLM
  response. Instead we accumulate text until we hit a sentence boundary
  (. ! ? \n), then send that sentence to TTS. This lets TTS start playing
  the first sentence while the LLM is still generating the rest.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Optional

import httpx
from loguru import logger

from core.events.event_bus import (
    EventBus,
    TranscriptionEvent,
    LLMResponseEvent,
    LLMStreamChunkEvent,
    InterruptEvent,
    SystemStatusEvent,
)
from core.context.context_manager import ContextManager


# Sentence boundary pattern — triggers TTS for accumulated text so far
SENTENCE_BOUNDARY = re.compile(r'(?<=[.!?])\s+|(?<=\n)')


class LLMEngine:
    """
    Async LLM interface via Ollama.

    Args:
        event_bus:       Shared EventBus.
        context_manager: Shared ContextManager.
        base_url:        Ollama API URL (default: http://localhost:11434).
        model:           Ollama model tag (e.g. "qwen2.5:7b").
        temperature:     Sampling temperature.
        top_p:           Top-p sampling.
        max_tokens:      Max tokens to generate.
        stream:          Enable token streaming.
        request_timeout: Seconds before giving up on the LLM.
    """

    def __init__(
        self,
        event_bus: EventBus,
        context_manager: ContextManager,
        base_url: str = "http://localhost:11434",
        model: str = "qwen2.5:7b",
        temperature: float = 0.7,
        top_p: float = 0.9,
        max_tokens: int = 512,
        stream: bool = True,
        request_timeout: float = 60.0,
    ) -> None:
        self._bus = event_bus
        self._ctx = context_manager
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._temperature = temperature
        self._top_p = top_p
        self._max_tokens = max_tokens
        self._stream = stream
        self._timeout = request_timeout

        self._client: Optional[httpx.AsyncClient] = None
        self._active_request: Optional[asyncio.Task] = None
        self._interrupt_flag = asyncio.Event()

        # Subscribe to events
        self._bus.subscribe(TranscriptionEvent, self._on_transcription)
        self._bus.subscribe(InterruptEvent, self._on_interrupt)

        logger.info(
            f"LLMEngine: model={model} base_url={base_url} "
            f"stream={stream} temp={temperature}"
        )

    # ── Public API ──────────────────────────────────────────

    async def start(self) -> None:
        """Initialize the async HTTP client and verify Ollama is reachable."""
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
        )
        await self._check_ollama_ready()
        await self._bus.publish(SystemStatusEvent("llm", "ready"))
        logger.info("LLMEngine: ready")

    async def stop(self) -> None:
        """Close HTTP client."""
        if self._active_request and not self._active_request.done():
            self._active_request.cancel()
        if self._client:
            await self._client.aclose()
        logger.info("LLMEngine: stopped")

    # ── Event handlers ──────────────────────────────────────

    async def _on_transcription(self, event: TranscriptionEvent) -> None:
        """Process a user's transcribed utterance."""
        text = event.text.strip()
        if not text:
            return

        # Cancel any in-flight request
        if self._active_request and not self._active_request.done():
            self._active_request.cancel()
            await asyncio.sleep(0.05)

        self._interrupt_flag.clear()

        logger.info(f"LLMEngine: user said: '{text}'")
        await self._ctx.add_user_message(text)
        await self._bus.publish(SystemStatusEvent("llm", "busy"))

        self._active_request = asyncio.create_task(
            self._generate_response()
        )

    async def _on_interrupt(self, event: InterruptEvent) -> None:
        """Cancel active generation on interrupt."""
        self._interrupt_flag.set()
        if self._active_request and not self._active_request.done():
            self._active_request.cancel()
            logger.info("LLMEngine: generation cancelled (interrupt)")
        await self._bus.publish(SystemStatusEvent("llm", "ready"))

    # ── Generation ──────────────────────────────────────────

    async def _generate_response(self) -> None:
        """
        Call Ollama /api/chat with streaming.

        Token streaming pipeline:
          - Accumulate tokens into a sentence buffer.
          - When a sentence boundary is detected, publish LLMStreamChunkEvent.
          - TTS subscribes to LLMStreamChunkEvent and starts speaking immediately.
          - On completion, add the full response to context.
        """
        messages = await self._ctx.get_messages()
        payload = {
            "model": self._model,
            "messages": messages,
            "stream": self._stream,
            "options": {
                "temperature": self._temperature,
                "top_p": self._top_p,
                "num_predict": self._max_tokens,
            },
        }

        t0 = time.time()
        full_response = ""
        sentence_buffer = ""
        chunk_seq = 0

        try:
            async with self._client.stream(
                "POST",
                "/api/chat",
                json=payload,
                timeout=self._timeout,
            ) as response:
                response.raise_for_status()

                async for line in response.aiter_lines():
                    if self._interrupt_flag.is_set():
                        logger.info("LLMEngine: stream interrupted")
                        break

                    if not line.strip():
                        continue

                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if data.get("done", False):
                        break

                    token = data.get("message", {}).get("content", "")
                    if not token:
                        continue

                    full_response += token
                    sentence_buffer += token

                    # Check for sentence boundary → flush to TTS
                    if SENTENCE_BOUNDARY.search(sentence_buffer):
                        parts = SENTENCE_BOUNDARY.split(sentence_buffer, maxsplit=1)
                        to_speak = parts[0].strip()
                        sentence_buffer = parts[1] if len(parts) > 1 else ""

                        if to_speak:
                            await self._bus.publish(
                                LLMStreamChunkEvent(
                                    chunk=to_speak,
                                    sequence=chunk_seq,
                                )
                            )
                            chunk_seq += 1

            # Flush remaining buffer
            if sentence_buffer.strip() and not self._interrupt_flag.is_set():
                await self._bus.publish(
                    LLMStreamChunkEvent(
                        chunk=sentence_buffer.strip(),
                        sequence=chunk_seq,
                    )
                )

            elapsed = time.time() - t0
            logger.info(
                f"LLMEngine: response generated in {elapsed:.2f}s | "
                f"~{len(full_response.split())} words"
            )

            if full_response.strip():
                await self._ctx.add_assistant_message(full_response)
                await self._bus.publish(
                    LLMResponseEvent(
                        text=full_response.strip(),
                        is_final=True,
                        timestamp=time.time(),
                    )
                )

        except asyncio.CancelledError:
            logger.info("LLMEngine: task cancelled")
        except httpx.HTTPStatusError as e:
            logger.error(f"LLMEngine: Ollama HTTP error: {e.response.status_code}")
            await self._bus.publish(SystemStatusEvent("llm", "error", str(e)))
        except httpx.ConnectError:
            logger.error("LLMEngine: cannot connect to Ollama. Is it running?")
            await self._bus.publish(
                SystemStatusEvent("llm", "error", "Cannot connect to Ollama")
            )
        except Exception as e:
            logger.error(f"LLMEngine: unexpected error: {e}", exc_info=True)
            await self._bus.publish(SystemStatusEvent("llm", "error", str(e)))
        finally:
            if not self._interrupt_flag.is_set():
                await self._bus.publish(SystemStatusEvent("llm", "ready"))

    # ── Utilities ────────────────────────────────────────────

    async def _check_ollama_ready(self) -> None:
        """Verify Ollama is running and the model is available."""
        try:
            resp = await self._client.get("/api/tags", timeout=5.0)
            resp.raise_for_status()
            tags = resp.json()
            model_names = [m["name"] for m in tags.get("models", [])]

            if self._model not in model_names:
                logger.warning(
                    f"LLMEngine: model '{self._model}' not found in Ollama. "
                    f"Available: {model_names}. "
                    f"Run: ollama pull {self._model}"
                )
            else:
                logger.info(f"LLMEngine: model '{self._model}' confirmed available")

        except httpx.ConnectError:
            logger.error(
                "LLMEngine: Ollama is not running! "
                "Start it with: ollama serve"
            )
        except Exception as e:
            logger.warning(f"LLMEngine: Ollama check failed: {e}")

    async def generate_direct(self, prompt: str) -> str:
        """
        One-shot generation without context or event bus.
        Used by other components (e.g. proactive suggestions).
        """
        payload = {
            "model": self._model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "options": {
                "temperature": self._temperature,
                "num_predict": self._max_tokens,
            },
        }
        resp = await self._client.post("/api/chat", json=payload, timeout=self._timeout)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "").strip()

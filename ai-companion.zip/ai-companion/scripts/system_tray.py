"""
scripts/system_tray.py
=======================
Windows system tray integration using pystray.

Provides:
  - Tray icon with status colour (green=ready, yellow=busy, red=error)
  - Right-click menu:
      Open Dashboard  → opens http://localhost:8765 in browser
      Mute            → toggles TTS output
      Interrupt       → sends POST /interrupt
      New Session     → clears conversation context
      Quit            → graceful shutdown

Runs in its own thread alongside the main pipeline.
Communicates with the API via localhost HTTP.

Usage (started by main.py automatically):
    from scripts.system_tray import SystemTrayApp
    tray = SystemTrayApp(api_port=8765)
    tray.start()     # Non-blocking; runs in daemon thread
    ...
    tray.stop()
"""

from __future__ import annotations

import threading
import webbrowser
from pathlib import Path
from typing import Optional

from loguru import logger

try:
    import pystray
    from PIL import Image, ImageDraw
    TRAY_AVAILABLE = True
except ImportError:
    TRAY_AVAILABLE = False


def _create_icon_image(color: str = "#22c55e", size: int = 64) -> "Image":
    """Generate a simple circular icon of the given colour."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.ellipse([(4, 4), (size - 4, size - 4)], fill=color)
    # Small white dot in the centre to suggest "active"
    draw.ellipse(
        [(size // 2 - 6, size // 2 - 6), (size // 2 + 6, size // 2 + 6)],
        fill="white",
    )
    return img


STATUS_COLORS = {
    "healthy": "#22c55e",
    "degraded": "#f59e0b",
    "error": "#ef4444",
    "offline": "#6b7280",
}


class SystemTrayApp:
    """
    System tray icon and menu for the AI companion.

    Args:
        api_port: Port the FastAPI gateway is running on.
        api_host: Host (default 127.0.0.1).
    """

    def __init__(self, api_port: int = 8765, api_host: str = "127.0.0.1") -> None:
        if not TRAY_AVAILABLE:
            logger.warning(
                "SystemTray: pystray or Pillow not installed — tray disabled. "
                "Run: pip install pystray Pillow"
            )
        self._api_base = f"http://{api_host}:{api_port}"
        self._api_port = api_port
        self._icon: Optional[pystray.Icon] = None
        self._thread: Optional[threading.Thread] = None
        self._muted = False
        self._current_status = "offline"

        logger.info(f"SystemTray: api={self._api_base}")

    # ── Public API ──────────────────────────────────────────

    def start(self) -> None:
        """Start the tray icon in a daemon thread."""
        if not TRAY_AVAILABLE:
            return
        self._thread = threading.Thread(
            target=self._run_tray,
            name="system-tray-thread",
            daemon=True,
        )
        self._thread.start()
        logger.info("SystemTray: started")

    def stop(self) -> None:
        """Stop the tray icon."""
        if self._icon:
            self._icon.stop()
        logger.info("SystemTray: stopped")

    def update_status(self, status: str) -> None:
        """Update icon colour based on pipeline status."""
        self._current_status = status
        if self._icon:
            color = STATUS_COLORS.get(status, "#6b7280")
            self._icon.icon = _create_icon_image(color)
            self._icon.title = f"AI Companion — {status}"

    # ── Internal ─────────────────────────────────────────────

    def _run_tray(self) -> None:
        menu = pystray.Menu(
            pystray.MenuItem("AI Companion", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Open Dashboard", self._open_dashboard),
            pystray.MenuItem("Open API Docs", self._open_docs),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                "Mute",
                self._toggle_mute,
                checked=lambda item: self._muted,
            ),
            pystray.MenuItem("Interrupt", self._interrupt),
            pystray.MenuItem("New Session", self._new_session),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", self._quit),
        )

        self._icon = pystray.Icon(
            name="ai_companion",
            icon=_create_icon_image("#6b7280"),   # Grey until connected
            title="AI Companion — starting",
            menu=menu,
        )
        self._icon.run()

    def _open_dashboard(self, icon, item) -> None:
        webbrowser.open(f"{self._api_base.replace('http', 'http')}:3000")

    def _open_docs(self, icon, item) -> None:
        webbrowser.open(f"{self._api_base}/docs")

    def _toggle_mute(self, icon, item) -> None:
        self._muted = not self._muted
        self._api_post("/speak" if not self._muted else "/interrupt", {})
        logger.info(f"SystemTray: mute={'on' if self._muted else 'off'}")

    def _interrupt(self, icon, item) -> None:
        self._api_post("/interrupt", {})

    def _new_session(self, icon, item) -> None:
        self._api_delete("/context")
        logger.info("SystemTray: new session started")

    def _quit(self, icon, item) -> None:
        logger.info("SystemTray: quit requested")
        icon.stop()
        import os, signal
        os.kill(os.getpid(), signal.SIGTERM)

    def _api_post(self, endpoint: str, data: dict) -> None:
        try:
            import urllib.request, json
            req = urllib.request.Request(
                self._api_base + endpoint,
                data=json.dumps(data).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception as e:
            logger.debug(f"SystemTray: API call failed: {e}")

    def _api_delete(self, endpoint: str) -> None:
        try:
            import urllib.request
            req = urllib.request.Request(
                self._api_base + endpoint, method="DELETE"
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception as e:
            logger.debug(f"SystemTray: API delete failed: {e}")

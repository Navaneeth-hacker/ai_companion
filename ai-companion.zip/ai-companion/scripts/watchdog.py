"""
scripts/watchdog.py
====================
Process watchdog for the AI Companion.

Monitors the main companion process and restarts it if it crashes,
with exponential backoff to avoid restart loops.

Also monitors:
  - Memory usage (restart if >2GB RAM — likely leak)
  - CPU usage (alert if sustained >90% for >60s)
  - Ollama connectivity (restart if unreachable for >30s)

Usage (standalone watchdog process):
  python scripts/watchdog.py

Or as a Windows scheduled task:
  python scripts/watchdog.py --daemon

The watchdog runs as a completely separate process from the companion,
so companion crashes don't affect it.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

import psutil
from loguru import logger
from rich.console import Console

ROOT = Path(__file__).resolve().parent.parent
MAIN_SCRIPT = str(ROOT / "main.py")
PYTHON = sys.executable

console = Console()


class Watchdog:
    """
    Process watchdog with health monitoring and auto-restart.

    Args:
        max_restarts:        Maximum restarts within restart_window_sec.
        restart_window_sec:  Window to count restarts within.
        backoff_base_sec:    Initial wait before restart (doubles each time).
        max_memory_mb:       Restart if companion exceeds this RAM usage.
        extra_args:          Additional CLI args passed to main.py.
    """

    def __init__(
        self,
        max_restarts: int = 5,
        restart_window_sec: int = 300,
        backoff_base_sec: float = 2.0,
        max_memory_mb: int = 2048,
        extra_args: list = None,
    ) -> None:
        self._max_restarts = max_restarts
        self._restart_window = restart_window_sec
        self._backoff_base = backoff_base_sec
        self._max_memory_bytes = max_memory_mb * 1024 * 1024
        self._extra_args = extra_args or []

        self._process: subprocess.Popen | None = None
        self._restart_times: list[float] = []
        self._total_restarts = 0
        self._start_time = time.time()

    def run(self) -> None:
        """Main watchdog loop. Blocks indefinitely."""
        logger.info("Watchdog: starting")
        console.print("[bold green]AI Companion Watchdog started[/]")

        while True:
            self._start_process()
            exit_code = self._monitor_process()

            if exit_code == 0:
                logger.info("Watchdog: companion exited cleanly (code 0). Stopping watchdog.")
                console.print("[green]Companion exited cleanly. Watchdog stopping.[/]")
                break

            logger.warning(f"Watchdog: companion exited with code {exit_code}")
            self._record_restart()

            # Check restart rate
            if self._is_restart_loop():
                logger.error(
                    f"Watchdog: {self._max_restarts} restarts in "
                    f"{self._restart_window}s — stopping to prevent loop."
                )
                console.print(
                    f"[red]Too many restarts ({self._max_restarts} in "
                    f"{self._restart_window}s). Manual intervention required.[/]"
                )
                break

            # Exponential backoff
            wait = self._backoff_base * (2 ** min(self._total_restarts - 1, 5))
            logger.info(f"Watchdog: waiting {wait:.1f}s before restart #{self._total_restarts + 1}")
            console.print(f"[yellow]Restarting in {wait:.1f}s...[/]")
            time.sleep(wait)

    def _start_process(self) -> None:
        cmd = [PYTHON, MAIN_SCRIPT, "--no-tray"] + self._extra_args
        logger.info(f"Watchdog: starting process: {' '.join(cmd)}")
        self._process = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            # Don't capture stdout/stderr — let it flow to console + loguru
        )
        logger.info(f"Watchdog: process started (PID {self._process.pid})")

    def _monitor_process(self) -> int:
        """
        Monitor the running process.
        Returns the exit code when the process terminates.
        Performs health checks every 10 seconds.
        """
        psutil_proc = None
        try:
            psutil_proc = psutil.Process(self._process.pid)
        except psutil.NoSuchProcess:
            pass

        consecutive_high_cpu = 0

        while True:
            # Check if process ended
            ret = self._process.poll()
            if ret is not None:
                return ret

            # Health checks
            if psutil_proc:
                try:
                    # Memory check
                    mem = psutil_proc.memory_info().rss
                    if mem > self._max_memory_bytes:
                        logger.warning(
                            f"Watchdog: memory too high "
                            f"({mem // 1024 // 1024}MB > "
                            f"{self._max_memory_bytes // 1024 // 1024}MB) — restarting"
                        )
                        psutil_proc.kill()
                        self._process.wait()
                        return -1

                    # CPU check
                    cpu = psutil_proc.cpu_percent(interval=None)
                    if cpu > 90:
                        consecutive_high_cpu += 1
                        if consecutive_high_cpu >= 6:   # 60s at 10s intervals
                            logger.warning(
                                f"Watchdog: sustained high CPU ({cpu:.0f}%) — "
                                "may be stuck. Restarting."
                            )
                            psutil_proc.kill()
                            self._process.wait()
                            return -2
                    else:
                        consecutive_high_cpu = 0

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            time.sleep(10)

    def _record_restart(self) -> None:
        now = time.time()
        self._restart_times.append(now)
        self._total_restarts += 1
        # Prune old entries outside the window
        cutoff = now - self._restart_window
        self._restart_times = [t for t in self._restart_times if t >= cutoff]

    def _is_restart_loop(self) -> bool:
        return len(self._restart_times) >= self._max_restarts


def main() -> None:
    p = argparse.ArgumentParser(description="AI Companion Watchdog")
    p.add_argument("--max-restarts", type=int, default=5)
    p.add_argument("--max-memory-mb", type=int, default=2048)
    p.add_argument("--no-wakeword", action="store_true")
    p.add_argument("--no-vision", action="store_true")
    args = p.parse_args()

    extra = []
    if args.no_wakeword:
        extra.append("--no-wakeword")
    if args.no_vision:
        extra.append("--no-vision")

    # Setup watchdog logging
    from loguru import logger as wdog_logger
    (ROOT / "logs").mkdir(exist_ok=True)
    wdog_logger.add(
        str(ROOT / "logs" / "watchdog.log"),
        rotation="5 MB", retention=3,
        level="INFO",
    )

    dog = Watchdog(
        max_restarts=args.max_restarts,
        max_memory_mb=args.max_memory_mb,
        extra_args=extra,
    )
    dog.run()


if __name__ == "__main__":
    main()

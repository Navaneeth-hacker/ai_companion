"""
scripts/debug_tools.py
======================
Debugging and diagnostic utilities for Phase 1.

Commands:
  python scripts/debug_tools.py list-audio     # List all audio devices
  python scripts/debug_tools.py test-mic       # Record 5 seconds, show waveform stats
  python scripts/debug_tools.py test-tts       # Synthesize and play a test sentence
  python scripts/debug_tools.py test-whisper   # Transcribe a test recording
  python scripts/debug_tools.py test-llm       # Send a test prompt to Ollama
  python scripts/debug_tools.py latency        # Measure end-to-end pipeline latency
  python scripts/debug_tools.py check-gpu      # GPU / CUDA diagnostics
  python scripts/debug_tools.py check-deps     # Verify all dependencies
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from rich.console import Console
from rich.table import Table

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
console = Console()


# ── Audio device listing ─────────────────────────────────────

def list_audio_devices() -> None:
    try:
        import pyaudio
        pa = pyaudio.PyAudio()
        count = pa.get_device_count()

        table = Table(title="Audio Devices")
        table.add_column("Index", style="cyan")
        table.add_column("Name")
        table.add_column("In Ch")
        table.add_column("Out Ch")
        table.add_column("Default SR")
        table.add_column("Type")

        default_in = pa.get_default_input_device_info().get("index", -1)
        default_out = pa.get_default_output_device_info().get("index", -1)

        for i in range(count):
            info = pa.get_device_info_by_index(i)
            name = info["name"]
            is_default = ""
            if i == default_in:
                is_default += " [IN DEFAULT]"
            if i == default_out:
                is_default += " [OUT DEFAULT]"
            table.add_row(
                str(i),
                name + is_default,
                str(int(info["maxInputChannels"])),
                str(int(info["maxOutputChannels"])),
                str(int(info["defaultSampleRate"])),
                "input" if info["maxInputChannels"] > 0 else "output",
            )

        pa.terminate()
        console.print(table)
        console.print(
            "\n[dim]Set input_device / output_device in config/settings.toml "
            "or config/local.toml to pin a specific device.[/]"
        )

    except ImportError:
        console.print("[red]pyaudio not installed[/]")


# ── Microphone test ──────────────────────────────────────────

def test_mic(duration: float = 5.0) -> None:
    console.print(f"\n[bold]Recording {duration}s from microphone...[/]")
    try:
        import numpy as np
        import pyaudio

        RATE = 16000
        CHUNK = 1024
        pa = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=RATE,
            input=True,
            frames_per_buffer=CHUNK,
        )

        frames = []
        n_chunks = int(RATE / CHUNK * duration)
        for i in range(n_chunks):
            data = stream.read(CHUNK, exception_on_overflow=False)
            frames.append(np.frombuffer(data, dtype=np.int16))

        stream.stop_stream()
        stream.close()
        pa.terminate()

        audio = np.concatenate(frames)
        rms = float(np.sqrt(np.mean(audio.astype(np.float32) ** 2)))
        peak = int(np.abs(audio).max())
        dc_offset = float(np.mean(audio))

        table = Table(title="Microphone Stats")
        table.add_column("Metric")
        table.add_column("Value")
        table.add_row("Duration", f"{duration:.1f}s")
        table.add_row("Sample rate", f"{RATE} Hz")
        table.add_row("Samples", str(len(audio)))
        table.add_row("RMS level", f"{rms:.1f}")
        table.add_row("Peak level", f"{peak} / 32767")
        table.add_row("DC offset", f"{dc_offset:.2f}")
        table.add_row(
            "Signal quality",
            "[green]GOOD[/]" if rms > 100 else "[yellow]LOW — check mic[/]"
        )
        console.print(table)

    except ImportError as e:
        console.print(f"[red]Missing dependency: {e}[/]")


# ── Latency profiler ─────────────────────────────────────────

def measure_latency() -> None:
    """Measure latency of each pipeline stage using test data."""
    console.print("\n[bold]Measuring pipeline latency...[/]")

    results = {}

    # STT latency
    try:
        import numpy as np
        from faster_whisper import WhisperModel

        console.print("  Loading Whisper base...")
        model = WhisperModel("base", device="cpu", compute_type="int8",
                             download_root=str(ROOT / "models" / "stt"))

        dummy_audio = np.zeros(16000 * 3, dtype=np.float32)  # 3s of silence
        t0 = time.perf_counter()
        list(model.transcribe(dummy_audio)[0])
        elapsed = time.perf_counter() - t0
        results["stt_3s_audio"] = f"{elapsed*1000:.0f}ms"
        del model

    except Exception as e:
        results["stt"] = f"ERROR: {e}"

    # LLM latency
    try:
        import httpx
        import asyncio

        async def _llm_latency():
            async with httpx.AsyncClient() as client:
                t0 = time.perf_counter()
                resp = await client.post(
                    "http://localhost:11434/api/generate",
                    json={"model": "qwen2.5:7b", "prompt": "Say hello.", "stream": False},
                    timeout=30,
                )
                elapsed = time.perf_counter() - t0
                if resp.status_code == 200:
                    return elapsed
                return None

        elapsed = asyncio.run(_llm_latency())
        if elapsed:
            results["llm_first_response"] = f"{elapsed*1000:.0f}ms"
        else:
            results["llm"] = "Ollama not running"

    except Exception as e:
        results["llm"] = f"ERROR: {e}"

    table = Table(title="Pipeline Latency")
    table.add_column("Stage")
    table.add_column("Latency")
    table.add_column("Target")
    table.add_column("Status")

    targets = {
        "stt_3s_audio": (800, "ms"),
        "llm_first_response": (400, "ms"),
    }

    for key, val in results.items():
        target = targets.get(key, (None, None))
        if target[0] and "ms" in val:
            measured = int(val.replace("ms", ""))
            ok = measured <= target[0]
            status = "[green]✓[/]" if ok else "[red]SLOW[/]"
        else:
            status = "[yellow]?[/]"
        table.add_row(key, val, f"≤{target[0]}ms" if target[0] else "-", status)

    console.print(table)


# ── GPU check ───────────────────────────────────────────────

def check_gpu() -> None:
    console.print("\n[bold]GPU Diagnostics[/]")

    try:
        import torch
        console.print(f"  PyTorch: {torch.__version__}")
        console.print(f"  CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            console.print(f"  CUDA version: {torch.version.cuda}")
            console.print(f"  GPU: {torch.cuda.get_device_name(0)}")
            props = torch.cuda.get_device_properties(0)
            console.print(f"  VRAM: {props.total_memory / 1e9:.1f} GB")
            free, total = torch.cuda.mem_get_info()
            console.print(f"  VRAM free: {free / 1e9:.1f} GB / {total / 1e9:.1f} GB")
    except ImportError:
        console.print("  [yellow]PyTorch not installed[/]")

    try:
        import ctranslate2
        console.print(f"\n  CTranslate2: {ctranslate2.__version__}")
        for device in ["cpu", "cuda"]:
            types = ctranslate2.get_supported_compute_types(device)
            console.print(f"  Supported compute types ({device}): {types}")
    except (ImportError, RuntimeError) as e:
        console.print(f"  [yellow]CTranslate2: {e}[/]")


# ── Dependency check ─────────────────────────────────────────

def check_deps() -> None:
    deps = [
        ("pyaudio", "PyAudio"),
        ("numpy", "NumPy"),
        ("openwakeword", "OpenWakeWord"),
        ("faster_whisper", "Faster-Whisper"),
        ("piper", "Piper TTS"),
        ("sounddevice", "sounddevice"),
        ("httpx", "httpx"),
        ("fastapi", "FastAPI"),
        ("uvicorn", "uvicorn"),
        ("loguru", "loguru"),
        ("pydantic", "pydantic"),
        ("sqlalchemy", "SQLAlchemy"),
    ]

    table = Table(title="Dependency Check")
    table.add_column("Package")
    table.add_column("Status")
    table.add_column("Version")

    for import_name, display_name in deps:
        try:
            mod = __import__(import_name)
            version = getattr(mod, "__version__", "?")
            table.add_row(display_name, "[green]✓[/]", version)
        except ImportError:
            table.add_row(display_name, "[red]✗ missing[/]", "-")

    console.print(table)


# ── Entry point ──────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description="AI Companion Debug Tools")
    p.add_argument(
        "command",
        choices=[
            "list-audio", "test-mic", "test-tts",
            "test-whisper", "test-llm", "latency",
            "check-gpu", "check-deps"
        ]
    )
    p.add_argument("--duration", type=float, default=5.0)
    args = p.parse_args()

    dispatch = {
        "list-audio": list_audio_devices,
        "test-mic": lambda: test_mic(args.duration),
        "latency": measure_latency,
        "check-gpu": check_gpu,
        "check-deps": check_deps,
    }

    fn = dispatch.get(args.command)
    if fn:
        fn()
    else:
        console.print(f"[yellow]{args.command} not yet implemented[/]")


if __name__ == "__main__":
    main()

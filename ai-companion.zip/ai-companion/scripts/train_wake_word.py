"""
scripts/train_wake_word.py
===========================
Custom wake word model training using OpenWakeWord.

This script guides you through training a custom "wake up" wake word model,
since OpenWakeWord's built-in models don't include "wake up" exactly.

Process:
  1. Record positive examples (you saying "wake up" ~100 times)
  2. Collect negative examples (other speech, background noise)
  3. Generate synthetic training data using text-to-speech augmentation
  4. Train the ONNX model using OWW's training pipeline
  5. Validate the model against a test set
  6. Export to models/wake_word/wake_up.onnx

Requirements:
  pip install openwakeword[training]
  (Additional: tensorflow >= 2.13 for training)

IMPORTANT: Training takes 30–60 minutes on a GPU,
           several hours on CPU. Use GPU if available.

Usage:
  # Step 1: Record samples
  python scripts/train_wake_word.py record --phrase "wake up" --samples 100

  # Step 2: Generate synthetic data (augment recordings)
  python scripts/train_wake_word.py augment

  # Step 3: Train the model
  python scripts/train_wake_word.py train

  # Step 4: Test the model
  python scripts/train_wake_word.py test

  # Step 5: Export
  python scripts/train_wake_word.py export
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import wave
from pathlib import Path

import numpy as np
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

console = Console()
DATA_DIR = ROOT / "data" / "wake_word_training"
POSITIVE_DIR = DATA_DIR / "positive"
NEGATIVE_DIR = DATA_DIR / "negative"
MODEL_DIR = ROOT / "models" / "wake_word"


# ── Record samples ────────────────────────────────────────────

def record_samples(phrase: str = "wake up", n_samples: int = 100) -> None:
    """
    Interactive recording session to collect positive wake word samples.
    """
    console.print(f"\n[bold]Recording '{phrase}' wake word samples[/]")
    console.print(
        f"You will be prompted to say [bold cyan]'{phrase}'[/] {n_samples} times.\n"
        f"Speak naturally — vary your tone, speed, and distance from the mic.\n"
        f"Press Enter before each recording. Press Ctrl+C to stop early.\n"
    )

    POSITIVE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        import pyaudio
    except ImportError:
        console.print("[red]pyaudio not installed. Run: pip install pyaudio[/]")
        return

    pa = pyaudio.PyAudio()
    RATE = 16000
    DURATION = 1.5  # seconds per sample
    CHUNK = 1024

    existing = list(POSITIVE_DIR.glob("*.wav"))
    start_idx = len(existing)

    for i in range(start_idx, start_idx + n_samples):
        try:
            input(f"  [{i+1}/{start_idx + n_samples}] Press Enter then say '{phrase}'...")
        except KeyboardInterrupt:
            console.print("\n[yellow]Recording stopped early.[/]")
            break

        stream = pa.open(
            format=pyaudio.paInt16, channels=1, rate=RATE,
            input=True, frames_per_buffer=CHUNK,
        )
        frames = []
        n_chunks = int(RATE / CHUNK * DURATION)
        for _ in range(n_chunks):
            frames.append(stream.read(CHUNK, exception_on_overflow=False))
        stream.stop_stream()
        stream.close()

        out_path = POSITIVE_DIR / f"positive_{i:04d}.wav"
        with wave.open(str(out_path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(RATE)
            wf.writeframes(b"".join(frames))

        console.print(f"  [green]✓[/] Saved {out_path.name}")

    pa.terminate()
    n_saved = len(list(POSITIVE_DIR.glob("*.wav")))
    console.print(
        f"\n[green]✓[/] {n_saved} positive samples saved to {POSITIVE_DIR}"
    )


# ── Augment with TTS synthesis ────────────────────────────────

def augment_with_tts(phrase: str = "wake up", count: int = 500) -> None:
    """
    Generate synthetic positive samples using multiple TTS voices.
    This dramatically improves robustness without 500 real recordings.
    """
    console.print(f"\n[bold]Generating {count} synthetic '{phrase}' samples via TTS...[/]")
    POSITIVE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        from piper.voice import PiperVoice
    except ImportError:
        console.print("[red]piper-tts not installed. Run: pip install piper-tts[/]")
        return

    tts_models_dir = ROOT / "models" / "tts"
    onnx_files = list(tts_models_dir.glob("*.onnx"))
    if not onnx_files:
        console.print(
            f"[red]No TTS models found in {tts_models_dir}.[/]\n"
            "Run: python scripts/download_models.py"
        )
        return

    import io, wave

    RATE = 16000
    existing = list(POSITIVE_DIR.glob("synth_*.wav"))
    start_idx = len(existing)

    with Progress(SpinnerColumn(), TextColumn("{task.description}")) as progress:
        task = progress.add_task(f"Synthesizing...", total=count)

        for i in range(start_idx, start_idx + count):
            model_path = onnx_files[i % len(onnx_files)]
            config_path = model_path.with_suffix(".onnx.json")
            if not config_path.exists():
                continue

            try:
                voice = PiperVoice.load(str(model_path), config_path=str(config_path))
                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(voice.config.sample_rate)
                    for chunk in voice.synthesize_stream_raw(phrase):
                        wf.writeframes(chunk)

                out_path = POSITIVE_DIR / f"synth_{i:05d}.wav"
                out_path.write_bytes(buf.getvalue())
                progress.advance(task)

            except Exception as e:
                console.print(f"[yellow]TTS error for sample {i}: {e}[/]")

    n_total = len(list(POSITIVE_DIR.glob("*.wav")))
    console.print(f"[green]✓[/] {n_total} total positive samples ready")


# ── Train ──────────────────────────────────────────────────────

def train_model(phrase: str = "wake_up") -> None:
    """
    Train the ONNX wake word model using OWW's training pipeline.
    """
    console.print(f"\n[bold]Training wake word model...[/]")

    n_positive = len(list(POSITIVE_DIR.glob("*.wav")))
    if n_positive < 50:
        console.print(
            f"[red]Only {n_positive} positive samples. Need at least 50.[/]\n"
            "Run the record and augment steps first."
        )
        return

    try:
        import openwakeword
    except ImportError:
        console.print("[red]openwakeword not installed. Run: pip install openwakeword[training][/]")
        return

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model_tag = phrase.replace(" ", "_")

    console.print(
        f"Positive samples: {n_positive}\n"
        f"Output: {MODEL_DIR / model_tag}.onnx\n"
    )

    # OWW training uses its own CLI / API
    # This calls the OWW training script with our data
    try:
        from openwakeword.train import train

        train(
            model_name=model_tag,
            positive_reference_clips=str(POSITIVE_DIR),
            negative_reference_clips=str(NEGATIVE_DIR) if NEGATIVE_DIR.exists() else None,
            output_dir=str(MODEL_DIR),
            training_steps=10000,
            learning_rate=1e-3,
            batch_size=64,
        )
        console.print(f"[green]✓[/] Model trained: {MODEL_DIR / model_tag}.onnx")
        console.print(
            f"\nUpdate config/settings.toml:\n"
            f"  [wake_word]\n"
            f"  model_name = \"{MODEL_DIR / model_tag}.onnx\""
        )

    except ImportError:
        console.print(
            "[yellow]OWW training API not available in this version.[/]\n"
            "Use the OWW training notebook instead:\n"
            "https://github.com/dscripka/openWakeWord/blob/main/notebooks/Train_Custom_Model.ipynb"
        )
    except Exception as e:
        console.print(f"[red]Training failed: {e}[/]")


# ── Test ───────────────────────────────────────────────────────

def test_model(model_path: str = None) -> None:
    """Live test of the trained model via microphone."""
    if model_path is None:
        candidates = list(MODEL_DIR.glob("*.onnx"))
        if not candidates:
            console.print("[red]No custom model found. Train one first.[/]")
            return
        model_path = str(candidates[0])

    console.print(f"\n[bold]Testing model: {model_path}[/]")
    console.print("Say the wake word — press Ctrl+C to stop.\n")

    try:
        from openwakeword.model import Model
        import pyaudio

        oww = Model(wakeword_models=[model_path], inference_framework="onnx")
        pa = pyaudio.PyAudio()
        stream = pa.open(
            format=pyaudio.paInt16, channels=1, rate=16000,
            input=True, frames_per_buffer=1280,
        )

        while True:
            raw = stream.read(1280, exception_on_overflow=False)
            audio = np.frombuffer(raw, dtype=np.int16)
            predictions = oww.predict(audio)
            for name, score in predictions.items():
                bar = "█" * int(score * 30)
                if score >= 0.5:
                    console.print(f"[green]DETECTED[/] {name}: {score:.3f} {bar}")
                else:
                    print(f"  {name}: {score:.3f} {bar}", end="\r")

    except KeyboardInterrupt:
        console.print("\n[yellow]Test stopped.[/]")
    finally:
        try:
            stream.stop_stream()
            stream.close()
            pa.terminate()
        except Exception:
            pass


# ── Entry point ───────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description="Wake Word Training Pipeline")
    sub = p.add_subparsers(dest="command")

    rec = sub.add_parser("record", help="Record positive samples via microphone")
    rec.add_argument("--phrase", default="wake up")
    rec.add_argument("--samples", type=int, default=100)

    aug = sub.add_parser("augment", help="Generate synthetic TTS samples")
    aug.add_argument("--phrase", default="wake up")
    aug.add_argument("--count", type=int, default=500)

    tr = sub.add_parser("train", help="Train the wake word model")
    tr.add_argument("--phrase", default="wake_up")

    ts = sub.add_parser("test", help="Live-test the trained model")
    ts.add_argument("--model", default=None)

    args = p.parse_args()

    if args.command == "record":
        record_samples(args.phrase, args.samples)
    elif args.command == "augment":
        augment_with_tts(args.phrase, args.count)
    elif args.command == "train":
        train_model(args.phrase)
    elif args.command == "test":
        test_model(args.model)
    else:
        p.print_help()


if __name__ == "__main__":
    main()

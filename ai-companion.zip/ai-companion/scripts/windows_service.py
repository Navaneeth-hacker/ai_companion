"""
scripts/windows_service.py
============================
Windows service wrapper for the AI companion.

Two deployment modes:

MODE 1 — NSSM (Non-Sucking Service Manager) — RECOMMENDED
  NSSM wraps any executable as a Windows service with restart-on-crash.
  Installation:
    1. Download nssm from https://nssm.cc/download
    2. Run: python scripts/windows_service.py install
    3. Run: python scripts/windows_service.py start

  This is preferred over pywin32 service because:
    - No need to compile a service binary.
    - NSSM handles stdout/stderr redirection.
    - Easy uninstall.
    - Works with virtual environments.

MODE 2 — Startup Registry (simpler, no service)
  Adds the companion to HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
  So it starts when the user logs in (not as a system service).
  Run: python scripts/windows_service.py startup-register

MODE 3 — Task Scheduler
  Creates a scheduled task that runs on login.
  Run: python scripts/windows_service.py task-register

Usage:
  python scripts/windows_service.py install      # Install NSSM service
  python scripts/windows_service.py uninstall    # Remove NSSM service
  python scripts/windows_service.py start        # Start service
  python scripts/windows_service.py stop         # Stop service
  python scripts/windows_service.py status       # Show service status
  python scripts/windows_service.py startup-register   # Add to startup
  python scripts/windows_service.py startup-remove     # Remove from startup
  python scripts/windows_service.py task-register      # Task Scheduler
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

console = Console()
ROOT = Path(__file__).resolve().parent.parent
SERVICE_NAME = "AICompanion"
DISPLAY_NAME = "AI Companion Service"
DESCRIPTION = "Local AI productivity companion with voice, vision, and automation."

PYTHON = sys.executable
MAIN_SCRIPT = str(ROOT / "main.py")


@click.group()
def cli():
    """AI Companion Windows Service Manager"""
    pass


# ── NSSM service management ──────────────────────────────────

@cli.command()
def install():
    """Install the companion as a Windows service via NSSM."""
    nssm = _find_nssm()
    if not nssm:
        console.print(
            "[red]NSSM not found.[/]\n"
            "Download from https://nssm.cc/download\n"
            "Place nssm.exe in your PATH or in the project root."
        )
        return

    console.print(f"Installing service '{SERVICE_NAME}'...")
    _run(nssm, "install", SERVICE_NAME, PYTHON)
    _run(nssm, "set", SERVICE_NAME, "AppParameters", MAIN_SCRIPT)
    _run(nssm, "set", SERVICE_NAME, "AppDirectory", str(ROOT))
    _run(nssm, "set", SERVICE_NAME, "DisplayName", DISPLAY_NAME)
    _run(nssm, "set", SERVICE_NAME, "Description", DESCRIPTION)
    _run(nssm, "set", SERVICE_NAME, "Start", "SERVICE_AUTO_START")
    _run(nssm, "set", SERVICE_NAME, "AppRestartDelay", "5000")   # 5s restart delay
    _run(nssm, "set", SERVICE_NAME, "AppStdout",
         str(ROOT / "logs" / "service_stdout.log"))
    _run(nssm, "set", SERVICE_NAME, "AppStderr",
         str(ROOT / "logs" / "service_stderr.log"))
    console.print(f"[green]✓[/] Service installed. Run: python scripts/windows_service.py start")


@cli.command()
def uninstall():
    """Remove the NSSM service."""
    nssm = _find_nssm()
    if not nssm:
        console.print("[red]NSSM not found.[/]")
        return
    _run(nssm, "remove", SERVICE_NAME, "confirm")
    console.print(f"[green]✓[/] Service '{SERVICE_NAME}' removed.")


@cli.command()
def start():
    """Start the AI Companion service."""
    nssm = _find_nssm()
    if nssm:
        _run(nssm, "start", SERVICE_NAME)
    else:
        _run("sc", "start", SERVICE_NAME)


@cli.command()
def stop():
    """Stop the AI Companion service."""
    nssm = _find_nssm()
    if nssm:
        _run(nssm, "stop", SERVICE_NAME)
    else:
        _run("sc", "stop", SERVICE_NAME)


@cli.command()
def status():
    """Show current service status."""
    try:
        result = subprocess.run(
            ["sc", "query", SERVICE_NAME],
            capture_output=True, text=True
        )
        console.print(result.stdout)
    except Exception as e:
        console.print(f"[red]Error: {e}[/]")


# ── Startup registry ─────────────────────────────────────────

@cli.command("startup-register")
def startup_register():
    """Add to Windows startup via registry (runs on user login)."""
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE,
        )
        cmd = f'"{PYTHON}" "{MAIN_SCRIPT}"'
        winreg.SetValueEx(key, SERVICE_NAME, 0, winreg.REG_SZ, cmd)
        winreg.CloseKey(key)
        console.print(f"[green]✓[/] Added to startup: {cmd}")
    except ImportError:
        console.print("[red]winreg not available (Windows only)[/]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/]")


@cli.command("startup-remove")
def startup_remove():
    """Remove from Windows startup registry."""
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE,
        )
        try:
            winreg.DeleteValue(key, SERVICE_NAME)
            console.print(f"[green]✓[/] Removed from startup.")
        except FileNotFoundError:
            console.print("[yellow]Not found in startup registry.[/]")
        winreg.CloseKey(key)
    except ImportError:
        console.print("[red]winreg not available[/]")


# ── Task Scheduler ───────────────────────────────────────────

@cli.command("task-register")
def task_register():
    """Create a Task Scheduler task that starts companion on login."""
    task_xml = f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <Delay>PT10S</Delay>
    </LogonTrigger>
  </Triggers>
  <Actions Context="Author">
    <Exec>
      <Command>{PYTHON}</Command>
      <Arguments>"{MAIN_SCRIPT}"</Arguments>
      <WorkingDirectory>{ROOT}</WorkingDirectory>
    </Exec>
  </Actions>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
</Task>"""

    xml_path = ROOT / "installer" / "task.xml"
    xml_path.parent.mkdir(exist_ok=True)
    xml_path.write_text(task_xml, encoding="utf-16")

    try:
        result = subprocess.run(
            ["schtasks", "/create", "/tn", SERVICE_NAME,
             "/xml", str(xml_path), "/f"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            console.print(f"[green]✓[/] Scheduled task '{SERVICE_NAME}' created.")
        else:
            console.print(f"[red]schtasks error: {result.stderr}[/]")
    except FileNotFoundError:
        console.print("[red]schtasks not found (Windows only)[/]")


# ── Helpers ──────────────────────────────────────────────────

def _find_nssm() -> str | None:
    """Find nssm.exe in PATH or project root."""
    for candidate in ["nssm", str(ROOT / "nssm.exe"), str(ROOT / "installer" / "nssm.exe")]:
        try:
            subprocess.run([candidate, "version"], capture_output=True, timeout=3)
            return candidate
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


def _run(*args) -> None:
    result = subprocess.run(list(args), capture_output=False)
    if result.returncode != 0:
        console.print(f"[yellow]Command returned {result.returncode}[/]")


if __name__ == "__main__":
    cli()

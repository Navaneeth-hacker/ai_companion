"""
scripts/download_models.py
===========================
Downloads all required models for Phase 1.

Models downloaded:
  1. Faster-Whisper: base / small / medium (Hugging Face CTranslate2 format)
  2. Piper TTS:      en_US-lessac-medium (Amy-like voice)
  3. OpenWakeWord:   hey_jarvis (OWW pulls its own models automatically)
  4. Ollama:         qwen2.5:7b (via ollama pull command)

Run this once after installation:
  python scripts/download_models.py

Or with specific models:
  python scripts/download_models.py --whisper small --no-ollama
"""

from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen, urlretrieve

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TransferSpeedColumn

console = Console()
ROOT = Path(__file__).resolve().parent.parent
MODELS_DIR = ROOT / "models"


# ── Piper TTS model registry ────────────────────────────────
PIPER_BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main"
PIPER_MODELS = {
    "en_US-lessac-medium": {
        "onnx": f"{PIPER_BASE}/en/en_US/lessac/medium/en_US-lessac-medium.onnx",
        "json": f"{PIPER_BASE}/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json",
        "size_mb": 63,
    },
    "en_US-amy-medium": {
        "onnx": f"{PIPER_BASE}/en/en_US/amy/medium/en_US-amy-medium.onnx",
        "json": f"{PIPER_BASE}/en/en_US/amy/medium/en_US-amy-medium.onnx.json",
        "size_mb": 63,
    },
    "en_GB-alan-medium": {
        "onnx": f"{PIPER_BASE}/en/en_GB/alan/medium/en_GB-alan-medium.onnx",
        "json": f"{PIPER_BASE}/en/en_GB/alan/medium/en_GB-alan-medium.onnx.json",
        "size_mb": 63,
    },
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--whisper", default="base",
                   choices=["tiny", "base", "small", "medium", "large-v3"])
    p.add_argument("--piper-voice", default="en_US-lessac-medium")
    p.add_argument("--ollama-model", default="qwen2.5:7b")
    p.add_argument("--no-ollama", action="store_true")
    p.add_argument("--no-whisper", action="store_true")
    p.add_argument("--no-piper", action="store_true")
    return p.parse_args()


def download_file(url: str, dest: Path, description: str = "") -> bool:
    """Download a file with a Rich progress bar."""
    dest.parent.mkdir(parents=True, exist_ok=True)

    if dest.exists():
        console.print(f"  [dim]Already exists: {dest.name}[/]")
        return True

    console.print(f"  Downloading: [cyan]{description or dest.name}[/]")

    try:
        def reporthook(count, block_size, total_size):
            pass   # Rich handles progress separately

        urlretrieve(url, str(dest))
        console.print(f"  [green]✓[/] {dest.name}")
        return True

    except Exception as e:
        console.print(f"  [red]✗ Failed: {e}[/]")
        if dest.exists():
            dest.unlink()
        return False


def download_whisper(model: str) -> None:
    """
    Faster-Whisper models are downloaded automatically on first use
    via the WhisperModel constructor. We trigger that here.
    """
    console.print(f"\n[bold]Downloading Faster-Whisper ({model})...[/]")
    dest_dir = MODELS_DIR / "stt"
    dest_dir.mkdir(parents=True, exist_ok=True)

    try:
        from faster_whisper import WhisperModel
        console.print(f"  Loading model (may take a moment)...")
        m = WhisperModel(model, device="cpu", compute_type="int8",
                         download_root=str(dest_dir))
        # Run a dummy inference to confirm it works
        import numpy as np
        dummy = np.zeros(16000, dtype=np.float32)
        list(m.transcribe(dummy)[0])   # Materialize the lazy iterator
        del m
        console.print(f"  [green]✓[/] Whisper {model} ready")
    except ImportError:
        console.print("  [red]faster-whisper not installed. Run: pip install faster-whisper[/]")
    except Exception as e:
        console.print(f"  [red]✗ Whisper download failed: {e}[/]")


def download_piper(voice_name: str) -> None:
    """Download Piper TTS voice model."""
    console.print(f"\n[bold]Downloading Piper TTS voice ({voice_name})...[/]")

    if voice_name not in PIPER_MODELS:
        console.print(f"  [red]Unknown voice: {voice_name}[/]")
        console.print(f"  Available: {list(PIPER_MODELS.keys())}")
        return

    tts_dir = MODELS_DIR / "tts"
    tts_dir.mkdir(parents=True, exist_ok=True)

    model_info = PIPER_MODELS[voice_name]
    onnx_dest = tts_dir / f"{voice_name}.onnx"
    json_dest = tts_dir / f"{voice_name}.onnx.json"

    download_file(model_info["onnx"], onnx_dest, f"{voice_name}.onnx")
    download_file(model_info["json"], json_dest, f"{voice_name}.onnx.json")


def download_ollama_model(model: str) -> None:
    """Pull an Ollama model (requires ollama to be running)."""
    console.print(f"\n[bold]Pulling Ollama model ({model})...[/]")

    try:
        result = subprocess.run(
            ["ollama", "pull", model],
            check=True,
            timeout=600,    # 10 min for large models
        )
        console.print(f"  [green]✓[/] {model} ready")
    except FileNotFoundError:
        console.print(
            "  [red]Ollama not found.[/]\n"
            "  Install from: https://ollama.ai/download\n"
            "  Then run: ollama pull " + model
        )
    except subprocess.CalledProcessError as e:
        console.print(
            f"  [red]ollama pull failed.[/]\n"
            "  Is Ollama running? Start it with: ollama serve"
        )
    except subprocess.TimeoutExpired:
        console.print("  [yellow]Ollama pull is taking a long time. "
                      "Check progress in the Ollama window.[/]")


def check_openwakeword() -> None:
    """OWW downloads its models automatically; just verify the import."""
    console.print("\n[bold]Checking OpenWakeWord...[/]")
    try:
        from openwakeword.model import Model
        m = Model(wakeword_models=["hey_jarvis"], inference_framework="onnx")
        del m
        console.print("  [green]✓[/] OpenWakeWord ready (hey_jarvis model loaded)")
    except ImportError:
        console.print("  [red]openwakeword not installed. Run: pip install openwakeword[/]")
    except Exception as e:
        console.print(f"  [yellow]OWW check warning: {e}[/]")


def main() -> None:
    args = parse_args()

    console.print("[bold green]AI Companion — Model Downloader[/]\n")

    if not args.no_whisper:
        download_whisper(args.whisper)

    if not args.no_piper:
        download_piper(args.piper_voice)

    check_openwakeword()

    if not args.no_ollama:
        download_ollama_model(args.ollama_model)

    console.print("\n[bold green]✓ All models ready.[/]")
    console.print("\nStart the companion with:")
    console.print("  [cyan]python main.py[/]")


if __name__ == "__main__":
    main()

"""
scripts/setup_windows.py
========================
Windows 11 setup assistant.

What this does:
  1. Checks Python version (3.10+ required).
  2. Detects NVIDIA GPU and CUDA version.
  3. Installs the correct onnxruntime variant (GPU or CPU).
  4. Installs all pip requirements.
  5. Checks for Ollama installation.
  6. Downloads the Piper binary.
  7. Creates required directories.
  8. Generates a .env file with detected settings.

Run as:
  python scripts/setup_windows.py

Then:
  python scripts/download_models.py
  python main.py
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()
ROOT = Path(__file__).resolve().parent.parent


def check_python() -> bool:
    v = sys.version_info
    ok = v >= (3, 10)
    status = "[green]✓[/]" if ok else "[red]✗[/]"
    console.print(
        f"{status} Python {v.major}.{v.minor}.{v.micro}"
        + (" (OK)" if ok else " — REQUIRES 3.10+")
    )
    return ok


def detect_cuda() -> tuple[bool, str]:
    """Returns (has_cuda, cuda_version_string)."""
    # Method 1: nvidia-smi
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            line = result.stdout.strip().split("\n")[0]
            gpu_name = line.split(",")[0].strip()
            console.print(f"  [green]✓[/] NVIDIA GPU detected: {gpu_name}")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        console.print("  [yellow]nvidia-smi not found[/]")

    # Method 2: nvcc
    try:
        result = subprocess.run(
            ["nvcc", "--version"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if "release" in line.lower():
                    version = line.split("release")[-1].split(",")[0].strip()
                    console.print(f"  [green]✓[/] CUDA version: {version}")
                    return True, version
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Method 3: torch (if already installed)
    try:
        import torch
        if torch.cuda.is_available():
            v = torch.version.cuda
            console.print(f"  [green]✓[/] CUDA via PyTorch: {v}")
            return True, v
    except ImportError:
        pass

    console.print("  [yellow]CUDA not detected — will use CPU mode[/]")
    return False, ""


def install_requirements(has_cuda: bool) -> None:
    """Install pip requirements with appropriate onnxruntime variant."""
    console.print("\n[bold]Installing Python requirements...[/]")

    # Install base requirements
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r",
         str(ROOT / "requirements.txt"), "--quiet"],
        capture_output=False
    )
    if result.returncode != 0:
        console.print("[red]pip install failed. Check errors above.[/]")
        return

    # Install GPU-accelerated onnxruntime if CUDA available
    if has_cuda:
        console.print("  Installing onnxruntime-gpu...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "onnxruntime-gpu==1.18.0", "--quiet"],
        )
        console.print("  [green]✓[/] onnxruntime-gpu installed")
    else:
        console.print("  [dim]Using onnxruntime (CPU)[/]")

    # Install faster-whisper with CUDA if available
    if has_cuda:
        console.print("  Installing CTranslate2 (GPU)...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "ctranslate2", "--upgrade", "--quiet"],
        )

    console.print("[green]✓[/] Requirements installed")


def check_ollama() -> bool:
    """Check if Ollama is installed."""
    console.print("\n[bold]Checking Ollama...[/]")
    try:
        result = subprocess.run(
            ["ollama", "version"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            console.print(f"  [green]✓[/] Ollama installed: {version}")
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    console.print(
        "  [red]✗ Ollama not found[/]\n"
        "  Install from: https://ollama.ai/download\n"
        "  Then restart this script."
    )
    return False


def download_piper_binary() -> None:
    """Download the Piper binary for Windows."""
    import urllib.request
    import zipfile

    piper_dir = ROOT / "models" / "piper_bin"
    piper_exe = piper_dir / "piper.exe"

    if piper_exe.exists():
        console.print(f"  [dim]Piper binary already exists[/]")
        return

    piper_dir.mkdir(parents=True, exist_ok=True)

    # Piper releases on GitHub
    url = (
        "https://github.com/rhasspy/piper/releases/download/"
        "2023.11.14-2/piper_windows_amd64.zip"
    )

    zip_path = piper_dir / "piper.zip"
    console.print(f"  Downloading Piper binary...")

    try:
        urllib.request.urlretrieve(url, str(zip_path))
        with zipfile.ZipFile(str(zip_path), "r") as zf:
            zf.extractall(str(piper_dir))
        zip_path.unlink()
        console.print(f"  [green]✓[/] Piper binary at {piper_exe}")
    except Exception as e:
        console.print(f"  [red]✗ Failed to download Piper: {e}[/]")


def create_env_file(has_cuda: bool) -> None:
    """Write a .env file with detected settings."""
    env_path = ROOT / ".env"
    if env_path.exists():
        console.print("  [dim].env already exists — skipping[/]")
        return

    piper_bin = ROOT / "models" / "piper_bin" / "piper.exe"
    lines = [
        "# AI Companion environment settings",
        "# Generated by setup_windows.py — customize as needed",
        "",
        f"AI_COMPANION_APP__DEBUG=false",
        f"AI_COMPANION_STT__DEVICE={'cuda' if has_cuda else 'cpu'}",
        f"AI_COMPANION_STT__COMPUTE_TYPE={'float16' if has_cuda else 'int8'}",
        f"PIPER_BINARY={piper_bin}",
        "",
    ]
    env_path.write_text("\n".join(lines))
    console.print(f"  [green]✓[/] Created .env")


def create_directories() -> None:
    """Ensure all runtime directories exist."""
    dirs = [
        ROOT / "logs",
        ROOT / "data",
        ROOT / "models" / "stt",
        ROOT / "models" / "tts",
        ROOT / "models" / "tts",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    console.print(f"  [green]✓[/] Directories created")


def print_next_steps() -> None:
    console.print(
        Panel(
            "[bold]Setup complete! Next steps:[/]\n\n"
            "1. Start Ollama:\n"
            "   [cyan]ollama serve[/]\n\n"
            "2. Download models:\n"
            "   [cyan]python scripts/download_models.py[/]\n\n"
            "3. Start the companion:\n"
            "   [cyan]python main.py[/]\n\n"
            "4. Open the API dashboard:\n"
            "   [cyan]http://localhost:8765/docs[/]\n\n"
            "Say '[bold]wake up[/]' to activate voice input.",
            title="[bold green]Ready[/]",
            border_style="green",
        )
    )


def main() -> None:
    if platform.system() != "Windows":
        console.print(
            "[yellow]Warning: this script is designed for Windows. "
            "Continuing anyway...[/]"
        )

    console.print("[bold green]AI Companion — Windows Setup[/]\n")

    console.print("[bold]1. Python check[/]")
    if not check_python():
        console.print(
            "[red]Install Python 3.10+ from https://python.org[/]"
        )
        sys.exit(1)

    console.print("\n[bold]2. CUDA detection[/]")
    has_cuda, cuda_version = detect_cuda()

    console.print("\n[bold]3. Installing requirements[/]")
    install_requirements(has_cuda)

    console.print("\n[bold]4. Ollama check[/]")
    check_ollama()

    console.print("\n[bold]5. Piper TTS binary[/]")
    download_piper_binary()

    console.print("\n[bold]6. Directories[/]")
    create_directories()

    console.print("\n[bold]7. Environment file[/]")
    create_env_file(has_cuda)

    print_next_steps()


if __name__ == "__main__":
    main()

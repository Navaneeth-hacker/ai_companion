"""
scripts/benchmark.py
=====================
Pipeline latency benchmark tool.

Measures:
  - STT: transcription latency (Whisper) across audio lengths
  - LLM: time-to-first-token and total generation latency
  - TTS: synthesis latency (Piper)
  - E2E: full wake-word-to-audio-start latency (simulated)
  - Memory: ChromaDB query latency

Reports: mean, p50, p95, p99 across N runs.

Usage:
  python scripts/benchmark.py
  python scripts/benchmark.py --runs 20
  python scripts/benchmark.py --stage stt
  python scripts/benchmark.py --stage llm --model qwen2.5:7b
"""

from __future__ import annotations

import argparse
import asyncio
import statistics
import sys
import time
from pathlib import Path

import numpy as np
from rich.console import Console
from rich.table import Table

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

console = Console()


def _percentile(data: list, p: float) -> float:
    if not data:
        return 0.0
    sorted_data = sorted(data)
    idx = int(len(sorted_data) * p / 100)
    return sorted_data[min(idx, len(sorted_data) - 1)]


def _print_results(stage: str, timings_ms: list) -> None:
    if not timings_ms:
        console.print(f"[red]{stage}: No results[/]")
        return

    table = Table(title=f"{stage} Benchmark ({len(timings_ms)} runs)")
    table.add_column("Metric", style="cyan")
    table.add_column("Value (ms)", justify="right")
    table.add_column("Rating", justify="center")

    mean = statistics.mean(timings_ms)
    p50 = _percentile(timings_ms, 50)
    p95 = _percentile(timings_ms, 95)
    p99 = _percentile(timings_ms, 99)
    min_v = min(timings_ms)
    max_v = max(timings_ms)

    targets = {"STT": 800, "LLM TTFT": 400, "TTS": 300, "Memory": 50}
    target = targets.get(stage, 1000)

    def rate(v):
        if v <= target: return "[green]✓ FAST[/]"
        if v <= target * 2: return "[yellow]~ OK[/]"
        return "[red]✗ SLOW[/]"

    for label, value in [("Mean", mean), ("P50", p50), ("P95", p95),
                          ("P99", p99), ("Min", min_v), ("Max", max_v)]:
        table.add_row(label, f"{value:.0f}", rate(value))

    console.print(table)


# ── STT benchmark ─────────────────────────────────────────────

def bench_stt(runs: int = 10, model: str = "base") -> None:
    console.print(f"\n[bold]Benchmarking STT (Whisper {model})...[/]")

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        console.print("[red]faster-whisper not installed[/]")
        return

    m = WhisperModel(model, device="cpu", compute_type="int8",
                     download_root=str(ROOT / "models" / "stt"))

    # Test with different audio lengths
    for dur_sec in [1, 3, 5]:
        timings = []
        audio = np.zeros(16000 * dur_sec, dtype=np.float32)  # Silence

        for _ in range(runs):
            t0 = time.perf_counter()
            list(m.transcribe(audio)[0])
            timings.append((time.perf_counter() - t0) * 1000)

        _print_results(f"STT ({dur_sec}s audio)", timings)

    del m


# ── LLM benchmark ─────────────────────────────────────────────

async def bench_llm(runs: int = 5, model: str = "qwen2.5:7b") -> None:
    console.print(f"\n[bold]Benchmarking LLM ({model})...[/]")

    import httpx
    ttft_timings = []
    total_timings = []

    prompts = [
        "Say 'hello' in one word.",
        "What is 2 + 2?",
        "Name one productivity technique.",
    ]

    async with httpx.AsyncClient() as client:
        for i in range(runs):
            prompt = prompts[i % len(prompts)]
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": True,
                "options": {"num_predict": 50},
            }

            t_start = time.perf_counter()
            first_token = None

            try:
                async with client.stream("POST", "http://localhost:11434/api/generate",
                                         json=payload, timeout=60) as resp:
                    async for line in resp.aiter_lines():
                        if not line: continue
                        import json
                        data = json.loads(line)
                        if data.get("response") and first_token is None:
                            first_token = (time.perf_counter() - t_start) * 1000
                        if data.get("done"): break

                total = (time.perf_counter() - t_start) * 1000
                if first_token: ttft_timings.append(first_token)
                total_timings.append(total)

            except Exception as e:
                console.print(f"[red]LLM run {i}: {e}[/]")

    _print_results("LLM TTFT", ttft_timings)
    _print_results("LLM Total", total_timings)


# ── TTS benchmark ─────────────────────────────────────────────

def bench_tts(runs: int = 10) -> None:
    console.print(f"\n[bold]Benchmarking TTS (Piper)...[/]")

    model_path = ROOT / "models" / "tts" / "en_US-lessac-medium.onnx"
    if not model_path.exists():
        console.print(f"[yellow]TTS model not found: {model_path}[/]")
        console.print("Run: python scripts/download_models.py")
        return

    try:
        from piper.voice import PiperVoice
    except ImportError:
        console.print("[red]piper-tts not installed[/]")
        return

    voice = PiperVoice.load(
        str(model_path),
        config_path=str(model_path.with_suffix(".onnx.json")),
    )

    test_texts = [
        "Hello.",
        "You have been distracted for five minutes.",
        "Your productivity score is seventy-two out of one hundred. "
        "You spent most of the morning coding, which is good.",
    ]

    for text in test_texts:
        timings = []
        for _ in range(runs):
            t0 = time.perf_counter()
            import io, wave
            buf = io.BytesIO()
            with wave.open(buf, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(voice.config.sample_rate)
                for chunk in voice.synthesize_stream_raw(text):
                    wf.writeframes(chunk)
            timings.append((time.perf_counter() - t0) * 1000)

        _print_results(f"TTS ({len(text)} chars)", timings)


# ── Memory benchmark ──────────────────────────────────────────

async def bench_memory(runs: int = 20) -> None:
    console.print(f"\n[bold]Benchmarking Memory (ChromaDB)...[/]")

    try:
        import chromadb
        from sentence_transformers import SentenceTransformer
    except ImportError:
        console.print("[yellow]chromadb or sentence-transformers not installed[/]")
        return

    client = chromadb.EphemeralClient()
    collection = client.create_collection("bench_test")

    embedder = SentenceTransformer("all-MiniLM-L6-v2")

    # Populate with 100 dummy memories
    docs = [f"Memory entry {i}: some content about topic {i % 10}" for i in range(100)]
    embeddings = embedder.encode(docs).tolist()
    collection.add(
        ids=[str(i) for i in range(100)],
        documents=docs,
        embeddings=embeddings,
    )

    # Benchmark query
    timings = []
    for _ in range(runs):
        query_emb = embedder.encode("productivity and focus").tolist()
        t0 = time.perf_counter()
        collection.query(query_embeddings=[query_emb], n_results=5)
        timings.append((time.perf_counter() - t0) * 1000)

    _print_results("Memory Query", timings)


# ── Entry point ───────────────────────────────────────────────

async def main() -> None:
    p = argparse.ArgumentParser(description="AI Companion Benchmark")
    p.add_argument("--runs", type=int, default=10)
    p.add_argument("--stage", choices=["all", "stt", "llm", "tts", "memory"],
                   default="all")
    p.add_argument("--model", default="qwen2.5:7b")
    p.add_argument("--stt-model", default="base")
    args = p.parse_args()

    console.print("[bold green]AI Companion — Latency Benchmark[/]\n")

    if args.stage in ("all", "stt"):
        bench_stt(args.runs, args.stt_model)

    if args.stage in ("all", "llm"):
        await bench_llm(args.runs, args.model)

    if args.stage in ("all", "tts"):
        bench_tts(args.runs)

    if args.stage in ("all", "memory"):
        await bench_memory(args.runs)

    console.print("\n[bold green]Benchmark complete.[/]")


if __name__ == "__main__":
    asyncio.run(main())

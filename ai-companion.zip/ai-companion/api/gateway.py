"""
api/gateway.py — FastAPI gateway registering all route modules.
See api/routes/ for endpoint implementations.
"""
from __future__ import annotations
import asyncio, time
from typing import Dict, List
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from loguru import logger

from config.config import settings
from core.events.event_bus import (
    bus, InterruptEvent, TranscriptionEvent, SystemStatusEvent,
    WakeWordEvent, LLMResponseEvent, LLMStreamChunkEvent, TTSDoneEvent,
)
from api.routes.automation_routes import router as automation_router
from api.routes.automation_routes import set_pipeline as _set_auto
from api.routes.memory_routes import router as memory_router
from api.routes.memory_routes import set_pipeline as _set_mem
from api.routes.productivity_routes import router as productivity_router
from api.routes.productivity_routes import set_pipeline as _set_prod

app = FastAPI(
    title="AI Companion", version=settings.app.version,
    docs_url="/docs", redoc_url="/redoc",
)
app.add_middleware(CORSMiddleware,
    allow_origins=["http://localhost:3000","http://127.0.0.1:3000",
                   "http://localhost:5173","http://127.0.0.1:5173"],
    allow_methods=["*"], allow_headers=["*"],
)
app.include_router(automation_router)
app.include_router(memory_router)
app.include_router(productivity_router)

_pipeline = None
_start_time = time.time()
_ws_connections: List[WebSocket] = []

def set_pipeline(pipeline) -> None:
    global _pipeline
    _pipeline = pipeline
    _set_auto(pipeline); _set_mem(pipeline); _set_prod(pipeline)

class SpeakRequest(BaseModel):
    text: str
    interrupt_current: bool = True

class AskRequest(BaseModel):
    text: str

@app.get("/health", tags=["core"])
async def health():
    components = await _pipeline.health() if _pipeline else {}
    ok = all(s == "ready" for s in components.values()) if components else False
    return {"status": "healthy" if ok else "starting" if not components else "degraded",
            "components": components,
            "uptime_sec": round(time.time() - _start_time, 1),
            "version": settings.app.version}

@app.get("/status", tags=["core"])
async def status():
    import psutil
    mem = psutil.virtual_memory()
    gpu = _get_gpu_info()
    return {
        "uptime_sec": round(time.time() - _start_time, 1),
        "components": await _pipeline.health() if _pipeline else {},
        "resources": {"cpu_percent": psutil.cpu_percent(0.1),
                      "memory": {"total_gb": round(mem.total/1e9,1),
                                 "available_gb": round(mem.available/1e9,1),
                                 "percent_used": mem.percent},
                      "gpu": gpu},
        "models": {"llm": settings.llm.model,
                   "stt": f"whisper-{settings.stt.model}",
                   "tts": settings.tts.engine,
                   "wake_word": settings.wake_word.model_name},
        "personality": {"name": settings.personality.name,
                        "style": settings.personality.style},
    }

@app.post("/speak", tags=["core"])
async def speak(req: SpeakRequest):
    if not req.text.strip(): raise HTTPException(400, "text required")
    if req.interrupt_current:
        await bus.publish(InterruptEvent(reason="api_speak"))
        await asyncio.sleep(0.05)
    if _pipeline and _pipeline._tts:
        await _pipeline._tts.speak(req.text.strip())
        return {"status": "queued", "text": req.text}
    raise HTTPException(503, "TTS not ready")

@app.post("/ask", tags=["core"])
async def ask(req: AskRequest):
    if not req.text.strip(): raise HTTPException(400, "text required")
    await bus.publish(TranscriptionEvent(text=req.text.strip(), language="en", timestamp=time.time()))
    return {"status": "queued", "text": req.text}

@app.post("/interrupt", tags=["core"])
async def interrupt():
    await bus.publish(InterruptEvent(reason="api_interrupt"))
    return {"status": "interrupted"}

@app.get("/context", tags=["core"])
async def get_context():
    if not (_pipeline and _pipeline._context): raise HTTPException(503, "Context not ready")
    msgs = await _pipeline._context.get_messages()
    return {"messages": msgs, "summary": _pipeline._context.summary_str()}

@app.delete("/context", tags=["core"])
async def clear_context():
    if not (_pipeline and _pipeline._context): raise HTTPException(503, "Context not ready")
    await _pipeline._context.clear()
    return {"status": "cleared"}

@app.get("/config", tags=["core"])
async def get_config():
    return {"stt": {"model": settings.stt.model, "device": settings.stt.device},
            "llm": {"model": settings.llm.model, "temperature": settings.llm.temperature,
                    "max_tokens": settings.llm.max_tokens},
            "tts": {"engine": settings.tts.engine},
            "wake_word": {"enabled": settings.wake_word.enabled,
                          "wake_words": settings.wake_word.wake_words},
            "personality": settings.personality.model_dump()}

@app.websocket("/ws/events")
async def websocket_events(websocket: WebSocket):
    await websocket.accept()
    _ws_connections.append(websocket)
    logger.info(f"WS: connected ({len(_ws_connections)} clients)")

    async def forward(event) -> None:
        try:
            await websocket.send_json({
                "type": type(event).__name__,
                "data": {k: str(v) for k, v in vars(event).items()},
                "timestamp": time.time(),
            })
        except Exception: pass

    for evt in (SystemStatusEvent, WakeWordEvent, TranscriptionEvent,
                LLMResponseEvent, LLMStreamChunkEvent):
        bus.subscribe(evt, forward)

    try:
        while True:
            msg = await websocket.receive_text()
            if msg == "ping": await websocket.send_text("pong")
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _ws_connections: _ws_connections.remove(websocket)

def _get_gpu_info() -> dict:
    try:
        import torch
        if torch.cuda.is_available():
            p = torch.cuda.get_device_properties(0)
            free, total = torch.cuda.mem_get_info(0)
            return {"available": True, "name": p.name,
                    "vram_total_gb": round(total/1e9,1),
                    "vram_used_gb": round((total-free)/1e9,1)}
    except ImportError: pass
    return {"available": False, "name": "CPU-only"}

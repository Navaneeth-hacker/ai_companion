"""
api/routes/automation_routes.py
================================
REST endpoints for the desktop automation engine.

Endpoints:
  GET  /automation/pending         — List actions awaiting confirmation
  POST /automation/confirm/{id}    — User confirms a pending action
  POST /automation/deny/{id}       — User denies a pending action
  POST /automation/execute         — Execute an action directly (auto-tier only)
  GET  /automation/log             — Recent automation audit log
  GET  /automation/apps            — List of approved launchable apps
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/automation", tags=["automation"])

# Injected by gateway.py at startup
_pipeline = None


def set_pipeline(pipeline) -> None:
    global _pipeline
    _pipeline = pipeline


# ── Request models ──────────────────────────────────────────

class ExecuteRequest(BaseModel):
    action_type: str
    parameters: Dict[str, Any] = {}
    source: str = "api"


# ── Routes ──────────────────────────────────────────────────

@router.get("/pending")
async def get_pending():
    """List all automation actions waiting for user confirmation."""
    if not (_pipeline and _pipeline._perms):
        raise HTTPException(503, "Automation engine not initialized")

    pending = _pipeline._perms.get_pending()
    return {
        "count": len(pending),
        "actions": [
            {
                "request_id": r.request_id,
                "action_type": r.action_type,
                "parameters": r.parameters,
                "source": r.source,
                "timestamp": r.timestamp,
            }
            for r in pending
        ],
    }


@router.post("/confirm/{request_id}")
async def confirm_action(request_id: str):
    """
    Confirm a pending automation action.
    The action will be executed immediately after confirmation.
    """
    if not (_pipeline and _pipeline._perms and _pipeline._automation):
        raise HTTPException(503, "Automation engine not initialized")

    result = await _pipeline._automation.confirm_and_execute(request_id)
    if not result:
        raise HTTPException(404, f"No pending action with ID {request_id}")

    return {
        "request_id": request_id,
        "success": result.success,
        "message": result.message,
        "duration_sec": result.duration_sec,
    }


@router.post("/deny/{request_id}")
async def deny_action(request_id: str):
    """Deny a pending automation action. The action will not be executed."""
    if not (_pipeline and _pipeline._perms):
        raise HTTPException(503, "Automation engine not initialized")

    decision = _pipeline._perms.deny(request_id)
    if not decision:
        raise HTTPException(404, f"No pending action with ID {request_id}")

    return {"request_id": request_id, "status": "denied"}


@router.post("/execute")
async def execute_action(req: ExecuteRequest):
    """
    Directly execute an automation action.
    Auto-approved actions execute immediately.
    Confirm-required actions return a pending request_id.
    Blocked actions return 403.
    """
    if not (_pipeline and _pipeline._automation):
        raise HTTPException(503, "Automation engine not initialized")

    result = await _pipeline._automation.execute(
        action_type=req.action_type,
        parameters=req.parameters,
        source=req.source,
    )

    if result.message.startswith("BLOCKED"):
        raise HTTPException(403, result.message)

    if result.message.startswith("CONFIRM_REQUIRED"):
        parts = result.message.split(":", 2)
        return {
            "status": "pending_confirmation",
            "request_id": parts[1] if len(parts) > 1 else "unknown",
            "message": parts[2] if len(parts) > 2 else result.message,
        }

    return {
        "success": result.success,
        "action_type": result.action_type,
        "message": result.message,
        "duration_sec": result.duration_sec,
    }


@router.get("/log")
async def get_automation_log(limit: int = 50):
    """
    Return recent automation audit log entries.
    Reads directly from the audit.jsonl file.
    """
    from config.config import settings
    audit_path = settings.security.audit_log_path

    if not audit_path.exists():
        return {"entries": [], "total": 0}

    lines = audit_path.read_text(encoding="utf-8").strip().splitlines()
    entries = []
    for line in reversed(lines[-limit:]):
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    return {"entries": entries, "total": len(lines)}


@router.get("/apps")
async def get_approved_apps():
    """List all applications approved for voice-commanded launch."""
    from automation.permission_system import APPROVED_APPS
    return {"apps": sorted(APPROVED_APPS)}

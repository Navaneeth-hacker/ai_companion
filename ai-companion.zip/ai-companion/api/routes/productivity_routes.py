"""
api/routes/productivity_routes.py
==================================
REST endpoints for productivity tracking and learning.

Endpoints:
  GET  /productivity/report       — Current productivity report
  GET  /productivity/history      — Historical activity log
  GET  /productivity/breakdown    — Category time breakdown
  POST /productivity/feedback     — Submit feedback on AI response quality
  GET  /productivity/patterns     — Learned behavioral patterns
  POST /productivity/goal         — Set a work session goal
  GET  /productivity/goal         — Get current session goal
  GET  /productivity/proactive    — History of proactive messages
"""

from __future__ import annotations

import time
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/productivity", tags=["productivity"])

_pipeline = None
_current_goal: Optional[str] = None


def set_pipeline(pipeline) -> None:
    global _pipeline
    _pipeline = pipeline


# ── Request models ──────────────────────────────────────────

class FeedbackRequest(BaseModel):
    response_text: str
    feedback: str       # good | too_long | too_short | wrong_tone | helpful | unhelpful
    context: str = ""


class GoalRequest(BaseModel):
    goal: str           # Free-text session goal


# ── Routes ──────────────────────────────────────────────────

@router.get("/report")
async def get_productivity_report():
    """
    Current productivity report with score, time breakdown, and recommendations.
    """
    if not (_pipeline and _pipeline._vision):
        return {
            "status": "unavailable",
            "reason": "Vision engine not running",
        }

    report = _pipeline._vision.get_productivity_report()
    if not report:
        return {"status": "no_data", "reason": "No activity recorded yet"}

    return {
        "score": report.score,
        "session_duration_min": report.session_duration_min,
        "productive_pct": report.productive_pct,
        "distraction_pct": report.distraction_pct,
        "current_streak": {
            "minutes": report.current_streak_min,
            "type": report.current_streak_type,
        },
        "category_breakdown": report.category_breakdown,
        "context_switches_per_hour": report.context_switches_per_hour,
        "needs_intervention": report.needs_intervention,
        "recommendations": report.recommendations,
        "timestamp": report.timestamp,
    }


@router.get("/history")
async def get_activity_history(
    limit: int = 100,
    category: Optional[str] = None,
    date: Optional[str] = None,    # YYYY-MM-DD format
):
    """
    Historical window activity log from SQLite.
    Supports filtering by category and date.
    """
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    from sqlalchemy import select, desc
    from database.models import ActivityLog

    async with _pipeline._memory._session_factory() as session:
        query = select(ActivityLog).order_by(desc(ActivityLog.timestamp)).limit(limit)

        if category:
            query = query.where(ActivityLog.category == category)
        if date:
            query = query.where(ActivityLog.date_str == date)

        result = await session.execute(query)
        rows = result.scalars().all()

    return {
        "entries": [
            {
                "process_name": r.process_name,
                "window_title": r.window_title,
                "category": r.category,
                "is_distraction": r.is_distraction,
                "is_productive": r.is_productive,
                "duration_sec": r.duration_sec,
                "timestamp": r.timestamp,
                "date": r.date_str,
            }
            for r in rows
        ],
        "count": len(rows),
        "filters": {"category": category, "date": date},
    }


@router.get("/breakdown")
async def get_category_breakdown(days: int = 7):
    """
    Aggregated time-per-category over the last N days.
    Returns minutes per category, sorted by time spent.
    """
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    from datetime import datetime, timedelta
    from sqlalchemy import select, func
    from database.models import ActivityLog

    cutoff = datetime.now() - timedelta(days=days)
    cutoff_str = cutoff.strftime("%Y-%m-%d")

    async with _pipeline._memory._session_factory() as session:
        result = await session.execute(
            select(
                ActivityLog.category,
                func.sum(ActivityLog.duration_sec).label("total_sec"),
                func.count().label("sessions"),
            )
            .where(ActivityLog.date_str >= cutoff_str)
            .group_by(ActivityLog.category)
            .order_by(func.sum(ActivityLog.duration_sec).desc())
        )
        rows = result.all()

    total_sec = sum(r.total_sec or 0 for r in rows)

    return {
        "days": days,
        "categories": [
            {
                "category": r.category,
                "minutes": round((r.total_sec or 0) / 60, 1),
                "sessions": r.sessions,
                "percentage": round(
                    ((r.total_sec or 0) / total_sec * 100) if total_sec else 0, 1
                ),
            }
            for r in rows
        ],
        "total_tracked_hours": round(total_sec / 3600, 1),
    }


@router.post("/feedback")
async def submit_feedback(req: FeedbackRequest):
    """Submit quality feedback on an AI response. Used by the learning engine."""
    if not (_pipeline and _pipeline._learning):
        raise HTTPException(503, "Learning engine not initialized")

    valid_feedback = {
        "good", "helpful", "too_long", "too_short",
        "wrong_tone", "unhelpful", "inaccurate",
    }
    if req.feedback not in valid_feedback:
        raise HTTPException(
            400, f"Invalid feedback. Must be one of: {valid_feedback}"
        )

    await _pipeline._learning.record_feedback(
        response_text=req.response_text,
        feedback=req.feedback,
    )
    return {"status": "recorded", "feedback": req.feedback}


@router.get("/patterns")
async def get_learned_patterns():
    """Return behavioral patterns the learning engine has discovered."""
    if not (_pipeline and _pipeline._learning):
        raise HTTPException(503, "Learning engine not initialized")

    patterns = _pipeline._learning.pattern_learner._learned_patterns
    style_summary = _pipeline._learning.preference_tracker.get_style_summary()

    return {
        "patterns": [
            {
                "type": p.pattern_type,
                "description": p.description,
                "confidence": p.confidence,
                "occurrences": p.occurrences,
                "last_seen": p.last_seen,
            }
            for p in patterns
        ],
        "preference_summary": style_summary,
        "preferred_response_length": (
            _pipeline._learning.preference_tracker.get_preferred_length()
        ),
    }


@router.post("/goal")
async def set_goal(req: GoalRequest):
    """Set a work session goal. Stored in memory and used in LLM context."""
    global _current_goal

    if not req.goal.strip():
        raise HTTPException(400, "goal must not be empty")

    _current_goal = req.goal.strip()

    # Store as a preference in memory engine
    if _pipeline and _pipeline._memory:
        await _pipeline._memory.set_preference("session_goal", _current_goal)
        await _pipeline._memory.store_memory(
            content=f"User's session goal: {_current_goal}",
            memory_type="goal",
            importance=0.9,
            source="api",
        )

    return {"status": "goal_set", "goal": _current_goal}


@router.get("/goal")
async def get_goal():
    """Get the current session goal."""
    goal = _current_goal
    if not goal and _pipeline and _pipeline._memory:
        goal = await _pipeline._memory.get_preference("session_goal", "")

    return {"goal": goal or None, "set": bool(goal)}


@router.get("/proactive")
async def get_proactive_history(limit: int = 20):
    """Return history of proactive messages sent by the personality engine."""
    if not (_pipeline and hasattr(_pipeline, "_personality") and _pipeline._personality):
        return {"messages": [], "count": 0}

    history = _pipeline._personality.get_history()
    recent = history[-limit:]

    return {
        "messages": [
            {
                "trigger": m.trigger,
                "message": m.message,
                "timestamp": m.timestamp,
            }
            for m in reversed(recent)
        ],
        "count": len(history),
    }

"""
api/routes/memory_routes.py
============================
REST endpoints for the memory engine.

Endpoints:
  GET    /memory/search            — Semantic search over stored memories
  POST   /memory/store             — Manually store a memory
  GET    /memory/recent            — Recent conversation turns
  DELETE /memory/entry/{id}        — Delete a specific memory
  POST   /memory/summarize         — Trigger session summarization
  GET    /memory/preferences       — All stored user preferences
  PUT    /memory/preferences/{key} — Set a user preference
  POST   /memory/session/new       — Start a fresh conversation session
  GET    /memory/stats             — Memory database statistics
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/memory", tags=["memory"])

_pipeline = None


def set_pipeline(pipeline) -> None:
    global _pipeline
    _pipeline = pipeline


# ── Request models ──────────────────────────────────────────

class StoreMemoryRequest(BaseModel):
    content: str
    memory_type: str = "fact"           # fact | preference | habit | goal | summary
    importance: float = 0.5             # 0.0 – 1.0
    source: str = "manual"


class SetPreferenceRequest(BaseModel):
    value: str


# ── Routes ──────────────────────────────────────────────────

@router.get("/search")
async def search_memory(q: str, top_k: int = 5):
    """
    Semantic search over stored memories.
    Returns the most relevant memories for the query.
    """
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    memories = await _pipeline._memory.retrieve_relevant(q, top_k=top_k)
    return {
        "query": q,
        "results": [
            {
                "id": m.id,
                "content": m.content,
                "memory_type": m.memory_type,
                "importance": m.importance,
                "relevance_score": m.relevance_score,
                "timestamp": m.timestamp,
            }
            for m in memories
        ],
    }


@router.post("/store")
async def store_memory(req: StoreMemoryRequest):
    """Manually store a memory entry."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    if not req.content.strip():
        raise HTTPException(400, "content must not be empty")

    if not 0.0 <= req.importance <= 1.0:
        raise HTTPException(400, "importance must be between 0.0 and 1.0")

    memory_id = await _pipeline._memory.store_memory(
        content=req.content.strip(),
        memory_type=req.memory_type,
        importance=req.importance,
        source=req.source,
    )
    return {"status": "stored", "id": memory_id}


@router.get("/recent")
async def get_recent_turns(limit: int = 20):
    """Get recent conversation turns for the current session."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    turns = await _pipeline._memory.get_recent_turns(limit=limit)
    return {
        "session_id": _pipeline._memory._current_session_id,
        "turns": turns,
        "count": len(turns),
    }


@router.post("/summarize")
async def summarize_session():
    """
    Trigger immediate session summarization.
    The LLM distills the current conversation into bullet-point memories.
    """
    if not (_pipeline and _pipeline._memory and _pipeline._llm):
        raise HTTPException(503, "Memory or LLM engine not initialized")

    summary = await _pipeline._memory.summarize_session(_pipeline._llm)
    if not summary:
        return {"status": "skipped", "reason": "Not enough conversation history"}

    return {"status": "summarized", "summary": summary}


@router.get("/preferences")
async def get_preferences():
    """Get all stored user preferences."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    # Query all preferences from SQLite
    from sqlalchemy import select
    from database.models import UserPreference

    async with _pipeline._memory._session_factory() as session:
        result = await session.execute(select(UserPreference))
        prefs = result.scalars().all()

    return {
        "preferences": {
            p.key: {"value": p.value, "type": p.value_type}
            for p in prefs
        }
    }


@router.put("/preferences/{key}")
async def set_preference(key: str, req: SetPreferenceRequest):
    """Set a user preference by key."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    await _pipeline._memory.set_preference(key, req.value)
    return {"status": "ok", "key": key, "value": req.value}


@router.post("/session/new")
async def new_session():
    """Start a fresh conversation session (clears rolling context)."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    session_id = _pipeline._memory.new_session()

    # Also clear the LLM context manager
    if _pipeline._context:
        await _pipeline._context.clear()

    return {"status": "new_session", "session_id": session_id}


@router.get("/stats")
async def memory_stats():
    """Return memory database statistics."""
    if not (_pipeline and _pipeline._memory):
        raise HTTPException(503, "Memory engine not initialized")

    engine = _pipeline._memory

    # SQLite counts
    from sqlalchemy import select, func
    from database.models import Conversation, Memory, ActivityLog

    async with engine._session_factory() as session:
        conv_count = await session.scalar(select(func.count()).select_from(Conversation))
        mem_count = await session.scalar(select(func.count()).select_from(Memory))
        activity_count = await session.scalar(select(func.count()).select_from(ActivityLog))

    # ChromaDB count
    vector_count = 0
    if engine._collection:
        vector_count = engine._collection.count()

    return {
        "sqlite": {
            "conversations": conv_count,
            "memories": mem_count,
            "activity_logs": activity_count,
        },
        "chromadb": {
            "vector_entries": vector_count,
            "max_memories": engine._max_memories,
        },
        "current_session": engine._current_session_id,
        "embedding_model": engine._embedding_model_name,
    }

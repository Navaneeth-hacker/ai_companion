"""
database/models.py
==================
SQLAlchemy ORM models for the local SQLite database.

Tables:
  conversations     — Full conversation history (user + assistant turns)
  memories          — Distilled long-term memory entries (summaries, facts)
  activity_log      — Window/app usage timeline
  user_preferences  — Key-value preference store
  tasks             — Tracked tasks and their completion state
  automation_log    — Record of all automation actions taken

Design:
  - SQLite is sufficient for the local single-user case.
  - ChromaDB (vector DB) handles semantic search separately.
  - SQLite gives us fast structured queries (date range, category filter).
  - We use SQLAlchemy 2.x async engine for non-blocking DB access.
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Float, Integer,
    JSON, String, Text, func, Index,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


# ── Conversations ────────────────────────────────────────────

class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    role: Mapped[str] = mapped_column(String(20), nullable=False)   # user | assistant | system
    content: Mapped[str] = mapped_column(Text, nullable=False)
    timestamp: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        Index("ix_conversations_session_ts", "session_id", "timestamp"),
    )


# ── Long-term memories ───────────────────────────────────────

class Memory(Base):
    __tablename__ = "memories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    memory_type: Mapped[str] = mapped_column(
        String(50), nullable=False, index=True
    )   # "fact" | "preference" | "habit" | "goal" | "summary"
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(100))  # Where this came from
    importance: Mapped[float] = mapped_column(Float, default=0.5)  # 0–1
    access_count: Mapped[int] = mapped_column(Integer, default=0)
    last_accessed: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    embedding_id: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True
    )   # ChromaDB document ID
    timestamp: Mapped[float] = mapped_column(Float, nullable=False, default=time.time)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        Index("ix_memories_type_importance", "memory_type", "importance"),
    )


# ── Activity log ─────────────────────────────────────────────

class ActivityLog(Base):
    __tablename__ = "activity_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    process_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    window_title: Mapped[str] = mapped_column(String(500))
    category: Mapped[str] = mapped_column(String(50), index=True)
    is_distraction: Mapped[bool] = mapped_column(Boolean, default=False)
    is_productive: Mapped[bool] = mapped_column(Boolean, default=False)
    duration_sec: Mapped[float] = mapped_column(Float, default=0.0)
    timestamp: Mapped[float] = mapped_column(Float, nullable=False, default=time.time, index=True)
    date_str: Mapped[str] = mapped_column(String(10))  # YYYY-MM-DD for easy grouping

    __table_args__ = (
        Index("ix_activity_date_category", "date_str", "category"),
    )


# ── User preferences ─────────────────────────────────────────

class UserPreference(Base):
    __tablename__ = "user_preferences"

    key: Mapped[str] = mapped_column(String(200), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    value_type: Mapped[str] = mapped_column(String(20), default="string")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )


# ── Tasks ────────────────────────────────────────────────────

class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        String(20), default="pending", index=True
    )   # pending | in_progress | done | cancelled
    priority: Mapped[int] = mapped_column(Integer, default=2)  # 1=high, 2=medium, 3=low
    due_date: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    completed_at: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    metadata_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


# ── Automation log ───────────────────────────────────────────

class AutomationLogEntry(Base):
    __tablename__ = "automation_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[str] = mapped_column(String(20), nullable=False)
    action_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    parameters: Mapped[str] = mapped_column(Text)   # JSON
    source: Mapped[str] = mapped_column(String(50))
    success: Mapped[bool] = mapped_column(Boolean)
    result_message: Mapped[str] = mapped_column(Text)
    duration_sec: Mapped[float] = mapped_column(Float)
    timestamp: Mapped[float] = mapped_column(Float, default=time.time, index=True)

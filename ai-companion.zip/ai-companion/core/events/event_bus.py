"""
core/events/event_bus.py
========================
Lightweight publish/subscribe event bus built on asyncio.

Design:
  - All events are typed dataclasses (not raw strings).
  - Any component can publish; any component can subscribe.
  - Handlers are async coroutines.
  - The bus runs inside the main asyncio event loop.
  - For cross-process communication, see core/events/ipc_bridge.py.

Usage:
    bus = EventBus()

    # Subscribe
    async def on_wake(event: WakeWordEvent):
        print(f"Wake word detected: {event.word}")
    bus.subscribe(WakeWordEvent, on_wake)

    # Publish
    await bus.publish(WakeWordEvent(word="wake up", confidence=0.95))
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Dict, List, Type, TypeVar

from loguru import logger

T = TypeVar("T")
AsyncHandler = Callable[[Any], Coroutine[Any, Any, None]]


# ─────────────────────────────────────────────
# Event dataclasses
# ─────────────────────────────────────────────

@dataclass
class BaseEvent:
    """All events inherit from this."""
    pass


@dataclass
class WakeWordEvent(BaseEvent):
    word: str
    confidence: float
    timestamp: float = 0.0


@dataclass
class AudioChunkEvent(BaseEvent):
    """Raw PCM chunk from the microphone."""
    data: bytes
    sample_rate: int
    timestamp: float = 0.0


@dataclass
class TranscriptionEvent(BaseEvent):
    text: str
    language: str
    timestamp: float = 0.0
    duration_sec: float = 0.0


@dataclass
class LLMResponseEvent(BaseEvent):
    text: str
    is_final: bool = True       # False during streaming chunks
    timestamp: float = 0.0


@dataclass
class LLMStreamChunkEvent(BaseEvent):
    """Streaming token from LLM — sent to TTS as they arrive."""
    chunk: str
    sequence: int = 0


@dataclass
class TTSStartEvent(BaseEvent):
    text: str


@dataclass
class TTSDoneEvent(BaseEvent):
    duration_sec: float = 0.0


@dataclass
class InterruptEvent(BaseEvent):
    """
    Published when user interrupts mid-response (wake word during TTS).
    All active TTS + LLM processing should cancel on this event.
    """
    reason: str = "user_interrupt"


@dataclass
class SystemStatusEvent(BaseEvent):
    component: str
    status: str         # "ready" | "busy" | "error" | "shutdown"
    detail: str = ""


@dataclass
class ErrorEvent(BaseEvent):
    component: str
    error: str
    recoverable: bool = True


# ─────────────────────────────────────────────
# Event Bus
# ─────────────────────────────────────────────

class EventBus:
    """
    Async publish/subscribe event bus.

    Thread safety: NOT thread-safe. Must be used from a single
    asyncio event loop. Use asyncio.run_coroutine_threadsafe()
    to publish from a different thread.
    """

    def __init__(self) -> None:
        self._handlers: Dict[Type[BaseEvent], List[AsyncHandler]] = defaultdict(list)
        self._event_queue: asyncio.Queue = asyncio.Queue()
        self._running = False

    def subscribe(self, event_type: Type[T], handler: AsyncHandler) -> None:
        """Register an async handler for an event type."""
        self._handlers[event_type].append(handler)
        logger.debug(
            f"EventBus: subscribed {handler.__name__} → {event_type.__name__}"
        )

    def unsubscribe(self, event_type: Type[T], handler: AsyncHandler) -> None:
        """Remove a previously registered handler."""
        handlers = self._handlers.get(event_type, [])
        if handler in handlers:
            handlers.remove(handler)

    async def publish(self, event: BaseEvent) -> None:
        """
        Enqueue an event for dispatch.
        Returns immediately — handlers run in the next loop iteration.
        """
        await self._event_queue.put(event)

    def publish_sync(self, event: BaseEvent, loop: asyncio.AbstractEventLoop) -> None:
        """
        Thread-safe publish from a non-async context (e.g. pyaudio callback).
        Requires a running event loop reference.
        """
        asyncio.run_coroutine_threadsafe(self.publish(event), loop)

    async def _dispatch(self, event: BaseEvent) -> None:
        """Call all handlers registered for this event type."""
        event_type = type(event)
        handlers = self._handlers.get(event_type, [])
        if not handlers:
            return
        tasks = [asyncio.create_task(h(event)) for h in handlers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                handler_name = handlers[i].__name__
                logger.error(
                    f"EventBus handler error | handler={handler_name} "
                    f"event={event_type.__name__} error={result}"
                )

    async def run(self) -> None:
        """
        Main dispatch loop. Run this as a long-lived task:
            asyncio.create_task(bus.run())
        """
        self._running = True
        logger.info("EventBus: started dispatch loop")
        while self._running:
            try:
                event = await asyncio.wait_for(
                    self._event_queue.get(), timeout=0.5
                )
                await self._dispatch(event)
                self._event_queue.task_done()
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"EventBus: dispatch loop error: {e}")

    async def stop(self) -> None:
        """Gracefully stop the dispatch loop."""
        self._running = False
        logger.info("EventBus: stopped")


# Module-level singleton — import this everywhere
bus = EventBus()

"""
core/context/context_manager.py
================================
Rolling conversation context buffer.

Responsibilities:
  - Maintain ordered conversation history (user + assistant turns).
  - Enforce token budget (prune oldest turns when approaching LLM context limit).
  - Produce the message list format Ollama's /api/chat expects.
  - Store context snapshots to SQLite for session recovery (Phase 4 expands this).

Design notes:
  - We estimate tokens as len(text) // 4 (rough but avoids a tokenizer dep here).
  - A full tiktoken / sentencepiece count is added in Phase 4.
  - Thread-safe via asyncio.Lock.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Literal, Optional

import asyncio
from loguru import logger


Role = Literal["system", "user", "assistant"]


@dataclass
class Message:
    role: Role
    content: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {"role": self.role, "content": self.content}

    @property
    def estimated_tokens(self) -> int:
        return max(1, len(self.content) // 4)


class ContextManager:
    """
    Manages the rolling conversation context sent to the LLM.

    Args:
        system_prompt:    Fixed system prompt prepended to every request.
        max_tokens:       Approximate token budget for the full context window.
        max_turns:        Hard cap on conversation turns kept in memory.
    """

    def __init__(
        self,
        system_prompt: str,
        max_tokens: int = 4096,
        max_turns: int = 20,
    ) -> None:
        self._system_prompt = system_prompt
        self._max_tokens = max_tokens
        self._max_turns = max_turns
        self._history: List[Message] = []
        self._lock = asyncio.Lock()

        logger.info(
            f"ContextManager: max_tokens={max_tokens} max_turns={max_turns}"
        )

    async def add_user_message(self, text: str) -> None:
        async with self._lock:
            self._history.append(Message(role="user", content=text.strip()))
            await self._prune()

    async def add_assistant_message(self, text: str) -> None:
        async with self._lock:
            self._history.append(Message(role="assistant", content=text.strip()))
            await self._prune()

    async def get_messages(self) -> List[dict]:
        """
        Return the full message list in Ollama /api/chat format.
        Always prepends the system prompt.
        """
        async with self._lock:
            messages = [{"role": "system", "content": self._system_prompt}]
            messages.extend(m.to_dict() for m in self._history)
            return messages

    async def clear(self) -> None:
        async with self._lock:
            self._history.clear()
            logger.info("ContextManager: history cleared")

    async def _prune(self) -> None:
        """
        Remove oldest turns if we're over budget.
        Always removes in pairs (user + assistant) to keep conversation coherent.
        Must be called while holding self._lock.
        """
        # Hard cap on number of turns
        while len(self._history) > self._max_turns * 2:
            self._history.pop(0)

        # Token budget enforcement
        system_tokens = len(self._system_prompt) // 4
        while True:
            history_tokens = sum(m.estimated_tokens for m in self._history)
            total = system_tokens + history_tokens
            if total <= self._max_tokens * 0.85:   # 85% threshold → leave room for response
                break
            if len(self._history) < 2:
                break
            removed = self._history.pop(0)
            logger.debug(
                f"ContextManager: pruned oldest message "
                f"({removed.role}, ~{removed.estimated_tokens} tokens)"
            )

    @property
    def turn_count(self) -> int:
        return len(self._history) // 2

    @property
    def estimated_token_count(self) -> int:
        return (len(self._system_prompt) // 4) + sum(
            m.estimated_tokens for m in self._history
        )

    def summary_str(self) -> str:
        return (
            f"turns={self.turn_count} "
            f"~tokens={self.estimated_token_count}"
        )

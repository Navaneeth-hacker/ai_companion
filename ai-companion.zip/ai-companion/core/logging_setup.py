"""
core/logging_setup.py
=====================
Centralized logging configuration using loguru.

Features:
  - Rotating file logs (10 MB max, 7 files retained)
  - Structured JSON sink for machine-readable audit trail
  - Rich console output with colors in dev mode
  - Per-module log filtering

Usage:
    from core.logging_setup import get_logger
    logger = get_logger(__name__)
    logger.info("Starting...")
"""

import sys
from pathlib import Path
from loguru import logger


def setup_logging(log_dir: Path, log_level: str = "INFO", debug: bool = False) -> None:
    """
    Configure loguru sinks. Call once at startup in main.py.

    Args:
        log_dir:   Directory where log files are written.
        log_level: Minimum level for file + console output.
        debug:     If True, enables DEBUG level and verbose format.
    """
    log_dir.mkdir(parents=True, exist_ok=True)

    # Remove loguru's default handler
    logger.remove()

    # ── Console sink ────────────────────────────────────────
    console_fmt = (
        "<green>{time:HH:mm:ss}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
        "{message}"
    )
    logger.add(
        sys.stdout,
        format=console_fmt,
        level="DEBUG" if debug else log_level,
        colorize=True,
        backtrace=debug,
        diagnose=debug,
    )

    # ── Rotating human-readable file sink ───────────────────
    log_file = log_dir / "companion.log"
    logger.add(
        str(log_file),
        format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {name}:{function}:{line} | {message}",
        level=log_level,
        rotation="10 MB",
        retention=7,
        compression="gz",
        backtrace=True,
        diagnose=True,
        encoding="utf-8",
    )

    # ── JSON structured sink (for future telemetry / dashboard) ─
    json_log = log_dir / "structured.jsonl"
    logger.add(
        str(json_log),
        format="{message}",
        level=log_level,
        rotation="50 MB",
        retention=3,
        serialize=True,   # loguru outputs JSON when serialize=True
        encoding="utf-8",
    )

    logger.info(
        f"Logging initialized | level={log_level} | dir={log_dir}"
    )


def get_logger(name: str):
    """
    Return a loguru logger bound to the caller's module name.

    Usage:
        logger = get_logger(__name__)
    """
    return logger.bind(name=name)

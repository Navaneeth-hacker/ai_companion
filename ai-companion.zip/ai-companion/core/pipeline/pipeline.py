"""
core/pipeline/pipeline.py
==========================
Phase 1 Pipeline Orchestrator.

Wires together:
  WakeWordEngine → STTEngine → LLMEngine → TTSEngine

Responsibilities:
  - Start/stop all engines in the correct order.
  - Manage the shared state flags (is_speaking).
  - Handle graceful shutdown on SIGINT/SIGTERM.
  - Run the EventBus dispatch loop.
  - Export pipeline health status for the API gateway.

Threading model:
  - Main thread: asyncio event loop (EventBus, LLMEngine, STTEngine handlers).
  - Thread 1: WakeWordEngine detection loop (pyaudio + OWW inference).
  - Thread 2: TTSEngine playback loop (sounddevice).
  - All cross-thread comms go through EventBus.publish_sync() or asyncio.Queue.

Startup sequence:
  1. Load config.
  2. Init logging.
  3. Start EventBus.
  4. Load STT model (slow — Whisper download).
  5. Load TTS model.
  6. Start Ollama health check.
  7. Start WakeWordEngine (begins listening).
  8. Begin asyncio event loop → blocks until shutdown.
"""

from __future__ import annotations

import asyncio
import signal
import threading
import time
from typing import Dict, Optional

from loguru import logger

from config.config import Settings
from core.events.event_bus import EventBus, SystemStatusEvent, bus
from core.context.context_manager import ContextManager
from core.logging_setup import setup_logging
from audio.wake_word.wake_word_engine import WakeWordEngine
from audio.stt.stt_engine import STTEngine
from audio.llm.llm_engine import LLMEngine
from audio.tts.tts_engine import TTSEngine


class Pipeline:
    """
    Top-level orchestrator for the AI companion pipeline.

    Usage:
        pipeline = Pipeline(settings)
        asyncio.run(pipeline.run())
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._is_speaking = threading.Event()
        self._shutdown_event = asyncio.Event()

        # Component instances (populated in _initialize)
        self._wake_word: Optional[WakeWordEngine] = None
        self._stt: Optional[STTEngine] = None
        self._llm: Optional[LLMEngine] = None
        self._tts: Optional[TTSEngine] = None
        self._context: Optional[ContextManager] = None

        # Status tracking for health endpoint
        self._component_status: Dict[str, str] = {
            "wake_word": "uninitialized",
            "stt": "uninitialized",
            "llm": "uninitialized",
            "tts": "uninitialized",
        }

    # ── Public API ──────────────────────────────────────────

    async def run(self) -> None:
        """Start all components and block until shutdown."""
        loop = asyncio.get_running_loop()

        # Register OS signal handlers for graceful shutdown
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._signal_handler)

        try:
            await self._initialize(loop)
            logger.info("Pipeline: all components initialized — listening for wake word")
            await self._shutdown_event.wait()

        except Exception as e:
            logger.critical(f"Pipeline: fatal error: {e}", exc_info=True)
        finally:
            await self._shutdown()

    async def health(self) -> Dict[str, str]:
        """Return current status of all components."""
        return dict(self._component_status)

    # ── Initialization ───────────────────────────────────────

    async def _initialize(self, loop: asyncio.AbstractEventLoop) -> None:
        """Initialize all components in dependency order."""

        # ── Subscribe to SystemStatusEvents for health tracking ──
        bus.subscribe(SystemStatusEvent, self._on_system_status)

        # ── Start EventBus dispatch loop ─────────────────────
        asyncio.create_task(bus.run(), name="event-bus")

        # ── Context Manager ─────────────────────────────────
        self._context = ContextManager(
            system_prompt=self._settings.llm.system_prompt,
            max_tokens=self._settings.llm.context_window,
        )

        # ── STT Engine ───────────────────────────────────────
        logger.info("Pipeline: loading STT (Whisper)...")
        self._stt = STTEngine(
            event_bus=bus,
            model=self._settings.stt.model,
            device=self._settings.stt.device,
            compute_type=self._settings.stt.compute_type,
            language=self._settings.stt.language,
            sample_rate=self._settings.audio.sample_rate,
            silence_timeout=self._settings.audio.silence_timeout,
            max_record_sec=self._settings.audio.max_record_sec,
            vad_filter=self._settings.stt.vad_filter,
        )
        await self._stt.load()

        # ── TTS Engine ───────────────────────────────────────
        logger.info("Pipeline: loading TTS (Piper)...")
        self._tts = TTSEngine(
            event_bus=bus,
            model_path=self._settings.tts.model_path,
            config_path=self._settings.tts.config_path,
            speaking_rate=self._settings.tts.speaking_rate,
            volume=self._settings.tts.volume,
            sample_rate=self._settings.tts.sample_rate,
            output_device=self._settings.tts.output_device,
            is_speaking=self._is_speaking,
        )
        await self._tts.load()

        # ── LLM Engine ───────────────────────────────────────
        logger.info("Pipeline: connecting to Ollama LLM...")
        self._llm = LLMEngine(
            event_bus=bus,
            context_manager=self._context,
            base_url=self._settings.llm.base_url,
            model=self._settings.llm.model,
            temperature=self._settings.llm.temperature,
            top_p=self._settings.llm.top_p,
            max_tokens=self._settings.llm.max_tokens,
            stream=self._settings.llm.stream,
            request_timeout=self._settings.llm.request_timeout,
        )
        await self._llm.start()

        # ── Wake Word Engine (last — starts listening) ───────
        if self._settings.wake_word.enabled:
            logger.info("Pipeline: starting wake word engine...")
            self._wake_word = WakeWordEngine(
                event_bus=bus,
                event_loop=loop,
                model_name=self._settings.wake_word.model_name,
                wake_words=self._settings.wake_word.wake_words,
                threshold=self._settings.wake_word.threshold,
                sample_rate=self._settings.audio.sample_rate,
                is_speaking=self._is_speaking,
            )
            self._wake_word.start()
            self._component_status["wake_word"] = "ready"
        else:
            logger.warning("Pipeline: wake word disabled in config")

        # Announce readiness via TTS
        await bus.publish(
            type("_StartupMsg", (), {})()  # anonymous event
        )
        # Direct TTS speak for startup announcement
        await self._tts.speak(
            f"Hello. {self._settings.personality.name} is ready."
        )

    # ── Event handlers ───────────────────────────────────────

    async def _on_system_status(self, event: SystemStatusEvent) -> None:
        self._component_status[event.component] = event.status
        logger.debug(
            f"Pipeline: {event.component} → {event.status}"
            + (f" ({event.detail})" if event.detail else "")
        )

    # ── Shutdown ─────────────────────────────────────────────

    def _signal_handler(self) -> None:
        logger.info("Pipeline: shutdown signal received")
        self._shutdown_event.set()

    async def _shutdown(self) -> None:
        """Gracefully stop all components."""
        logger.info("Pipeline: shutting down...")

        if self._wake_word:
            self._wake_word.stop()
        if self._stt:
            await self._stt.unload()
        if self._llm:
            await self._llm.stop()
        if self._tts:
            await self._tts.stop()
        await bus.stop()

        logger.info("Pipeline: shutdown complete")

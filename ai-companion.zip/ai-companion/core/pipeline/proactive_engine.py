"""
core/pipeline/proactive_engine.py
===================================
Proactive observation engine.

Runs as a background asyncio task inside the full pipeline.
Periodically checks conditions and delivers unsolicited observations
via TTS when the user hasn't been interacting for a while.

Trigger conditions (in priority order):
  1. Distraction streak  → call out the distraction app by name
  2. Long work sprint    → suggest a break with specific duration
  3. Coding error on screen → offer debugging help
  4. Time-of-day events  → morning goal check, end-of-day review
  5. Idle for too long   → check-in prompt
  6. High context-switch rate → fragmentation warning

Gate conditions (all must pass before delivering):
  - Not currently speaking (is_speaking flag clear)
  - Not in active conversation (silence > 30s since last turn)
  - Cooldown since last proactive message has elapsed
  - Vision engine has data (can't proact without knowing what's on screen)

This separates the "when to speak" logic from the "what to say" logic.
The PersonalityEngine generates the messages; this engine decides when.
"""

from __future__ import annotations

import asyncio
import time
from typing import Optional

from loguru import logger

from core.events.event_bus import EventBus, LLMStreamChunkEvent


class ProactiveEngine:
    """
    Background task that monitors state and triggers proactive TTS messages.

    Args:
        event_bus:          Shared EventBus.
        is_speaking:        threading.Event set while TTS is active.
        poll_interval:      Seconds between proactive checks.
        silence_required:   Seconds of silence required before speaking.
    """

    def __init__(
        self,
        event_bus: EventBus,
        is_speaking,
        poll_interval: float = 30.0,
        silence_required: float = 30.0,
    ) -> None:
        self._bus = event_bus
        self._is_speaking = is_speaking
        self._poll_interval = poll_interval
        self._silence_required = silence_required

        self._last_user_activity = time.time()
        self._running = False

        # Component references (injected after init)
        self._personality = None
        self._vision = None
        self._coding_assistant = None

    def inject_components(self, personality, vision, coding_assistant=None) -> None:
        """Inject references to other pipeline components."""
        self._personality = personality
        self._vision = vision
        self._coding_assistant = coding_assistant

    def record_user_activity(self) -> None:
        """Call this whenever the user speaks or sends a message."""
        self._last_user_activity = time.time()

    # ── Main loop ─────────────────────────────────────────────

    async def run(self) -> None:
        """Long-running asyncio task. Add to pipeline with create_task()."""
        self._running = True
        logger.info("ProactiveEngine: started")

        while self._running:
            await asyncio.sleep(self._poll_interval)

            try:
                await self._check_and_deliver()
            except Exception as e:
                logger.error(f"ProactiveEngine: check error: {e}", exc_info=True)

    async def stop(self) -> None:
        self._running = False
        logger.info("ProactiveEngine: stopped")

    # ── Check logic ──────────────────────────────────────────

    async def _check_and_deliver(self) -> None:
        """Run all trigger checks and deliver at most one message."""

        # Gate: don't interrupt if speaking
        if self._is_speaking.is_set():
            return

        # Gate: don't interrupt if user recently spoke
        silence_sec = time.time() - self._last_user_activity
        if silence_sec < self._silence_required:
            return

        # Gate: personality must enable proactive
        if not self._personality:
            return
        if not self._personality.should_speak_proactively(is_in_conversation=False):
            return

        # Gather context
        vision_ctx = self._vision.get_context() if self._vision else None
        productivity = (
            self._vision.get_productivity_report()
            if self._vision else None
        )

        # Check triggers in priority order
        message = await self._check_distraction(vision_ctx, productivity)
        if not message:
            message = await self._check_work_sprint(productivity)
        if not message:
            message = await self._check_context_switching(productivity)
        if not message:
            message = await self._check_coding_error(vision_ctx)
        if not message:
            message = await self._check_time_triggers()
        if not message:
            message = await self._check_idle(silence_sec)

        if message:
            await self._deliver(message)

    async def _check_distraction(self, vision_ctx, productivity) -> Optional[str]:
        if not (vision_ctx and vision_ctx.window_snapshot):
            return None

        win = vision_ctx.window_snapshot.active_window
        if not win or not win.is_distraction:
            return None

        if not productivity:
            return None

        streak_min = productivity.current_streak_min
        if streak_min < 5:
            return None

        msg = self._personality.generate_proactive_message(
            "distraction",
            {"app": win.process_name, "minutes": int(streak_min)},
        )
        return msg.message if msg else None

    async def _check_work_sprint(self, productivity) -> Optional[str]:
        if not productivity:
            return None
        if productivity.current_streak_type != "productive":
            return None
        if productivity.current_streak_min < 90:
            return None

        hours = round(productivity.current_streak_min / 60, 1)
        msg = self._personality.generate_proactive_message(
            "work_sprint", {"hours": hours}
        )
        return msg.message if msg else None

    async def _check_context_switching(self, productivity) -> Optional[str]:
        if not productivity:
            return None
        if productivity.context_switches_per_hour < 20:
            return None

        msg = self._personality.generate_proactive_message(
            "context_switch",
            {"count": int(productivity.context_switches_per_hour)},
        )
        return msg.message if msg else None

    async def _check_coding_error(self, vision_ctx) -> Optional[str]:
        if not (vision_ctx and vision_ctx.ocr_page):
            return None
        if not self._coding_assistant:
            return None
        if not vision_ctx.window_snapshot:
            return None

        win = vision_ctx.window_snapshot.active_window
        if not win:
            return None

        code_ctx = self._coding_assistant.extract_context(
            window_title=win.title,
            process_name=win.process_name,
            ocr_text=vision_ctx.ocr_page.full_text,
        )

        if code_ctx and self._coding_assistant.should_alert_error(code_ctx):
            return (
                f"I see an error in your {code_ctx.language} code. "
                f"Say 'help me fix this' and I'll analyse it."
            )
        return None

    async def _check_time_triggers(self) -> Optional[str]:
        if not self._personality:
            return None
        msg = self._personality.check_time_triggers()
        return msg.message if msg else None

    async def _check_idle(self, silence_sec: float) -> Optional[str]:
        # Only fire if idle for > 20 min (1200s)
        if silence_sec < 1200:
            return None

        idle_min = int(silence_sec / 60)
        msg = self._personality.generate_proactive_message(
            "idle", {"minutes": idle_min}
        )
        return msg.message if msg else None

    async def _deliver(self, message: str) -> None:
        """Publish the proactive message directly to TTS via stream chunk event."""
        logger.info(f"ProactiveEngine: delivering: {message[:80]}")
        await self._bus.publish(LLMStreamChunkEvent(chunk=message, sequence=0))

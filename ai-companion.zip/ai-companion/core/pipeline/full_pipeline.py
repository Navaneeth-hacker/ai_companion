"""
core/pipeline/full_pipeline.py
================================
Production pipeline — all phases integrated.

Phase 1: Wake word → STT → LLM → TTS
Phase 2: Vision, OCR, window detection, productivity
Phase 3: Desktop automation with permission system
Phase 4: Persistent memory (SQLite + ChromaDB)
Phase 5: Adaptive learning, prompt adaptation
Phase 6: Multimodal vision LLM, coding assistant, proactive engine
"""

from __future__ import annotations

import asyncio
import signal
import threading
import time
from pathlib import Path
from typing import Dict, Optional

from loguru import logger

from config.config import Settings
from core.events.event_bus import (
    EventBus, bus,
    SystemStatusEvent, WakeWordEvent, TranscriptionEvent,
    LLMResponseEvent, InterruptEvent, LLMStreamChunkEvent,
)
from core.context.context_manager import ContextManager
from core.pipeline.proactive_engine import ProactiveEngine
from audio.wake_word.wake_word_engine import WakeWordEngine
from audio.stt.stt_engine import STTEngine
from audio.llm.llm_engine import LLMEngine
from audio.tts.tts_engine import TTSEngine
from vision.vision_engine import VisionEngine
from vision.multimodal_engine import MultimodalEngine, has_visual_intent
from automation.permission_system import PermissionSystem
from automation.automation_engine import AutomationEngine
from automation.coding_assistant import CodingAssistant
from memory.memory_engine import MemoryEngine
from learning.learning_engine import LearningEngine
from personality.personality_engine import PersonalityEngine


class FullPipeline:
    """Production AI companion pipeline — all phases integrated."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._is_speaking = threading.Event()
        self._shutdown_event = asyncio.Event()
        self._component_status: Dict[str, str] = {}
        self._session_start = time.time()
        self._last_memory_summary = time.time()
        self._last_user_turn = time.time()

        # Engine refs
        self._wake_word: Optional[WakeWordEngine] = None
        self._stt: Optional[STTEngine] = None
        self._llm: Optional[LLMEngine] = None
        self._tts: Optional[TTSEngine] = None
        self._context: Optional[ContextManager] = None
        self._vision: Optional[VisionEngine] = None
        self._multimodal: Optional[MultimodalEngine] = None
        self._perms: Optional[PermissionSystem] = None
        self._automation: Optional[AutomationEngine] = None
        self._coding_assistant: Optional[CodingAssistant] = None
        self._memory: Optional[MemoryEngine] = None
        self._learning: Optional[LearningEngine] = None
        self._personality: Optional[PersonalityEngine] = None
        self._proactive: Optional[ProactiveEngine] = None

    # ── Public API ──────────────────────────────────────────

    async def run(self) -> None:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._signal_handler)
        try:
            await self._initialize(loop)
            logger.info("FullPipeline: all systems ready")
            await asyncio.gather(
                self._shutdown_event.wait(),
                self._maintenance_loop(),
                self._proactive.run() if self._proactive else asyncio.sleep(0),
            )
        except Exception as e:
            logger.critical(f"FullPipeline: fatal: {e}", exc_info=True)
        finally:
            await self._shutdown()

    async def health(self) -> Dict[str, str]:
        return dict(self._component_status)

    # ── Initialization ───────────────────────────────────────

    async def _initialize(self, loop: asyncio.AbstractEventLoop) -> None:
        bus.subscribe(SystemStatusEvent, self._on_system_status)
        asyncio.create_task(bus.run(), name="event-bus")

        # 1. Memory
        logger.info("Pipeline: initializing memory...")
        self._memory = MemoryEngine(
            db_path=self._settings.app.data_dir / "companion.db",
            vector_db_path=self._settings.app.data_dir / "chroma",
        )
        await self._memory.initialize()
        self._component_status["memory"] = "ready"

        # 2. Personality
        self._personality = PersonalityEngine(
            style=self._settings.personality.style,
            proactive_enabled=self._settings.personality.proactive,
            proactive_interval_sec=self._settings.personality.proactive_interval_sec,
            name=self._settings.personality.name,
        )
        self._component_status["personality"] = "ready"

        # 3. Context
        self._context = ContextManager(
            system_prompt=(
                self._personality.get_style_directive()
                + "\n\n"
                + self._settings.llm.system_prompt
            ),
            max_tokens=self._settings.llm.context_window,
        )

        # 4. Learning
        self._learning = LearningEngine(
            base_prompt=self._context._system_prompt,
            memory_engine=self._memory,
        )
        self._component_status["learning"] = "ready"

        # 5. STT
        logger.info("Pipeline: loading STT...")
        self._stt = STTEngine(
            event_bus=bus,
            model=self._settings.stt.model,
            device=self._settings.stt.device,
            compute_type=self._settings.stt.compute_type,
            language=self._settings.stt.language,
            sample_rate=self._settings.audio.sample_rate,
            silence_timeout=self._settings.audio.silence_timeout,
            max_record_sec=self._settings.audio.max_record_sec,
            vad_filter=self._settings.stt.vad_filter,
        )
        await self._stt.load()

        # 6. TTS
        logger.info("Pipeline: loading TTS...")
        self._tts = TTSEngine(
            event_bus=bus,
            model_path=self._settings.tts.model_path,
            config_path=self._settings.tts.config_path,
            speaking_rate=self._settings.tts.speaking_rate,
            volume=self._settings.tts.volume,
            sample_rate=self._settings.tts.sample_rate,
            output_device=self._settings.tts.output_device,
            is_speaking=self._is_speaking,
        )
        await self._tts.load()

        # 7. LLM
        logger.info("Pipeline: connecting to LLM...")
        self._llm = LLMEngine(
            event_bus=bus,
            context_manager=self._context,
            base_url=self._settings.llm.base_url,
            model=self._settings.llm.model,
            temperature=self._settings.llm.temperature,
            top_p=self._settings.llm.top_p,
            max_tokens=self._settings.llm.max_tokens,
            stream=self._settings.llm.stream,
            request_timeout=self._settings.llm.request_timeout,
        )
        await self._llm.start()

        # 8. Automation
        self._perms = PermissionSystem(
            audit_log_path=self._settings.security.audit_log_path,
        )
        self._automation = AutomationEngine(permission_system=self._perms)
        self._component_status["automation"] = "ready"

        # 9. Vision
        logger.info("Pipeline: starting vision engine...")
        self._vision = VisionEngine(
            event_bus=bus,
            event_loop=loop,
            poll_interval=2.0,
            ocr_enabled=True,
            productivity_enabled=True,
        )
        self._vision.start()

        # 10. Multimodal (Phase 6)
        self._multimodal = MultimodalEngine(
            ollama_base_url=self._settings.llm.base_url,
            vision_model="qwen2-vl:7b",
            screen_capture=self._vision._capture,
        )
        await self._multimodal.initialize()
        self._component_status["multimodal"] = "ready"

        # 11. Coding assistant (Phase 6)
        self._coding_assistant = CodingAssistant(llm_engine=self._llm)

        # 12. Proactive engine (Phase 6)
        self._proactive = ProactiveEngine(
            event_bus=bus,
            is_speaking=self._is_speaking,
            poll_interval=30.0,
            silence_required=30.0,
        )
        self._proactive.inject_components(
            personality=self._personality,
            vision=self._vision,
            coding_assistant=self._coding_assistant,
        )

        # 13. Subscribe to enrichment handlers
        bus.subscribe(TranscriptionEvent, self._on_transcription_enriched)
        bus.subscribe(LLMResponseEvent, self._on_llm_response)
        bus.subscribe(WakeWordEvent, self._on_wake)

        # 14. Wake word (last — starts listening)
        if self._settings.wake_word.enabled:
            self._wake_word = WakeWordEngine(
                event_bus=bus,
                event_loop=loop,
                model_name=self._settings.wake_word.model_name,
                wake_words=self._settings.wake_word.wake_words,
                threshold=self._settings.wake_word.threshold,
                sample_rate=self._settings.audio.sample_rate,
                is_speaking=self._is_speaking,
            )
            self._wake_word.start()
            self._component_status["wake_word"] = "ready"

        # Startup announcement
        personality_name = self._settings.personality.name
        await self._tts.speak(
            f"{personality_name} is online. Say 'wake up' to begin."
        )

    # ── Event handlers ───────────────────────────────────────

    async def _on_wake(self, event: WakeWordEvent) -> None:
        """Record user activity for proactive engine gating."""
        if self._proactive:
            self._proactive.record_user_activity()

    async def _on_transcription_enriched(self, event: TranscriptionEvent) -> None:
        """
        Intercept every transcription to:
          1. Record user activity (silence timer reset)
          2. Persist to memory
          3. Check for visual intent (route to multimodal)
          4. Build enriched system prompt with vision + memory context
        """
        self._last_user_turn = time.time()
        if self._proactive:
            self._proactive.record_user_activity()

        # Persist user turn
        if self._memory:
            await self._memory.save_turn("user", event.text)

        # Visual intent routing (Phase 6)
        if self._multimodal and has_visual_intent(event.text):
            logger.info(f"Pipeline: visual intent detected — routing to multimodal")
            response = await self._multimodal.answer_visual_question(event.text)
            # Bypass LLM; speak directly
            await self._tts.speak(response)
            if self._memory:
                await self._memory.save_turn("assistant", response)
            return

        # Build enriched system prompt
        vision_ctx = self._vision.get_llm_context_string() if self._vision else ""
        memory_ctx = ""
        if self._memory:
            memory_ctx = await self._memory.get_context_string(event.text)

        if self._learning:
            enriched = self._learning.build_system_prompt(
                vision_context=vision_ctx,
                memory_context=memory_ctx,
            )
            self._context._system_prompt = enriched

    async def _on_llm_response(self, event: LLMResponseEvent) -> None:
        """Persist assistant response to memory."""
        if self._memory and event.is_final:
            await self._memory.save_turn("assistant", event.text)

    async def _on_system_status(self, event: SystemStatusEvent) -> None:
        self._component_status[event.component] = event.status

    # ── Maintenance ──────────────────────────────────────────

    async def _maintenance_loop(self) -> None:
        while not self._shutdown_event.is_set():
            await asyncio.sleep(300)
            try:
                # Session summarisation every 30 min
                if self._memory and self._llm:
                    if time.time() - self._last_memory_summary > 1800:
                        await self._memory.summarize_session(self._llm)
                        self._last_memory_summary = time.time()

                # Log productivity report
                if self._vision:
                    report = self._vision.get_productivity_report()
                    if report:
                        logger.info(
                            f"Productivity: score={report.score} "
                            f"productive={report.productive_pct:.0f}% "
                            f"distraction={report.distraction_pct:.0f}% "
                            f"streak={report.current_streak_min:.0f}m "
                            f"{report.current_streak_type}"
                        )
            except Exception as e:
                logger.error(f"Pipeline: maintenance error: {e}")

    # ── Shutdown ─────────────────────────────────────────────

    def _signal_handler(self) -> None:
        logger.info("Pipeline: shutdown signal received")
        self._shutdown_event.set()

    async def _shutdown(self) -> None:
        logger.info("Pipeline: shutting down...")
        if self._proactive: await self._proactive.stop()
        if self._wake_word: self._wake_word.stop()
        if self._vision: self._vision.stop()
        if self._stt: await self._stt.unload()
        if self._llm: await self._llm.stop()
        if self._tts: await self._tts.stop()
        if self._multimodal: await self._multimodal.close()
        if self._memory: await self._memory.close()
        await bus.stop()
        logger.info("Pipeline: shutdown complete")

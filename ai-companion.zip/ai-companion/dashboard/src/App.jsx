// dashboard/src/App.jsx
// Main dashboard shell — tabs for Status, Memory, Automation, Settings

import { useState, useEffect, useRef } from "react";

const API = "http://127.0.0.1:8765";

// ── Hook: poll API endpoint ──────────────────────────────────
function usePoll(endpoint, interval = 2000) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    const fetch_ = async () => {
      try {
        const r = await fetch(API + endpoint);
        if (!active) return;
        if (r.ok) setData(await r.json());
        else setError(r.status);
      } catch (e) {
        if (active) setError(e.message);
      }
    };
    fetch_();
    const id = setInterval(fetch_, interval);
    return () => { active = false; clearInterval(id); };
  }, [endpoint, interval]);

  return { data, error };
}

// ── Hook: WebSocket event stream ────────────────────────────
function useEventStream() {
  const [events, setEvents] = useState([]);
  const ws = useRef(null);

  useEffect(() => {
    const connect = () => {
      ws.current = new WebSocket("ws://127.0.0.1:8765/ws/events");
      ws.current.onmessage = (e) => {
        const event = JSON.parse(e.data);
        setEvents(prev => [event, ...prev].slice(0, 100));
      };
      ws.current.onclose = () => setTimeout(connect, 3000);
    };
    connect();
    return () => ws.current?.close();
  }, []);

  return events;
}

// ── Status dot ───────────────────────────────────────────────
function StatusDot({ status }) {
  const colors = {
    ready: "#22c55e", busy: "#f59e0b", error: "#ef4444",
    uninitialized: "#6b7280", shutdown: "#6b7280",
  };
  return (
    <span style={{
      display: "inline-block", width: 8, height: 8,
      borderRadius: "50%", backgroundColor: colors[status] || "#6b7280",
      marginRight: 6,
    }} />
  );
}

// ── Status Panel ─────────────────────────────────────────────
function StatusPanel() {
  const { data: health } = usePoll("/health", 2000);
  const { data: status } = usePoll("/status", 5000);
  const events = useEventStream();

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>

      {/* Component health */}
      <div style={card}>
        <h3 style={cardTitle}>Component Health</h3>
        {health?.components ? (
          Object.entries(health.components).map(([name, state]) => (
            <div key={name} style={row}>
              <StatusDot status={state} />
              <span style={{ color: "var(--fg)", textTransform: "capitalize" }}>{name}</span>
              <span style={{ marginLeft: "auto", color: "var(--fg2)", fontSize: 12 }}>{state}</span>
            </div>
          ))
        ) : <div style={{ color: "var(--fg2)" }}>Connecting…</div>}
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--border)" }}>
          <div style={{ color: "var(--fg2)", fontSize: 12 }}>
            Uptime: {health?.uptime_sec ? `${Math.floor(health.uptime_sec / 60)}m ${Math.floor(health.uptime_sec % 60)}s` : "—"}
          </div>
          <div style={{ color: "var(--fg2)", fontSize: 12, marginTop: 4 }}>
            Overall: <span style={{ color: health?.status === "healthy" ? "#22c55e" : "#f59e0b" }}>
              {health?.status || "unknown"}
            </span>
          </div>
        </div>
      </div>

      {/* GPU / System resources */}
      <div style={card}>
        <h3 style={cardTitle}>System Resources</h3>
        {status ? (
          <>
            <div style={row}>
              <span style={{ color: "var(--fg2)" }}>GPU</span>
              <span style={{ color: "var(--fg)", fontSize: 12 }}>
                {status.gpu?.available
                  ? `${status.gpu.name} — ${status.gpu.vram_used_gb}/${status.gpu.vram_total_gb} GB`
                  : "CPU only"
                }
              </span>
            </div>
            <div style={row}>
              <span style={{ color: "var(--fg2)" }}>RAM</span>
              <span style={{ color: "var(--fg)", fontSize: 12 }}>
                {status.memory?.available_gb}GB free / {status.memory?.total_gb}GB total
              </span>
            </div>
            <div style={row}>
              <span style={{ color: "var(--fg2)" }}>LLM model</span>
              <span style={{ color: "var(--accent)", fontSize: 12 }}>{status.config?.llm_model}</span>
            </div>
            <div style={row}>
              <span style={{ color: "var(--fg2)" }}>STT model</span>
              <span style={{ color: "var(--accent)", fontSize: 12 }}>Whisper {status.config?.stt_model}</span>
            </div>
          </>
        ) : <div style={{ color: "var(--fg2)" }}>Loading…</div>}
      </div>

      {/* Live event stream */}
      <div style={{ ...card, gridColumn: "1 / -1" }}>
        <h3 style={cardTitle}>Live Events</h3>
        <div style={{ fontFamily: "monospace", fontSize: 12, maxHeight: 240, overflowY: "auto" }}>
          {events.length === 0 && (
            <div style={{ color: "var(--fg2)" }}>Waiting for events… (say "wake up")</div>
          )}
          {events.map((e, i) => (
            <div key={i} style={{
              padding: "3px 0", borderBottom: "1px solid var(--border)",
              color: e.type === "SystemStatusEvent" ? "var(--fg2)" : "var(--fg)",
            }}>
              <span style={{ color: "var(--accent)", marginRight: 8 }}>{e.type}</span>
              {e.data?.text || e.data?.chunk || e.data?.status || e.data?.component || ""}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Context Panel ─────────────────────────────────────────────
function ContextPanel() {
  const { data: ctx } = usePoll("/context", 3000);
  const [askText, setAskText] = useState("");
  const [asking, setAsking] = useState(false);

  const ask = async () => {
    if (!askText.trim()) return;
    setAsking(true);
    await fetch(API + "/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: askText }),
    });
    setAskText("");
    setAsking(false);
  };

  const clearCtx = async () => {
    await fetch(API + "/context", { method: "DELETE" });
  };

  return (
    <div>
      {/* Text input */}
      <div style={card}>
        <h3 style={cardTitle}>Send Message</h3>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            value={askText}
            onChange={e => setAskText(e.target.value)}
            onKeyDown={e => e.key === "Enter" && ask()}
            placeholder="Type a message to the AI…"
            style={inputStyle}
          />
          <button onClick={ask} disabled={asking} style={btnStyle}>
            {asking ? "…" : "Send"}
          </button>
        </div>
      </div>

      {/* Conversation context */}
      <div style={card}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <h3 style={{ ...cardTitle, margin: 0 }}>Conversation Context</h3>
          <button onClick={clearCtx} style={{ ...btnStyle, background: "var(--border)", color: "var(--fg2)", padding: "4px 10px", fontSize: 12 }}>
            Clear
          </button>
        </div>
        <div style={{ color: "var(--fg2)", fontSize: 12, marginBottom: 8 }}>
          {ctx?.summary || "No context loaded"}
        </div>
        <div style={{ maxHeight: 400, overflowY: "auto" }}>
          {ctx?.messages?.slice(1).map((m, i) => (
            <div key={i} style={{
              marginBottom: 12,
              padding: "8px 12px",
              borderRadius: 8,
              background: m.role === "user" ? "var(--surface2)" : "var(--surface)",
              borderLeft: `3px solid ${m.role === "user" ? "var(--accent)" : "var(--fg2)"}`,
            }}>
              <div style={{ color: "var(--accent)", fontSize: 11, marginBottom: 4, textTransform: "uppercase" }}>
                {m.role}
              </div>
              <div style={{ color: "var(--fg)", fontSize: 13, lineHeight: 1.5 }}>
                {m.content}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Productivity Panel ───────────────────────────────────────
function ProductivityPanel() {
  const { data: status } = usePoll("/status", 3000);

  return (
    <div style={card}>
      <h3 style={cardTitle}>Productivity</h3>
      <div style={{ color: "var(--fg2)", fontSize: 13 }}>
        Connect the productivity endpoint in Phase 2 integration for live stats.
      </div>
    </div>
  );
}

// ── Settings Panel ───────────────────────────────────────────
function SettingsPanel() {
  const { data: cfg } = usePoll("/config", 30000);

  const interrupt = async () => {
    await fetch(API + "/interrupt", { method: "POST" });
  };

  const speak = async (text) => {
    await fetch(API + "/speak", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
  };

  return (
    <div>
      <div style={card}>
        <h3 style={cardTitle}>Controls</h3>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button onClick={interrupt} style={{ ...btnStyle, background: "#ef4444" }}>
            ⏹ Interrupt
          </button>
          <button onClick={() => speak("I am ready and listening.")} style={btnStyle}>
            🔊 Test TTS
          </button>
        </div>
      </div>
      <div style={card}>
        <h3 style={cardTitle}>Current Config</h3>
        {cfg ? (
          <pre style={{ fontSize: 11, color: "var(--fg2)", overflow: "auto", maxHeight: 400 }}>
            {JSON.stringify(cfg, null, 2)}
          </pre>
        ) : <div style={{ color: "var(--fg2)" }}>Loading…</div>}
      </div>
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────
const TABS = ["Status", "Context", "Productivity", "Settings"];

export default function App() {
  const [tab, setTab] = useState("Status");

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--fg)", fontFamily: "system-ui, sans-serif" }}>

      {/* Header */}
      <div style={{
        padding: "16px 24px",
        borderBottom: "1px solid var(--border)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "var(--surface)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>
            🤖
          </div>
          <span style={{ fontWeight: 600, fontSize: 16 }}>AI Companion</span>
          <span style={{ color: "var(--fg2)", fontSize: 12 }}>Dashboard</span>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              padding: "6px 14px", borderRadius: 6, border: "none",
              cursor: "pointer", fontSize: 13, fontWeight: 500,
              background: tab === t ? "var(--accent)" : "transparent",
              color: tab === t ? "#fff" : "var(--fg2)",
              transition: "background 0.15s",
            }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: "24px", maxWidth: 1100, margin: "0 auto" }}>
        {tab === "Status" && <StatusPanel />}
        {tab === "Context" && <ContextPanel />}
        {tab === "Productivity" && <ProductivityPanel />}
        {tab === "Settings" && <SettingsPanel />}
      </div>
    </div>
  );
}

// ── Shared styles ─────────────────────────────────────────────
const card = {
  background: "var(--surface)",
  border: "1px solid var(--border)",
  borderRadius: 12,
  padding: "16px 20px",
  marginBottom: 16,
};

const cardTitle = {
  margin: "0 0 14px 0",
  fontSize: 14,
  fontWeight: 600,
  color: "var(--fg)",
};

const row = {
  display: "flex",
  alignItems: "center",
  padding: "6px 0",
  borderBottom: "1px solid var(--border)",
  gap: 8,
  fontSize: 13,
};

const inputStyle = {
  flex: 1,
  background: "var(--surface2)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  padding: "8px 12px",
  color: "var(--fg)",
  fontSize: 14,
  outline: "none",
};

const btnStyle = {
  background: "var(--accent)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "8px 16px",
  cursor: "pointer",
  fontSize: 13,
  fontWeight: 500,
};

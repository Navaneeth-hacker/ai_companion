"""
tests/test_phase1.py
====================
Phase 1 test suite.

Tests:
  1. Config loading
  2. EventBus publish/subscribe
  3. ContextManager pruning logic
  4. STTEngine device resolution
  5. LLM sentence boundary splitting
  6. Pipeline health endpoint (integration)

Run with:
  pytest tests/test_phase1.py -v
  pytest tests/test_phase1.py -v --tb=short   # brief tracebacks
  pytest tests/test_phase1.py -v -k "test_event"  # specific tests

Markers:
  @pytest.mark.slow    — tests that require model loading
  @pytest.mark.network — tests that require Ollama to be running
"""

from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Config tests ────────────────────────────────────────────

def test_config_loads():
    from config.config import load_settings
    s = load_settings()
    assert s.app.version
    assert s.llm.model
    assert s.audio.sample_rate == 16000


def test_config_env_override(monkeypatch):
    monkeypatch.setenv("AI_COMPANION_LLM__MODEL", "qwen2.5:14b")
    from importlib import reload
    import config.config as cfg
    # We can't easily reload the singleton, but we can test load_settings directly
    # with the env var set
    s = cfg.load_settings()
    # The model should come from the default TOML or env override
    assert isinstance(s.llm.model, str)


def test_config_ensures_dirs(tmp_path):
    from config.config import load_settings
    s = load_settings()
    s.app.log_dir = tmp_path / "logs"
    s.app.data_dir = tmp_path / "data"
    s.ensure_dirs()
    assert s.app.log_dir.exists()
    assert s.app.data_dir.exists()


# ── EventBus tests ──────────────────────────────────────────

class TestEventBus:

    @pytest.fixture
    def bus(self):
        from core.events.event_bus import EventBus
        return EventBus()

    @pytest.mark.asyncio
    async def test_subscribe_and_publish(self, bus):
        from core.events.event_bus import WakeWordEvent

        received = []

        async def handler(event: WakeWordEvent):
            received.append(event)

        bus.subscribe(WakeWordEvent, handler)

        # Start bus task
        task = asyncio.create_task(bus.run())
        await bus.publish(WakeWordEvent(word="wake up", confidence=0.9))
        await asyncio.sleep(0.1)   # Let the dispatch loop run
        await bus.stop()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        assert len(received) == 1
        assert received[0].word == "wake up"
        assert received[0].confidence == 0.9

    @pytest.mark.asyncio
    async def test_multiple_handlers(self, bus):
        from core.events.event_bus import TranscriptionEvent

        calls = []

        async def h1(e): calls.append(("h1", e.text))
        async def h2(e): calls.append(("h2", e.text))

        bus.subscribe(TranscriptionEvent, h1)
        bus.subscribe(TranscriptionEvent, h2)

        task = asyncio.create_task(bus.run())
        await bus.publish(TranscriptionEvent(text="hello", language="en"))
        await asyncio.sleep(0.1)
        await bus.stop()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        assert ("h1", "hello") in calls
        assert ("h2", "hello") in calls

    @pytest.mark.asyncio
    async def test_unsubscribe(self, bus):
        from core.events.event_bus import WakeWordEvent

        calls = []

        async def handler(e): calls.append(e)

        bus.subscribe(WakeWordEvent, handler)
        bus.unsubscribe(WakeWordEvent, handler)

        task = asyncio.create_task(bus.run())
        await bus.publish(WakeWordEvent(word="test", confidence=0.8))
        await asyncio.sleep(0.1)
        await bus.stop()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        assert len(calls) == 0

    @pytest.mark.asyncio
    async def test_handler_exception_does_not_crash_bus(self, bus):
        from core.events.event_bus import WakeWordEvent

        async def bad_handler(e):
            raise ValueError("intentional test error")

        async def good_handler(e):
            pass   # Should still be called

        bus.subscribe(WakeWordEvent, bad_handler)
        bus.subscribe(WakeWordEvent, good_handler)

        task = asyncio.create_task(bus.run())
        # This should NOT raise; the bus handles handler exceptions internally
        await bus.publish(WakeWordEvent(word="test", confidence=0.5))
        await asyncio.sleep(0.1)
        await bus.stop()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        # If we got here, the bus didn't crash


# ── ContextManager tests ─────────────────────────────────────

class TestContextManager:

    def make_ctx(self, max_tokens=1000, max_turns=5):
        from core.context.context_manager import ContextManager
        return ContextManager(
            system_prompt="You are a test assistant.",
            max_tokens=max_tokens,
            max_turns=max_turns,
        )

    @pytest.mark.asyncio
    async def test_add_and_retrieve_messages(self):
        ctx = self.make_ctx()
        await ctx.add_user_message("Hello")
        await ctx.add_assistant_message("Hi there!")

        messages = await ctx.get_messages()
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "Hello"
        assert messages[2]["role"] == "assistant"
        assert messages[2]["content"] == "Hi there!"

    @pytest.mark.asyncio
    async def test_turn_count(self):
        ctx = self.make_ctx()
        assert ctx.turn_count == 0
        await ctx.add_user_message("Turn 1")
        await ctx.add_assistant_message("Response 1")
        assert ctx.turn_count == 1
        await ctx.add_user_message("Turn 2")
        await ctx.add_assistant_message("Response 2")
        assert ctx.turn_count == 2

    @pytest.mark.asyncio
    async def test_clear(self):
        ctx = self.make_ctx()
        await ctx.add_user_message("Test")
        await ctx.clear()
        messages = await ctx.get_messages()
        # Should only have the system message
        assert len(messages) == 1
        assert messages[0]["role"] == "system"

    @pytest.mark.asyncio
    async def test_max_turns_pruning(self):
        ctx = self.make_ctx(max_turns=2)
        for i in range(5):
            await ctx.add_user_message(f"Message {i}")
            await ctx.add_assistant_message(f"Response {i}")

        messages = await ctx.get_messages()
        # System + 2*2 max turns = 5 messages max
        assert len(messages) <= 1 + (2 * 2 * 2)  # generous upper bound

    @pytest.mark.asyncio
    async def test_token_budget_pruning(self):
        # Very tight budget — should force pruning
        ctx = self.make_ctx(max_tokens=100)
        # Add many messages that collectively exceed the budget
        for i in range(10):
            await ctx.add_user_message("A" * 50)
            await ctx.add_assistant_message("B" * 50)

        # The total estimated tokens should be within budget
        assert ctx.estimated_token_count <= 100


# ── STT engine unit tests ────────────────────────────────────

class TestSTTEngine:

    def test_device_resolution_cpu(self, monkeypatch):
        # Patch torch to appear unavailable
        monkeypatch.setitem(sys.modules, "torch", None)
        from audio.stt.stt_engine import STTEngine
        assert STTEngine._resolve_device("cpu") == "cpu"

    def test_device_resolution_explicit(self):
        from audio.stt.stt_engine import STTEngine
        assert STTEngine._resolve_device("cuda") == "cuda"
        assert STTEngine._resolve_device("cpu") == "cpu"

    def test_compute_type_gpu(self):
        from audio.stt.stt_engine import STTEngine
        assert STTEngine._resolve_compute_type("auto", "cuda") == "float16"

    def test_compute_type_cpu(self):
        from audio.stt.stt_engine import STTEngine
        assert STTEngine._resolve_compute_type("auto", "cpu") == "int8"

    def test_compute_type_explicit(self):
        from audio.stt.stt_engine import STTEngine
        assert STTEngine._resolve_compute_type("int8_float16", "cuda") == "int8_float16"


# ── LLM sentence boundary tests ─────────────────────────────

class TestLLMSentenceBoundary:

    def test_sentence_split_period(self):
        import re
        from audio.llm.llm_engine import SENTENCE_BOUNDARY
        text = "Hello world. This is a test."
        parts = SENTENCE_BOUNDARY.split(text, maxsplit=1)
        assert parts[0].strip() == "Hello world."

    def test_sentence_split_exclamation(self):
        from audio.llm.llm_engine import SENTENCE_BOUNDARY
        text = "Watch out! The server is down."
        parts = SENTENCE_BOUNDARY.split(text, maxsplit=1)
        assert parts[0].strip() == "Watch out!"

    def test_sentence_no_boundary(self):
        from audio.llm.llm_engine import SENTENCE_BOUNDARY
        text = "No boundary here"
        parts = SENTENCE_BOUNDARY.split(text, maxsplit=1)
        assert len(parts) == 1


# ── Integration test — API health endpoint ───────────────────

@pytest.mark.asyncio
async def test_api_health_no_pipeline():
    """Health endpoint should return 200 even without a pipeline."""
    from fastapi.testclient import TestClient
    from api.gateway import app

    with TestClient(app) as client:
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert "status" in data
        assert "uptime_sec" in data


@pytest.mark.network
@pytest.mark.asyncio
async def test_ollama_connectivity():
    """Verify Ollama is reachable (requires ollama serve to be running)."""
    import httpx
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get("http://localhost:11434/api/tags", timeout=5.0)
            assert resp.status_code == 200
            data = resp.json()
            assert "models" in data
        except httpx.ConnectError:
            pytest.skip("Ollama is not running")


# ── Helpers ─────────────────────────────────────────────────

import sys   # needed for monkeypatch test above

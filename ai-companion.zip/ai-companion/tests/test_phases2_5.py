"""
tests/test_phases2_5.py
========================
Test suite for Phases 2–5.

Covers:
  - Vision: change detection, window classification
  - OCR: preprocessing, result parsing
  - Productivity: scoring, intervention triggers
  - Automation: permission system, action classification
  - Memory: SQLite persistence, ChromaDB retrieval
  - Learning: preference tracking, pattern detection
  - Personality: style directives, proactive messages
"""

from __future__ import annotations

import asyncio
import time
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

import numpy as np
import pytest


# ── Vision: ScreenCapture ────────────────────────────────────

class TestScreenCapture:

    def test_change_detection_identical_frames(self):
        """Identical frames should report no change."""
        from vision.screen_capture import ScreenCapture, ScreenFrame

        cap = ScreenCapture.__new__(ScreenCapture)
        cap._change_threshold = 5.0
        cap._prev_gray = None

        import cv2
        frame = ScreenFrame(
            image=np.zeros((720, 1280, 3), dtype=np.uint8),
            timestamp=time.time(), width=1280, height=720,
        )
        # First frame always reports changed
        assert cap._has_changed(frame) is True

        # Same frame again → no change
        assert cap._has_changed(frame) is False

    def test_change_detection_different_frames(self):
        """Different frames should report change."""
        from vision.screen_capture import ScreenCapture, ScreenFrame
        import cv2

        cap = ScreenCapture.__new__(ScreenCapture)
        cap._change_threshold = 5.0
        cap._prev_gray = None

        f1 = ScreenFrame(
            image=np.zeros((720, 1280, 3), dtype=np.uint8),
            timestamp=time.time(), width=1280, height=720,
        )
        f2 = ScreenFrame(
            image=np.ones((720, 1280, 3), dtype=np.uint8) * 200,
            timestamp=time.time(), width=1280, height=720,
        )

        cap._has_changed(f1)              # Prime the prev_gray
        assert cap._has_changed(f2) is True


# ── Vision: WindowDetector ───────────────────────────────────

class TestWindowDetector:

    def test_classify_coding_vscode(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        cat = d._classify_process("code.exe", "main.py — VS Code")
        assert cat == "coding"

    def test_classify_browser_chrome(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        cat = d._classify_process("chrome.exe", "GitHub")
        assert cat == "browser"

    def test_classify_gaming(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        cat = d._classify_process("steam.exe", "Steam")
        assert cat == "gaming"

    def test_distraction_youtube(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        assert d._check_distraction("chrome.exe", "My Video - YouTube", "browser") is True

    def test_productive_github(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        assert d._check_productive("chrome.exe", "github.com/user/repo", "browser") is True

    def test_distraction_gaming(self):
        from vision.window_detector import WindowDetector
        d = WindowDetector()
        assert d._check_distraction("steam.exe", "Steam", "gaming") is True


# ── Productivity Analyzer ────────────────────────────────────

class TestProductivityAnalyzer:

    def _make_snapshot(self, is_productive=True, is_distraction=False, proc="code.exe", cat="coding"):
        from vision.window_detector import WindowInfo, WindowSnapshot
        win = WindowInfo(
            hwnd=1, title="test",
            process_name=proc, process_id=1234,
            category=cat,
            is_distraction=is_distraction,
            is_productive=is_productive,
        )
        return WindowSnapshot(active_window=win, all_windows=[win])

    def test_productivity_score_increases_with_work(self):
        from vision.productivity_analyzer import ProductivityAnalyzer
        analyzer = ProductivityAnalyzer()
        for _ in range(20):
            analyzer.ingest(self._make_snapshot(is_productive=True))
        report = analyzer.get_report()
        assert report.score > 50

    def test_distraction_score_lower(self):
        from vision.productivity_analyzer import ProductivityAnalyzer
        analyzer = ProductivityAnalyzer()
        for _ in range(20):
            analyzer.ingest(self._make_snapshot(
                is_productive=False, is_distraction=True, cat="gaming"
            ))
        report = analyzer.get_report()
        assert report.distraction_pct > 50

    def test_intervention_trigger_after_threshold(self):
        from vision.productivity_analyzer import ProductivityAnalyzer
        analyzer = ProductivityAnalyzer(distraction_threshold=0.0)  # Immediate trigger
        analyzer._distraction_alert_cooldown = 0

        snap = self._make_snapshot(is_productive=False, is_distraction=True, cat="gaming")
        # First ingest starts the streak
        analyzer.ingest(snap)
        # Force streak to be past threshold
        analyzer._streak_start = time.time() - 400
        analyzer._streak_type = "distraction"

        result = analyzer.ingest(snap)
        assert result is not None
        assert "distraction" in result.lower() or "youtube" in result.lower() or "game" in result.lower() or "steam" in result.lower()

    def test_context_summary_not_empty(self):
        from vision.productivity_analyzer import ProductivityAnalyzer
        analyzer = ProductivityAnalyzer()
        snap = self._make_snapshot()
        analyzer.ingest(snap)
        summary = analyzer.get_context_summary()
        assert len(summary) > 10


# ── Automation: Permission System ────────────────────────────

class TestPermissionSystem:

    def make_perms(self, tmp_path):
        from automation.permission_system import PermissionSystem
        return PermissionSystem(audit_log_path=tmp_path / "audit.jsonl")

    def make_request(self, action_type, params=None):
        from automation.permission_system import ActionRequest
        return ActionRequest(
            action_type=action_type,
            parameters=params or {},
            source="test",
            request_id="test001",
        )

    def test_open_url_auto_approved(self, tmp_path):
        perms = self.make_perms(tmp_path)
        req = self.make_request("open_url", {"url": "https://example.com"})
        decision = perms.evaluate(req)
        assert decision.approved is True

    def test_type_text_requires_confirm(self, tmp_path):
        from automation.permission_system import PermissionTier
        perms = self.make_perms(tmp_path)
        req = self.make_request("type_text", {"text": "hello"})
        decision = perms.evaluate(req)
        assert decision.tier == PermissionTier.CONFIRM_REQUIRED
        assert decision.approved is False

    def test_blocked_action_rejected(self, tmp_path):
        from automation.permission_system import PermissionTier
        perms = self.make_perms(tmp_path)
        req = self.make_request("delete_file", {"path": "C:\\Windows\\system32"})
        decision = perms.evaluate(req)
        assert decision.tier == PermissionTier.BLOCKED
        assert decision.approved is False

    def test_confirm_pending_action(self, tmp_path):
        perms = self.make_perms(tmp_path)
        req = self.make_request("type_text", {"text": "hello"})
        decision = perms.evaluate(req)
        assert not decision.approved

        confirmed = perms.confirm(req.request_id)
        assert confirmed is not None
        assert confirmed.approved is True

    def test_deny_pending_action(self, tmp_path):
        perms = self.make_perms(tmp_path)
        req = self.make_request("move_file", {"source": "a.txt", "destination": "b.txt"})
        perms.evaluate(req)
        denied = perms.deny(req.request_id)
        assert denied is not None
        assert denied.approved is False

    def test_unapproved_app_blocked(self, tmp_path):
        from automation.permission_system import PermissionTier
        perms = self.make_perms(tmp_path)
        req = self.make_request("launch_approved_app", {"app_name": "malware.exe"})
        decision = perms.evaluate(req)
        assert decision.tier == PermissionTier.BLOCKED

    def test_audit_log_written(self, tmp_path):
        import json
        perms = self.make_perms(tmp_path)
        req = self.make_request("open_url", {"url": "https://test.com"})
        perms.evaluate(req)
        audit = tmp_path / "audit.jsonl"
        assert audit.exists()
        record = json.loads(audit.read_text().strip())
        assert record["action_type"] == "open_url"
        assert record["approved"] is True


# ── Memory Engine ────────────────────────────────────────────

class TestMemoryEngine:

    @pytest.mark.asyncio
    async def test_conversation_persistence(self, tmp_path):
        from memory.memory_engine import MemoryEngine
        engine = MemoryEngine(
            db_path=tmp_path / "test.db",
            vector_db_path=tmp_path / "chroma",
        )
        await engine.initialize()

        await engine.save_turn("user", "Hello, how are you?")
        await engine.save_turn("assistant", "I am functioning correctly.")

        turns = await engine.get_recent_turns()
        assert len(turns) == 2
        assert turns[0]["role"] == "user"
        assert turns[1]["role"] == "assistant"

        await engine.close()

    @pytest.mark.asyncio
    async def test_preferences_persist(self, tmp_path):
        from memory.memory_engine import MemoryEngine
        engine = MemoryEngine(
            db_path=tmp_path / "test.db",
            vector_db_path=tmp_path / "chroma",
        )
        await engine.initialize()

        await engine.set_preference("theme", "dark")
        value = await engine.get_preference("theme")
        assert value == "dark"

        missing = await engine.get_preference("nonexistent", "default")
        assert missing == "default"

        await engine.close()

    @pytest.mark.asyncio
    async def test_new_session_changes_id(self, tmp_path):
        from memory.memory_engine import MemoryEngine
        engine = MemoryEngine(
            db_path=tmp_path / "test.db",
            vector_db_path=tmp_path / "chroma",
        )
        await engine.initialize()

        session1 = engine._current_session_id
        session2 = engine.new_session()
        assert session1 != session2

        await engine.close()

    @pytest.mark.asyncio
    @pytest.mark.slow
    async def test_memory_store_and_retrieve(self, tmp_path):
        """Tests ChromaDB + sentence-transformers. Requires deps installed."""
        from memory.memory_engine import MemoryEngine
        engine = MemoryEngine(
            db_path=tmp_path / "test.db",
            vector_db_path=tmp_path / "chroma",
            embedding_model="all-MiniLM-L6-v2",
            context_top_k=3,
        )
        await engine.initialize()

        if engine._embedder is None:
            pytest.skip("sentence-transformers not installed")

        await engine.store_memory(
            content="User prefers dark mode in VS Code.",
            memory_type="preference",
            importance=0.8,
        )
        await engine.store_memory(
            content="User works on Python ML projects.",
            memory_type="habit",
            importance=0.7,
        )

        results = await engine.retrieve_relevant("dark theme editor settings")
        assert len(results) >= 1
        # The first result should be about VS Code / dark mode
        assert any("dark" in r.content.lower() or "code" in r.content.lower() for r in results)

        await engine.close()


# ── Learning Engine ──────────────────────────────────────────

class TestLearningEngine:

    @pytest.mark.asyncio
    async def test_feedback_tracking(self):
        from learning.learning_engine import PreferenceTracker
        tracker = PreferenceTracker()

        await tracker.record_feedback("Short answer.", "good")
        await tracker.record_feedback("A" * 200, "too_long")

        pref = tracker.get_preferred_length()
        assert pref in ("short", "medium", "long")

    @pytest.mark.asyncio
    async def test_pattern_learner_peak_hours(self):
        from learning.learning_engine import PatternLearner
        from datetime import datetime, timedelta

        learner = PatternLearner()

        # Simulate 20 productive samples at 10am
        base_time = datetime.now().replace(hour=10, minute=0).timestamp()
        samples = [
            {
                "timestamp": base_time + i * 60,
                "category": "coding",
                "is_productive": True,
                "is_distraction": False,
            }
            for i in range(20)
        ]

        patterns = await learner.analyze(samples)
        assert len(patterns) >= 1
        peak = next((p for p in patterns if p.pattern_type == "peak_hours"), None)
        assert peak is not None
        assert "10:00" in peak.description

    def test_prompt_adapter_builds_prompt(self):
        from learning.learning_engine import (
            LearningEngine, PromptAdapter, PreferenceTracker, PatternLearner
        )
        base = "You are a test assistant."
        prefs = PreferenceTracker()
        patterns = PatternLearner()
        adapter = PromptAdapter(base, prefs, patterns)

        result = adapter.build_prompt(
            vision_context="[Screen] Active: code.exe",
            memory_context="[Memory] User prefers Python.",
        )
        assert base in result.full_prompt
        assert "code.exe" in result.full_prompt
        assert "Python" in result.full_prompt


# ── Personality Engine ───────────────────────────────────────

class TestPersonalityEngine:

    def test_style_directive_returned(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(style="strict_coach")
        directive = engine.get_style_directive()
        assert "coach" in directive.lower() or "strict" in directive.lower()

    def test_unknown_style_defaults(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(style="nonexistent_style")
        # Should default to strict_coach without raising
        directive = engine.get_style_directive()
        assert len(directive) > 0

    def test_proactive_message_distraction(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(proactive_enabled=True, proactive_interval_sec=0)
        msg = engine.generate_proactive_message(
            "distraction", {"app": "YouTube", "minutes": 8}
        )
        assert msg is not None
        assert "8" in msg.message or "YouTube" in msg.message

    def test_proactive_disabled(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(proactive_enabled=False)
        assert engine.should_speak_proactively(is_in_conversation=False) is False

    def test_proactive_suppressed_in_conversation(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(proactive_enabled=True, proactive_interval_sec=0)
        assert engine.should_speak_proactively(is_in_conversation=True) is False

    def test_style_hot_swap(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(style="strict_coach")
        result = engine.set_style("mentor")
        assert result is True
        assert engine._style == "mentor"

    def test_invalid_style_rejected(self):
        from personality.personality_engine import PersonalityEngine
        engine = PersonalityEngine(style="strict_coach")
        result = engine.set_style("invalid_style_xyz")
        assert result is False
        assert engine._style == "strict_coach"  # Unchanged

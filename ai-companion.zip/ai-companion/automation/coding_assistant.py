"""
automation/coding_assistant.py
================================
Phase 6 local coding assistant.

Capabilities:
  - Monitors the active code editor via window title + OCR.
  - Detects the current file, language, and approximate location.
  - On request ("help me with this code"), sends screen OCR text to LLM
    with a coding-specific prompt.
  - Proactively suggests fixes when it detects error patterns in OCR text.
  - Can write generated code to clipboard for paste-in (with confirmation).

Architecture:
  - Runs as a service on the vision engine's analysis cycle.
  - Does NOT inject keystrokes into the editor automatically.
  - All code suggestions go through voice output or clipboard + confirmation.

Language detection: from window title (file extension) or OCR text patterns.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Optional, List

from loguru import logger

# Language detection patterns (from file extensions in window title)
LANG_PATTERNS = {
    r"\.py[\"' ]":           "python",
    r"\.js[\"' ]":           "javascript",
    r"\.ts[\"' ]":           "typescript",
    r"\.jsx?[\"' ]":         "javascript",
    r"\.tsx?[\"' ]":         "typescript",
    r"\.rs[\"' ]":           "rust",
    r"\.go[\"' ]":           "go",
    r"\.java[\"' ]":         "java",
    r"\.cpp?[\"' ]":         "cpp",
    r"\.c[\"' ]":            "c",
    r"\.cs[\"' ]":           "csharp",
    r"\.rb[\"' ]":           "ruby",
    r"\.php[\"' ]":          "php",
    r"\.swift[\"' ]":        "swift",
    r"\.kt[\"' ]":           "kotlin",
    r"\.sh[\"' ]":           "bash",
    r"\.sql[\"' ]":          "sql",
    r"\.html?[\"' ]":        "html",
    r"\.css[\"' ]":          "css",
}

# Error patterns that trigger proactive suggestions
ERROR_PATTERNS = {
    "python": [
        r"SyntaxError",
        r"NameError",
        r"TypeError",
        r"IndentationError",
        r"AttributeError",
        r"ImportError",
        r"Traceback \(most recent call last\)",
    ],
    "javascript": [
        r"TypeError:",
        r"ReferenceError:",
        r"SyntaxError:",
        r"Uncaught",
        r"Cannot read propert",
        r"is not a function",
    ],
    "general": [
        r"ERROR",
        r"FAILED",
        r"Exception",
        r"fatal error",
        r"undefined reference",
    ],
}


@dataclass
class CodeContext:
    language: str
    file_name: str
    editor: str
    screen_text: str       # OCR text from the editor area
    error_detected: bool
    error_text: str
    timestamp: float = field(default_factory=time.time)

    def to_llm_prompt(self, user_request: str) -> str:
        error_note = ""
        if self.error_detected:
            error_note = (
                f"\n\nERROR DETECTED IN SCREEN:\n{self.error_text[:400]}"
            )

        code_note = ""
        if self.screen_text:
            code_note = (
                f"\n\nVISIBLE CODE (from screen OCR, may be partial):\n"
                f"```{self.language}\n{self.screen_text[:2000]}\n```"
            )

        return (
            f"The user is coding in {self.language} using {self.editor}. "
            f"File: {self.file_name}."
            f"{error_note}"
            f"{code_note}"
            f"\n\nUser request: {user_request}"
            f"\n\nProvide a clear, concise response. "
            f"If writing code, wrap it in ```{self.language} blocks. "
            f"Be specific — you can see what's on their screen."
        )


class CodingAssistant:
    """
    Coding context extractor and assistant.

    Works in conjunction with the VisionEngine's OCR output and
    the active window detector.
    """

    def __init__(self, llm_engine=None) -> None:
        self._llm = llm_engine
        self._last_context: Optional[CodeContext] = None
        self._last_error_alert: float = 0.0
        self._error_alert_cooldown = 60.0   # Don't spam error alerts

    def extract_context(
        self,
        window_title: str,
        process_name: str,
        ocr_text: str,
    ) -> Optional[CodeContext]:
        """
        Build a CodeContext from the current window and screen text.
        Returns None if the user is not in a code editor.
        """
        editor = self._detect_editor(process_name)
        if not editor:
            return None

        language = self._detect_language(window_title, ocr_text)
        file_name = self._extract_filename(window_title)
        error_text, error_detected = self._detect_errors(language, ocr_text)

        ctx = CodeContext(
            language=language,
            file_name=file_name,
            editor=editor,
            screen_text=ocr_text,
            error_detected=error_detected,
            error_text=error_text,
        )
        self._last_context = ctx
        return ctx

    def should_alert_error(self, ctx: CodeContext) -> bool:
        """Return True if we should proactively mention a detected error."""
        if not ctx.error_detected:
            return False
        elapsed = time.time() - self._last_error_alert
        if elapsed < self._error_alert_cooldown:
            return False
        self._last_error_alert = time.time()
        return True

    async def answer(
        self,
        user_request: str,
        vision_context: Optional[CodeContext] = None,
    ) -> str:
        """
        Generate a coding response using the LLM.
        Uses vision context if available.
        """
        if not self._llm:
            return "LLM not available."

        ctx = vision_context or self._last_context
        if ctx:
            prompt = ctx.to_llm_prompt(user_request)
        else:
            prompt = user_request

        return await self._llm.generate_direct(prompt)

    # ── Detection helpers ────────────────────────────────────

    @staticmethod
    def _detect_editor(process_name: str) -> Optional[str]:
        editors = {
            "code.exe": "VS Code",
            "cursor.exe": "Cursor",
            "pycharm64.exe": "PyCharm",
            "idea64.exe": "IntelliJ IDEA",
            "webstorm64.exe": "WebStorm",
            "sublime_text.exe": "Sublime Text",
            "notepad++.exe": "Notepad++",
            "vim.exe": "Vim",
            "nvim.exe": "Neovim",
            "emacs.exe": "Emacs",
        }
        pname = process_name.lower()
        for exe, name in editors.items():
            if exe in pname:
                return name
        return None

    @staticmethod
    def _detect_language(window_title: str, ocr_text: str) -> str:
        combined = f"{window_title} {ocr_text[:500]}"
        for pattern, lang in LANG_PATTERNS.items():
            if re.search(pattern, combined, re.IGNORECASE):
                return lang
        return "unknown"

    @staticmethod
    def _extract_filename(window_title: str) -> str:
        # Editors typically show "filename.ext — Editor Name"
        match = re.search(r'([^\\/]+\.\w+)', window_title)
        return match.group(1) if match else "unknown file"

    @staticmethod
    def _detect_errors(language: str, ocr_text: str) -> tuple[str, bool]:
        patterns = (
            ERROR_PATTERNS.get(language, [])
            + ERROR_PATTERNS["general"]
        )
        for pat in patterns:
            match = re.search(pat, ocr_text)
            if match:
                # Extract surrounding context
                start = max(0, match.start() - 50)
                end = min(len(ocr_text), match.end() + 200)
                return ocr_text[start:end], True
        return "", False

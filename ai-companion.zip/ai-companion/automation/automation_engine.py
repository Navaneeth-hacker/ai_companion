"""
automation/automation_engine.py
================================
Phase 3 desktop automation engine.

All actions go through the PermissionSystem before execution.
Supports:
  - App launching (approved list only)
  - Browser URL opening
  - Keyboard shortcuts (hotkeys)
  - Text typing with confirmation
  - Window management (focus, close, minimize)
  - File operations (create, rename, move — with confirmation)
  - Clipboard read/write
  - Screen scrolling

Uses pyautogui + pywinauto for Windows automation.

Safety model:
  - All actions are logged to audit.jsonl.
  - Destructive actions require voice/API confirmation.
  - Never executes shell commands.
  - Never accesses system paths outside user home.
  - Sanitizes all text inputs before typing.
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from loguru import logger

from automation.permission_system import (
    ActionRequest,
    PermissionSystem,
    PermissionTier,
)

try:
    import pyautogui
    pyautogui.FAILSAFE = True      # Move mouse to top-left corner to abort
    pyautogui.PAUSE = 0.05         # Small pause between actions
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False

try:
    import pywinauto
    PYWINAUTO_AVAILABLE = True
except ImportError:
    PYWINAUTO_AVAILABLE = False

try:
    import win32clipboard
    import win32con
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False


@dataclass
class AutomationResult:
    success: bool
    action_type: str
    message: str
    request_id: str
    duration_sec: float = 0.0


class AutomationEngine:
    """
    Safe desktop automation execution engine.

    All methods return AutomationResult — never raise on user-facing errors.

    Args:
        permission_system:  The shared PermissionSystem instance.
        safe_user_dir:      Root directory for allowed file operations.
                            Default: user's home directory.
    """

    def __init__(
        self,
        permission_system: PermissionSystem,
        safe_user_dir: Optional[Path] = None,
    ) -> None:
        self._perms = permission_system
        self._safe_dir = safe_user_dir or Path.home()
        logger.info(
            f"AutomationEngine: safe_dir={self._safe_dir} "
            f"pyautogui={PYAUTOGUI_AVAILABLE} pywinauto={PYWINAUTO_AVAILABLE}"
        )

    # ── High-level action dispatcher ────────────────────────

    async def execute(
        self, action_type: str, parameters: Dict[str, Any], source: str = "voice_command"
    ) -> AutomationResult:
        """
        Main entry point. Evaluate permissions, then execute.

        For CONFIRM_REQUIRED actions, returns a result indicating
        confirmation is needed (does NOT execute yet).
        The caller must call confirm(request_id) after user consent.
        """
        request_id = str(uuid.uuid4())[:8]
        request = ActionRequest(
            action_type=action_type,
            parameters=parameters,
            source=source,
            request_id=request_id,
        )

        decision = self._perms.evaluate(request)

        if not decision.approved:
            if decision.tier == PermissionTier.CONFIRM_REQUIRED:
                return AutomationResult(
                    success=False,
                    action_type=action_type,
                    message=f"CONFIRM_REQUIRED:{request_id}:{decision.reason}",
                    request_id=request_id,
                )
            else:
                return AutomationResult(
                    success=False,
                    action_type=action_type,
                    message=f"BLOCKED: {decision.reason}",
                    request_id=request_id,
                )

        # Approved — execute
        return await self._dispatch(action_type, parameters, request_id)

    async def confirm_and_execute(self, request_id: str) -> AutomationResult:
        """Execute a previously pending confirmed action."""
        decision = self._perms.confirm(request_id)
        if not decision:
            return AutomationResult(
                success=False,
                action_type="unknown",
                message=f"No pending action with ID {request_id}",
                request_id=request_id,
            )

        return await self._dispatch(
            decision.request.action_type,
            decision.request.parameters,
            request_id,
        )

    # ── Action dispatcher ────────────────────────────────────

    async def _dispatch(
        self, action_type: str, params: Dict, request_id: str
    ) -> AutomationResult:
        """Route to the appropriate handler."""
        t0 = time.perf_counter()

        handlers = {
            "open_url": self._open_url,
            "launch_approved_app": self._launch_app,
            "type_text": self._type_text,
            "press_hotkey": self._press_hotkey,
            "scroll_page": self._scroll_page,
            "copy_to_clipboard": self._copy_to_clipboard,
            "read_clipboard": self._read_clipboard,
            "take_screenshot": self._take_screenshot,
            "close_window": self._close_window,
            "create_file": self._create_file,
            "move_file": self._move_file,
            "rename_file": self._rename_file,
        }

        handler = handlers.get(action_type)
        if not handler:
            return AutomationResult(
                success=False,
                action_type=action_type,
                message=f"No handler for action: {action_type}",
                request_id=request_id,
            )

        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None, lambda: handler(params)
            )
            result.duration_sec = round(time.perf_counter() - t0, 3)
            return result

        except Exception as e:
            logger.error(f"AutomationEngine: error in {action_type}: {e}", exc_info=True)
            return AutomationResult(
                success=False,
                action_type=action_type,
                message=f"Execution error: {e}",
                request_id=request_id,
                duration_sec=round(time.perf_counter() - t0, 3),
            )

    # ── Action implementations ───────────────────────────────

    def _open_url(self, params: Dict) -> AutomationResult:
        url = params.get("url", "")
        if not url:
            return self._err("open_url", "No URL provided", params.get("__id__", ""))

        # Sanitize: only http/https URLs
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        import webbrowser
        webbrowser.open(url)
        logger.info(f"AutomationEngine: opened URL: {url}")
        return AutomationResult(True, "open_url", f"Opened: {url}", "")

    def _launch_app(self, params: Dict) -> AutomationResult:
        app_name = params.get("app_name", "").lower()
        if not app_name:
            return self._err("launch_approved_app", "No app_name provided", "")

        # Map display names to executables
        app_map = {
            "notepad": "notepad.exe",
            "calculator": "calc.exe",
            "code": "code",
            "chrome": "chrome",
            "firefox": "firefox",
            "edge": "msedge",
            "windows terminal": "wt",
            "cmd": "cmd.exe",
            "powershell": "powershell.exe",
            "explorer": "explorer.exe",
        }
        exe = app_map.get(app_name, app_name)

        try:
            subprocess.Popen([exe], shell=False)
            logger.info(f"AutomationEngine: launched app: {exe}")
            return AutomationResult(True, "launch_approved_app", f"Launched: {app_name}", "")
        except FileNotFoundError:
            return self._err("launch_approved_app", f"App not found: {exe}", "")

    def _type_text(self, params: Dict) -> AutomationResult:
        if not PYAUTOGUI_AVAILABLE:
            return self._err("type_text", "pyautogui not installed", "")

        text = params.get("text", "")
        interval = params.get("interval", 0.03)

        if not text:
            return self._err("type_text", "No text provided", "")

        # Sanitize: remove potential escape sequences or control chars
        safe_text = "".join(c for c in text if c.isprintable() or c in "\n\t")

        pyautogui.typewrite(safe_text, interval=interval)
        logger.info(f"AutomationEngine: typed {len(safe_text)} chars")
        return AutomationResult(True, "type_text", f"Typed {len(safe_text)} characters", "")

    def _press_hotkey(self, params: Dict) -> AutomationResult:
        if not PYAUTOGUI_AVAILABLE:
            return self._err("press_hotkey", "pyautogui not installed", "")

        keys = params.get("keys", [])
        if isinstance(keys, str):
            keys = [keys]

        # Whitelist of allowed hotkeys
        ALLOWED_MODIFIERS = {"ctrl", "alt", "shift", "win", "cmd"}
        ALLOWED_KEYS = {
            "c", "v", "x", "z", "a", "s", "f", "t", "w", "n", "r", "l",
            "tab", "return", "enter", "esc", "space", "backspace",
            "f1","f2","f3","f4","f5","f6","f7","f8","f9","f10","f11","f12",
            "left", "right", "up", "down", "home", "end", "pageup", "pagedown",
        }

        all_keys = {k.lower() for k in keys}
        modifiers = all_keys & ALLOWED_MODIFIERS
        action_keys = all_keys - modifiers

        if not action_keys.issubset(ALLOWED_KEYS) and not action_keys.issubset(ALLOWED_MODIFIERS):
            blocked = action_keys - ALLOWED_KEYS - ALLOWED_MODIFIERS
            return self._err("press_hotkey", f"Blocked keys: {blocked}", "")

        pyautogui.hotkey(*keys)
        logger.info(f"AutomationEngine: pressed hotkey: {'+'.join(keys)}")
        return AutomationResult(True, "press_hotkey", f"Pressed: {'+'.join(keys)}", "")

    def _scroll_page(self, params: Dict) -> AutomationResult:
        if not PYAUTOGUI_AVAILABLE:
            return self._err("scroll_page", "pyautogui not installed", "")

        direction = params.get("direction", "down")
        clicks = int(params.get("clicks", 3))
        clicks = max(1, min(clicks, 20))  # Cap at 20

        amount = -clicks if direction == "down" else clicks
        pyautogui.scroll(amount)
        return AutomationResult(True, "scroll_page", f"Scrolled {direction} {clicks}x", "")

    def _copy_to_clipboard(self, params: Dict) -> AutomationResult:
        text = params.get("text", "")
        if not text:
            return self._err("copy_to_clipboard", "No text provided", "")

        if WIN32_AVAILABLE:
            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32con.CF_UNICODETEXT, text)
            win32clipboard.CloseClipboard()
        else:
            import subprocess
            subprocess.run(["clip"], input=text.encode(), check=True)

        return AutomationResult(True, "copy_to_clipboard", "Copied to clipboard", "")

    def _read_clipboard(self, params: Dict) -> AutomationResult:
        if WIN32_AVAILABLE:
            try:
                win32clipboard.OpenClipboard()
                data = win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
                win32clipboard.CloseClipboard()
                return AutomationResult(True, "read_clipboard", data[:1000], "")
            except Exception as e:
                return self._err("read_clipboard", str(e), "")
        return self._err("read_clipboard", "win32clipboard not available", "")

    def _take_screenshot(self, params: Dict) -> AutomationResult:
        if not PYAUTOGUI_AVAILABLE:
            return self._err("take_screenshot", "pyautogui not installed", "")

        filename = params.get("filename", f"screenshot_{int(time.time())}.png")
        save_path = self._safe_dir / "Pictures" / filename

        try:
            save_path.parent.mkdir(parents=True, exist_ok=True)
            img = pyautogui.screenshot()
            img.save(str(save_path))
            logger.info(f"AutomationEngine: screenshot saved to {save_path}")
            return AutomationResult(True, "take_screenshot", str(save_path), "")
        except Exception as e:
            return self._err("take_screenshot", str(e), "")

    def _close_window(self, params: Dict) -> AutomationResult:
        if not PYAUTOGUI_AVAILABLE:
            return self._err("close_window", "pyautogui not installed", "")

        pyautogui.hotkey("alt", "f4")
        return AutomationResult(True, "close_window", "Sent Alt+F4 to active window", "")

    def _create_file(self, params: Dict) -> AutomationResult:
        path_str = params.get("path", "")
        content = params.get("content", "")

        if not path_str:
            return self._err("create_file", "No path provided", "")

        path = Path(path_str)
        if not path.is_absolute():
            path = self._safe_dir / path

        # Safety: must be within safe_dir
        if not str(path.resolve()).startswith(str(self._safe_dir.resolve())):
            return self._err("create_file", f"Path outside safe directory: {path}", "")

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        logger.info(f"AutomationEngine: created file: {path}")
        return AutomationResult(True, "create_file", str(path), "")

    def _move_file(self, params: Dict) -> AutomationResult:
        src = Path(params.get("source", ""))
        dst = Path(params.get("destination", ""))

        for p in (src, dst):
            if not p.is_absolute():
                p = self._safe_dir / p
            if not str(p.resolve()).startswith(str(self._safe_dir.resolve())):
                return self._err("move_file", f"Path outside safe directory: {p}", "")

        src.rename(dst)
        return AutomationResult(True, "move_file", f"Moved {src.name} → {dst}", "")

    def _rename_file(self, params: Dict) -> AutomationResult:
        path = Path(params.get("path", ""))
        new_name = params.get("new_name", "")

        if not path.exists():
            return self._err("rename_file", f"File not found: {path}", "")

        new_path = path.parent / new_name
        path.rename(new_path)
        return AutomationResult(True, "rename_file", f"Renamed to {new_name}", "")

    @staticmethod
    def _err(action: str, msg: str, rid: str) -> AutomationResult:
        return AutomationResult(False, action, msg, rid)

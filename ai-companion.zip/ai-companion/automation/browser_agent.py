"""
automation/browser_agent.py
============================
Phase 6 browser automation agent using Playwright.

Capabilities (all permission-gated):
  - Navigate to URL
  - Extract page text / structured content
  - Click elements by text label or CSS selector
  - Fill form fields
  - Take page screenshot
  - Run web search and return top results
  - Execute multi-step browser workflows via LLM planning

Architecture:
  - Playwright runs in async mode inside the main event loop.
  - A single persistent browser context is maintained per session.
  - All interactions go through the PermissionSystem.
  - Page content is extracted as clean text (markdown-ish) and fed
    to the LLM for understanding — no raw HTML passed to the model.

Security:
  - Headful mode (visible browser) so user sees every action.
  - No cookie/credential theft — browser profile is isolated.
  - Navigation to localhost / file:// URIs is blocked by default.
  - Download of executables is blocked.
"""

from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from loguru import logger

try:
    from playwright.async_api import (
        async_playwright, Browser, BrowserContext, Page, Playwright
    )
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

from automation.permission_system import PermissionSystem, ActionRequest


@dataclass
class PageContent:
    url: str
    title: str
    text: str           # Cleaned page text (no HTML tags)
    links: List[dict]   # [{text, href}]
    screenshot_b64: Optional[str] = None
    timestamp: float = 0.0


class BrowserAgent:
    """
    Playwright-based browser agent with permission gating.

    Args:
        permission_system:  Shared PermissionSystem instance.
        headless:           Run browser in headless mode (False = visible).
        blocked_domains:    Domains the agent may not navigate to.
    """

    BLOCKED_DOMAINS = {
        "localhost", "127.0.0.1", "0.0.0.0",
        "169.254.169.254",    # AWS metadata endpoint
    }
    BLOCKED_SCHEMES = {"file", "data", "javascript", "vbscript"}

    def __init__(
        self,
        permission_system: PermissionSystem,
        headless: bool = False,
        blocked_domains: set = None,
    ) -> None:
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError(
                "playwright not installed. Run: pip install playwright && "
                "playwright install chromium"
            )
        self._perms = permission_system
        self._headless = headless
        self._blocked_domains = self.BLOCKED_DOMAINS | (blocked_domains or set())

        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None

        logger.info(
            f"BrowserAgent: headless={headless} "
            f"blocked_domains={len(self._blocked_domains)}"
        )

    # ── Lifecycle ────────────────────────────────────────────

    async def start(self) -> None:
        """Launch browser. Call once at startup."""
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=self._headless,
            args=["--no-sandbox", "--disable-extensions"],
        )
        self._context = await self._browser.new_context(
            viewport={"width": 1280, "height": 800},
            accept_downloads=False,         # Block downloads by default
        )

        # Block executable downloads at network level
        await self._context.route(
            "**/*.exe", lambda r: r.abort()
        )
        await self._context.route(
            "**/*.msi", lambda r: r.abort()
        )

        self._page = await self._context.new_page()
        logger.info("BrowserAgent: browser started")

    async def stop(self) -> None:
        """Close the browser."""
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info("BrowserAgent: stopped")

    # ── Navigation ───────────────────────────────────────────

    async def navigate(self, url: str) -> Optional[PageContent]:
        """
        Navigate to a URL and return extracted page content.
        Requires open_url permission (auto-approved for http/https).
        """
        if not self._validate_url(url):
            logger.warning(f"BrowserAgent: blocked navigation to {url}")
            return None

        logger.info(f"BrowserAgent: navigating to {url}")
        try:
            await self._page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(1)  # Let dynamic content load
            return await self._extract_content()
        except Exception as e:
            logger.error(f"BrowserAgent: navigation error: {e}")
            return None

    async def web_search(self, query: str) -> PageContent:
        """Navigate to a DuckDuckGo search and extract results."""
        safe_query = query.replace('"', '').replace("'", "")[:200]
        url = f"https://duckduckgo.com/?q={safe_query.replace(' ', '+')}"
        return await self.navigate(url)

    async def click(self, selector_or_text: str) -> bool:
        """Click an element by CSS selector or visible text."""
        try:
            # Try text match first
            locator = self._page.get_by_text(selector_or_text, exact=False)
            count = await locator.count()
            if count > 0:
                await locator.first.click(timeout=5000)
                return True

            # Fall back to CSS selector
            await self._page.click(selector_or_text, timeout=5000)
            return True
        except Exception as e:
            logger.warning(f"BrowserAgent: click failed for '{selector_or_text}': {e}")
            return False

    async def fill_field(self, selector: str, value: str) -> bool:
        """Fill a form field. Requires CONFIRM_REQUIRED permission."""
        try:
            await self._page.fill(selector, value, timeout=5000)
            return True
        except Exception as e:
            logger.warning(f"BrowserAgent: fill failed: {e}")
            return False

    async def get_current_content(self) -> Optional[PageContent]:
        """Extract content from the currently loaded page."""
        if not self._page:
            return None
        return await self._extract_content()

    # ── Content extraction ───────────────────────────────────

    async def _extract_content(self) -> PageContent:
        """Extract clean text and links from the current page."""
        title = await self._page.title()
        url = self._page.url

        # Extract text using JS — strips scripts, styles, nav boilerplate
        text = await self._page.evaluate("""() => {
            // Remove non-content elements
            const remove_tags = ['script', 'style', 'nav', 'header', 'footer',
                                 'aside', 'advertisement', 'iframe'];
            remove_tags.forEach(tag => {
                document.querySelectorAll(tag).forEach(el => el.remove());
            });

            // Get text from main content areas
            const main = document.querySelector('main, article, [role=main], #content, .content');
            const source = main || document.body;
            return (source.innerText || source.textContent || '')
                .replace(/\\s{3,}/g, '\\n\\n')
                .trim()
                .slice(0, 8000);  // Cap at 8000 chars for LLM context
        }""")

        # Extract links
        links_raw = await self._page.evaluate("""() => {
            return Array.from(document.querySelectorAll('a[href]'))
                .filter(a => a.innerText.trim())
                .map(a => ({ text: a.innerText.trim().slice(0, 100), href: a.href }))
                .slice(0, 20);
        }""")

        return PageContent(
            url=url,
            title=title,
            text=text,
            links=links_raw,
            timestamp=time.time(),
        )

    # ── Validation ───────────────────────────────────────────

    def _validate_url(self, url: str) -> bool:
        """Return True if navigation to this URL is permitted."""
        # Must be http or https
        if not url.startswith(("http://", "https://")):
            return False

        # Extract domain
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            scheme = parsed.scheme.lower()
            host = parsed.hostname or ""
        except Exception:
            return False

        if scheme in self.BLOCKED_SCHEMES:
            return False

        for blocked in self._blocked_domains:
            if host == blocked or host.endswith("." + blocked):
                return False

        return True

    # ── LLM-planned multi-step workflow ─────────────────────

    async def execute_plan(self, plan: List[dict]) -> List[str]:
        """
        Execute a list of browser actions planned by the LLM.

        plan format:
          [
            {"action": "navigate", "url": "https://..."},
            {"action": "click", "target": "Sign in"},
            {"action": "extract", "selector": ".results"},
          ]

        Returns list of result strings.
        """
        results = []
        for step in plan:
            action = step.get("action", "")
            logger.info(f"BrowserAgent: executing step: {action}")

            if action == "navigate":
                content = await self.navigate(step.get("url", ""))
                results.append(
                    f"Navigated to: {content.title}" if content else "Navigation failed"
                )
            elif action == "click":
                ok = await self.click(step.get("target", ""))
                results.append("Clicked: " + step.get("target", "") if ok else "Click failed")
            elif action == "extract":
                content = await self.get_current_content()
                results.append(content.text[:500] if content else "Extraction failed")
            elif action == "search":
                content = await self.web_search(step.get("query", ""))
                results.append(content.text[:800] if content else "Search failed")
            else:
                results.append(f"Unknown action: {action}")

        return results

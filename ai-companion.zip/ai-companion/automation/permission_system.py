"""
automation/permission_system.py
================================
Security layer for all automation actions.

Philosophy:
  NEVER execute automation without explicit user consent.
  Every action goes through this layer before execution.

Three-tier permission model:
  TIER 1 — AUTO_APPROVED: Safe read-only or trivially reversible actions.
             e.g. open URL, launch approved apps, read clipboard.
  TIER 2 — CONFIRM_REQUIRED: Potentially impactful actions.
             e.g. type text, click buttons, move files.
             Requires verbal "yes" or API /confirm before executing.
  TIER 3 — BLOCKED: Never executed regardless of instructions.
             e.g. delete system files, run shell commands with elevated perms,
             access credential stores, exfiltrate data.

Audit logging:
  Every decision (approved/denied/blocked) is written to logs/audit.jsonl.
  This log is append-only and never auto-purged.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set

from loguru import logger


class PermissionTier(Enum):
    AUTO_APPROVED = "auto_approved"
    CONFIRM_REQUIRED = "confirm_required"
    BLOCKED = "blocked"


@dataclass
class ActionRequest:
    action_type: str           # e.g. "open_url", "type_text", "launch_app"
    parameters: dict
    source: str                # "voice_command" | "api" | "proactive"
    request_id: str
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


@dataclass
class PermissionDecision:
    request: ActionRequest
    tier: PermissionTier
    approved: bool
    reason: str
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


# ── Action classification rules ─────────────────────────────

AUTO_APPROVED_ACTIONS: Set[str] = {
    "open_url",
    "launch_approved_app",
    "read_clipboard",
    "get_window_title",
    "scroll_page",
    "take_screenshot",
    "search_web",
    "get_system_time",
    "list_open_windows",
}

CONFIRM_REQUIRED_ACTIONS: Set[str] = {
    "type_text",
    "click_button",
    "press_hotkey",
    "fill_form",
    "copy_to_clipboard",
    "move_file",
    "rename_file",
    "create_file",
    "create_folder",
    "close_window",
    "close_tab",
    "send_message",
    "submit_form",
    "download_file",
}

BLOCKED_ACTIONS: Set[str] = {
    "run_shell_command",
    "execute_arbitrary_code",
    "delete_file",
    "delete_folder",
    "modify_registry",
    "install_software",
    "uninstall_software",
    "access_credential_store",
    "access_browser_passwords",
    "disable_firewall",
    "modify_hosts_file",
    "access_private_keys",
    "exfiltrate_data",
    "send_email_without_confirm",
    "make_payment",
    "elevate_privileges",
}

# Approved application list for launch_approved_app
APPROVED_APPS: Set[str] = {
    "notepad",
    "notepad++",
    "calculator",
    "code",                 # VS Code
    "cursor",
    "pycharm",
    "windows terminal",
    "powershell",
    "cmd",
    "chrome",
    "firefox",
    "edge",
    "explorer",
    "outlook",
    "teams",
    "slack",
    "zoom",
    "vlc",
    "spotify",
}


class PermissionSystem:
    """
    Evaluates and records permission decisions for all automation actions.

    Args:
        audit_log_path: Path to the append-only audit log.
        require_confirm_via: "voice" | "api" — how confirmations are collected.
    """

    def __init__(
        self,
        audit_log_path: Path = Path("logs/audit.jsonl"),
        require_confirm_via: str = "api",
    ) -> None:
        self._audit_path = audit_log_path
        self._require_confirm_via = require_confirm_via
        self._pending_confirmations: Dict[str, ActionRequest] = {}
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        logger.info(f"PermissionSystem: audit_log={audit_log_path}")

    # ── Public API ──────────────────────────────────────────

    def evaluate(self, request: ActionRequest) -> PermissionDecision:
        """
        Evaluate an action request and return a permission decision.
        Auto-approved actions are immediately approved.
        Confirm-required actions are stored as pending.
        Blocked actions are immediately rejected.
        """
        tier = self._classify(request)

        if tier == PermissionTier.BLOCKED:
            decision = PermissionDecision(
                request=request,
                tier=tier,
                approved=False,
                reason=f"Action '{request.action_type}' is blocked by security policy.",
            )

        elif tier == PermissionTier.CONFIRM_REQUIRED:
            self._pending_confirmations[request.request_id] = request
            decision = PermissionDecision(
                request=request,
                tier=tier,
                approved=False,   # Not yet — waiting for confirmation
                reason=f"Action '{request.action_type}' requires user confirmation. "
                       f"Request ID: {request.request_id}",
            )

        else:  # AUTO_APPROVED
            decision = PermissionDecision(
                request=request,
                tier=tier,
                approved=True,
                reason="Auto-approved.",
            )

        self._audit(decision)
        return decision

    def confirm(self, request_id: str) -> Optional[PermissionDecision]:
        """
        User confirmed a pending action.
        Returns the approved decision, or None if request_id not found.
        """
        request = self._pending_confirmations.pop(request_id, None)
        if not request:
            logger.warning(f"PermissionSystem: confirm called for unknown ID {request_id}")
            return None

        decision = PermissionDecision(
            request=request,
            tier=PermissionTier.CONFIRM_REQUIRED,
            approved=True,
            reason="User confirmed.",
        )
        self._audit(decision)
        logger.info(f"PermissionSystem: confirmed {request.action_type} [{request_id}]")
        return decision

    def deny(self, request_id: str) -> Optional[PermissionDecision]:
        """User denied a pending action."""
        request = self._pending_confirmations.pop(request_id, None)
        if not request:
            return None

        decision = PermissionDecision(
            request=request,
            tier=PermissionTier.CONFIRM_REQUIRED,
            approved=False,
            reason="User denied.",
        )
        self._audit(decision)
        logger.info(f"PermissionSystem: denied {request.action_type} [{request_id}]")
        return decision

    def get_pending(self) -> List[ActionRequest]:
        return list(self._pending_confirmations.values())

    def check_app_approved(self, app_name: str) -> bool:
        return app_name.lower().strip() in APPROVED_APPS

    # ── Classification ───────────────────────────────────────

    def _classify(self, request: ActionRequest) -> PermissionTier:
        action = request.action_type.lower()

        if action in BLOCKED_ACTIONS:
            return PermissionTier.BLOCKED

        if action == "launch_approved_app":
            app = request.parameters.get("app_name", "")
            if not self.check_app_approved(app):
                logger.warning(
                    f"PermissionSystem: launch_approved_app called with "
                    f"non-approved app '{app}' — blocking."
                )
                return PermissionTier.BLOCKED

        if action in CONFIRM_REQUIRED_ACTIONS:
            return PermissionTier.CONFIRM_REQUIRED

        if action in AUTO_APPROVED_ACTIONS:
            return PermissionTier.AUTO_APPROVED

        # Unknown action → require confirmation
        logger.warning(
            f"PermissionSystem: unknown action '{action}' — "
            "defaulting to CONFIRM_REQUIRED."
        )
        return PermissionTier.CONFIRM_REQUIRED

    # ── Audit logging ────────────────────────────────────────

    def _audit(self, decision: PermissionDecision) -> None:
        record = {
            "timestamp": decision.timestamp,
            "action_type": decision.request.action_type,
            "parameters": decision.request.parameters,
            "source": decision.request.source,
            "request_id": decision.request.request_id,
            "tier": decision.tier.value,
            "approved": decision.approved,
            "reason": decision.reason,
        }
        try:
            with open(self._audit_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as e:
            logger.error(f"PermissionSystem: audit write failed: {e}")

        level = "INFO" if decision.approved else "WARNING"
        logger.log(
            level,
            f"PermissionSystem: [{decision.tier.value}] "
            f"{decision.request.action_type} → "
            f"{'APPROVED' if decision.approved else 'DENIED'}: {decision.reason}"
        )

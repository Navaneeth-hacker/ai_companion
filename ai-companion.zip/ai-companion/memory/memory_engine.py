"""
memory/memory_engine.py
=======================
Phase 4 persistent memory engine.

Two-layer memory architecture:
  Layer 1 — SQLite (structured):
    Fast, SQL-queryable. Stores full conversation history,
    activity logs, tasks, preferences. Perfect for exact lookups,
    date filtering, counting.

  Layer 2 — ChromaDB (vector):
    Semantic search. Stores distilled memory summaries and facts
    as embeddings. Retrieved by similarity to the current query.
    Used to inject relevant past context into LLM prompts.

Memory lifecycle:
  1. Every conversation turn is written to SQLite (conversations table).
  2. After each session, the LLM generates a "memory summary" of key facts.
  3. Summaries are embedded and stored in ChromaDB.
  4. On each new query, top-K memories are retrieved and prepended to context.
  5. Old memories are scored by recency + importance; low-scoring ones pruned.

Embeddings:
  sentence-transformers "all-MiniLM-L6-v2" (~80MB, fast on CPU).
  Produces 384-dim vectors. More than sufficient for personal memory retrieval.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from loguru import logger

# SQLAlchemy async
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import select, delete, update, func as sqlfunc

from database.models import Base, Conversation, Memory, UserPreference

# ChromaDB
try:
    import chromadb
    from chromadb.config import Settings as ChromaSettings
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False

# Sentence transformers
try:
    from sentence_transformers import SentenceTransformer
    ST_AVAILABLE = True
except ImportError:
    ST_AVAILABLE = False


@dataclass
class MemoryEntry:
    id: str
    content: str
    memory_type: str
    importance: float
    timestamp: float
    relevance_score: float = 0.0  # Set when retrieved by semantic search


class MemoryEngine:
    """
    Dual-layer memory system: SQLite for structure, ChromaDB for semantics.

    Args:
        db_path:          Path to the SQLite database file.
        vector_db_path:   Path to the ChromaDB persistent store.
        embedding_model:  sentence-transformers model name.
        max_memories:     Maximum entries in vector store before pruning.
        context_top_k:    How many memories to inject into each LLM prompt.
    """

    def __init__(
        self,
        db_path: Path = Path("data/companion.db"),
        vector_db_path: Path = Path("data/chroma"),
        embedding_model: str = "all-MiniLM-L6-v2",
        max_memories: int = 1000,
        context_top_k: int = 5,
    ) -> None:
        self._db_path = db_path
        self._vector_db_path = vector_db_path
        self._embedding_model_name = embedding_model
        self._max_memories = max_memories
        self._top_k = context_top_k

        self._engine = None
        self._session_factory = None
        self._chroma_client = None
        self._collection = None
        self._embedder = None

        self._current_session_id: str = str(uuid.uuid4())

        logger.info(
            f"MemoryEngine: db={db_path} vector_db={vector_db_path} "
            f"top_k={context_top_k}"
        )

    # ── Initialization ───────────────────────────────────────

    async def initialize(self) -> None:
        """Load models and initialize databases. Call once at startup."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)

        # SQLite async engine
        db_url = f"sqlite+aiosqlite:///{self._db_path}"
        self._engine = create_async_engine(db_url, echo=False)
        self._session_factory = async_sessionmaker(
            self._engine, expire_on_commit=False
        )

        # Create tables
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("MemoryEngine: SQLite initialized")

        # ChromaDB
        if CHROMA_AVAILABLE:
            self._vector_db_path.mkdir(parents=True, exist_ok=True)
            self._chroma_client = chromadb.PersistentClient(
                path=str(self._vector_db_path),
                settings=ChromaSettings(anonymized_telemetry=False),
            )
            self._collection = self._chroma_client.get_or_create_collection(
                name="memories",
                metadata={"hnsw:space": "cosine"},
            )
            logger.info(
                f"MemoryEngine: ChromaDB initialized "
                f"({self._collection.count()} memories)"
            )
        else:
            logger.warning("MemoryEngine: ChromaDB not available — vector search disabled")

        # Sentence transformer
        if ST_AVAILABLE:
            logger.info(f"MemoryEngine: loading embedder {self._embedding_model_name}...")
            self._embedder = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: SentenceTransformer(self._embedding_model_name),
            )
            logger.info("MemoryEngine: embedder loaded")
        else:
            logger.warning("MemoryEngine: sentence-transformers not installed — semantic search disabled")

    async def close(self) -> None:
        if self._engine:
            await self._engine.dispose()

    # ── Conversation persistence ─────────────────────────────

    async def save_turn(self, role: str, content: str) -> None:
        """Persist a conversation turn to SQLite."""
        async with self._session_factory() as session:
            turn = Conversation(
                session_id=self._current_session_id,
                role=role,
                content=content,
                timestamp=time.time(),
            )
            session.add(turn)
            await session.commit()

    async def get_recent_turns(
        self, session_id: Optional[str] = None, limit: int = 50
    ) -> List[Dict]:
        """Retrieve recent conversation turns."""
        sid = session_id or self._current_session_id
        async with self._session_factory() as session:
            result = await session.execute(
                select(Conversation)
                .where(Conversation.session_id == sid)
                .order_by(Conversation.timestamp.desc())
                .limit(limit)
            )
            rows = result.scalars().all()
            return [
                {"role": r.role, "content": r.content, "timestamp": r.timestamp}
                for r in reversed(rows)
            ]

    # ── Long-term memory ─────────────────────────────────────

    async def store_memory(
        self,
        content: str,
        memory_type: str = "fact",
        importance: float = 0.5,
        source: str = "conversation",
    ) -> str:
        """
        Store a memory in both SQLite and ChromaDB vector store.
        Returns the memory ID.
        """
        memory_id = str(uuid.uuid4())

        # SQLite
        async with self._session_factory() as session:
            memory = Memory(
                memory_type=memory_type,
                content=content,
                source=source,
                importance=importance,
                embedding_id=memory_id,
                timestamp=time.time(),
            )
            session.add(memory)
            await session.commit()

        # ChromaDB
        if self._collection and self._embedder:
            embedding = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._embedder.encode(content).tolist(),
            )
            self._collection.add(
                ids=[memory_id],
                documents=[content],
                embeddings=[embedding],
                metadatas=[{
                    "memory_type": memory_type,
                    "importance": importance,
                    "source": source,
                    "timestamp": time.time(),
                }],
            )
            logger.debug(f"MemoryEngine: stored memory [{memory_type}]: {content[:60]}")

            # Prune if over limit
            if self._collection.count() > self._max_memories:
                await self._prune_old_memories()

        return memory_id

    async def retrieve_relevant(self, query: str, top_k: int = None) -> List[MemoryEntry]:
        """
        Semantic search: find memories most relevant to the query.
        Falls back to recency-ordered SQLite if embedder unavailable.
        """
        k = top_k or self._top_k

        if self._collection and self._embedder:
            embedding = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._embedder.encode(query).tolist(),
            )
            results = self._collection.query(
                query_embeddings=[embedding],
                n_results=min(k, self._collection.count() or 1),
                include=["documents", "metadatas", "distances"],
            )

            entries = []
            for doc, meta, dist in zip(
                results["documents"][0],
                results["metadatas"][0],
                results["distances"][0],
            ):
                entries.append(MemoryEntry(
                    id=results["ids"][0][len(entries)],
                    content=doc,
                    memory_type=meta.get("memory_type", "unknown"),
                    importance=meta.get("importance", 0.5),
                    timestamp=meta.get("timestamp", 0.0),
                    relevance_score=1.0 - float(dist),  # cosine: 1-dist = similarity
                ))

            # Increment access count in SQLite
            for entry in entries:
                await self._bump_access(entry.id)

            return sorted(entries, key=lambda e: e.relevance_score, reverse=True)

        # Fallback: recent memories from SQLite
        async with self._session_factory() as session:
            result = await session.execute(
                select(Memory)
                .order_by(Memory.importance.desc(), Memory.timestamp.desc())
                .limit(k)
            )
            rows = result.scalars().all()
            return [
                MemoryEntry(
                    id=r.embedding_id or str(r.id),
                    content=r.content,
                    memory_type=r.memory_type,
                    importance=r.importance,
                    timestamp=r.timestamp,
                    relevance_score=r.importance,
                )
                for r in rows
            ]

    async def get_context_string(self, query: str) -> str:
        """
        Build a compact memory context string for LLM prompt injection.
        """
        memories = await self.retrieve_relevant(query)
        if not memories:
            return ""

        lines = ["[Memory context — relevant past information:]"]
        for m in memories:
            lines.append(f"- [{m.memory_type}] {m.content}")

        return "\n".join(lines)

    # ── Preferences ──────────────────────────────────────────

    async def set_preference(self, key: str, value: str) -> None:
        async with self._session_factory() as session:
            existing = await session.get(UserPreference, key)
            if existing:
                existing.value = value
            else:
                session.add(UserPreference(key=key, value=value))
            await session.commit()

    async def get_preference(self, key: str, default: str = "") -> str:
        async with self._session_factory() as session:
            pref = await session.get(UserPreference, key)
            return pref.value if pref else default

    # ── Session summarization ────────────────────────────────

    async def summarize_session(self, llm_engine) -> Optional[str]:
        """
        Ask the LLM to distill the current session into memorable facts.
        Stores the summary as a memory entry.
        """
        turns = await self.get_recent_turns(limit=30)
        if len(turns) < 4:
            return None

        turns_text = "\n".join(
            f"{t['role'].upper()}: {t['content'][:200]}" for t in turns
        )
        prompt = (
            f"Summarize the key facts, preferences, and important information "
            f"from this conversation in 3-5 bullet points. "
            f"Be specific and factual. No filler.\n\n{turns_text}"
        )

        try:
            summary = await llm_engine.generate_direct(prompt)
            await self.store_memory(
                content=summary,
                memory_type="summary",
                importance=0.7,
                source=f"session:{self._current_session_id}",
            )
            logger.info("MemoryEngine: session summarized and stored")
            return summary
        except Exception as e:
            logger.error(f"MemoryEngine: summarization failed: {e}")
            return None

    def new_session(self) -> str:
        """Start a new conversation session."""
        self._current_session_id = str(uuid.uuid4())
        logger.info(f"MemoryEngine: new session {self._current_session_id}")
        return self._current_session_id

    # ── Maintenance ──────────────────────────────────────────

    async def _prune_old_memories(self) -> None:
        """Remove low-importance, low-access memories to stay under max_memories."""
        if not self._collection:
            return

        # Get all memories from ChromaDB
        all_mems = self._collection.get(include=["metadatas"])
        if not all_mems["ids"]:
            return

        # Score: importance * 0.6 + recency * 0.3 + access_count * 0.1
        now = time.time()
        scored = []
        for mem_id, meta in zip(all_mems["ids"], all_mems["metadatas"]):
            age_days = (now - meta.get("timestamp", now)) / 86400
            recency_score = max(0, 1 - (age_days / 365))
            score = (
                meta.get("importance", 0.5) * 0.6
                + recency_score * 0.4
            )
            scored.append((score, mem_id))

        # Sort ascending (worst first) and delete bottom 10%
        scored.sort()
        to_delete_count = max(1, len(scored) // 10)
        to_delete_ids = [mid for _, mid in scored[:to_delete_count]]

        self._collection.delete(ids=to_delete_ids)
        logger.info(f"MemoryEngine: pruned {len(to_delete_ids)} old memories")

    async def _bump_access(self, embedding_id: str) -> None:
        """Increment access_count for a memory in SQLite."""
        try:
            async with self._session_factory() as session:
                await session.execute(
                    update(Memory)
                    .where(Memory.embedding_id == embedding_id)
                    .values(
                        access_count=Memory.access_count + 1,
                        last_accessed=time.time(),
                    )
                )
                await session.commit()
        except Exception:
            pass

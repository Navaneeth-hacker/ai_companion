"""
main.py
=======
AI Companion — Production Entry Point

Starts three concurrent services:
  1. FullPipeline   — All 5 phases (wake word → STT → LLM → TTS,
                      vision, automation, memory, learning)
  2. FastAPI server — REST gateway + WebSocket event stream
  3. System tray    — Windows tray icon + menu (daemon thread)

Usage:
  python main.py                         # Full production mode
  python main.py --debug                 # Debug logging
  python main.py --no-wakeword           # Disable wake word (API-only mode)
  python main.py --no-vision             # Disable vision engine
  python main.py --no-tray               # Disable system tray
  python main.py --stt-model small       # Override STT model size
  python main.py --llm-model qwen2.5:14b # Override LLM model
  python main.py --port 8765             # Override API port
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

import uvicorn
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from config.config import load_settings
from core.logging_setup import setup_logging
from core.pipeline.full_pipeline import FullPipeline
from api.gateway import app as fastapi_app, set_pipeline

console = Console()


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="AI Companion")
    p.add_argument("--debug",          action="store_true",  help="Enable debug logging")
    p.add_argument("--no-wakeword",    action="store_true",  help="Disable wake word detection")
    p.add_argument("--no-vision",      action="store_true",  help="Disable vision engine")
    p.add_argument("--no-tray",        action="store_true",  help="Disable system tray")
    p.add_argument("--stt-model",      type=str,             help="Whisper model size")
    p.add_argument("--llm-model",      type=str,             help="Ollama model tag")
    p.add_argument("--port",           type=int,             help="API gateway port")
    p.add_argument("--personality",    type=str,             help="Personality style")
    return p.parse_args()


def _print_banner(settings) -> None:
    t = Text()
    t.append("AI Companion", style="bold white")
    t.append(f"  v{settings.app.version}\n\n", style="dim")
    pairs = [
        ("Personality",  settings.personality.name),
        ("Style",        settings.personality.style),
        ("LLM",          settings.llm.model),
        ("STT",          f"Whisper {settings.stt.model}"),
        ("TTS",          settings.tts.engine),
        ("Wake word",    " / ".join(settings.wake_word.wake_words)
                         if settings.wake_word.enabled else "disabled"),
        ("API",          f"http://{settings.api.host}:{settings.api.port}/docs"),
        ("Dashboard",    "http://127.0.0.1:3000  (npm run dev in dashboard/)"),
    ]
    for label, value in pairs:
        t.append(f"{label:<14}", style="dim")
        t.append(f"{value}\n", style="cyan")
    console.print(Panel(t, title="[bold green]Starting[/]", border_style="green"))


async def main() -> None:
    args = parse_args()
    settings = load_settings()

    # Apply CLI overrides
    if args.debug:
        settings.app.debug = True
        settings.app.log_level = "DEBUG"
    if args.no_wakeword:
        settings.wake_word.enabled = False
    if args.stt_model:
        settings.stt.model = args.stt_model
    if args.llm_model:
        settings.llm.model = args.llm_model
    if args.port:
        settings.api.port = args.port
    if args.personality:
        settings.personality.style = args.personality

    settings.ensure_dirs()
    setup_logging(
        log_dir=settings.app.log_dir,
        log_level=settings.app.log_level,
        debug=settings.app.debug,
    )

    _print_banner(settings)

    # System tray (daemon thread — start before pipeline so icon appears early)
    if not args.no_tray:
        try:
            from scripts.system_tray import SystemTrayApp
            tray = SystemTrayApp(api_port=settings.api.port)
            tray.start()
        except Exception as e:
            console.print(f"[yellow]System tray unavailable: {e}[/]")

    # Pipeline
    pipeline = FullPipeline(settings)
    set_pipeline(pipeline)

    # Override vision if requested
    if args.no_vision:
        # Monkey-patch: skip vision start
        original_init = pipeline._initialize
        async def _init_no_vision(loop):
            await original_init(loop)
            if pipeline._vision:
                pipeline._vision.stop()
                pipeline._vision = None
        pipeline._initialize = _init_no_vision

    # Uvicorn config
    uvicorn_config = uvicorn.Config(
        app=fastapi_app,
        host=settings.api.host,
        port=settings.api.port,
        log_level="warning",
        loop="asyncio",
        access_log=False,
        ws_ping_interval=20,
        ws_ping_timeout=20,
    )
    server = uvicorn.Server(config=uvicorn_config)

    from loguru import logger
    logger.info(
        f"API gateway: http://{settings.api.host}:{settings.api.port}"
    )

    await asyncio.gather(
        pipeline.run(),
        server.serve(),
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted — shutting down.[/]")

"""
vision/vision_engine.py
=======================
Orchestrates all Phase 2 vision components:
  - ScreenCapture    → continuous frame acquisition
  - OCREngine        → text extraction from frames
  - WindowDetector   → active process / window classification
  - ProductivityAnalyzer → distraction/productivity scoring

Architecture:
  - Runs on a configurable poll cycle (default: every 2 seconds).
  - Enriches the LLM context with current screen state.
  - Publishes ProductivityEvent when intervention is needed.
  - Exposes get_context_for_llm() used by the pipeline to prepend
    screen awareness to every LLM prompt.

Vision → LLM injection strategy:
  We do NOT send raw screenshots to the text LLM (Qwen2.5 7B).
  Instead we:
    1. Run OCR to extract visible text (window title, content, taskbar).
    2. Classify the active window.
    3. Build a compact text summary.
    4. Prepend this to the system prompt for each LLM call.

  For multimodal queries ("what do you see on my screen?"), we invoke
  the Qwen2-VL vision model separately (Phase 6).
"""

from __future__ import annotations

import asyncio
import threading
import time
from dataclasses import dataclass
from typing import Optional

from loguru import logger

from core.events.event_bus import (
    EventBus,
    SystemStatusEvent,
    LLMStreamChunkEvent,
)
from vision.screen_capture import ScreenCapture, ScreenFrame
from vision.ocr_engine import OCREngine, OCRPage
from vision.window_detector import WindowDetector, WindowSnapshot
from vision.productivity_analyzer import ProductivityAnalyzer, ProductivityReport


@dataclass
class VisionContext:
    """Snapshot of everything the vision engine knows right now."""
    window_snapshot: Optional[WindowSnapshot]
    ocr_page: Optional[OCRPage]
    productivity_report: Optional[ProductivityReport]
    timestamp: float

    def to_llm_context(self) -> str:
        """
        Compact text string injected into every LLM system prompt.
        Kept short to avoid wasting LLM context budget.
        """
        parts = []

        if self.window_snapshot and self.window_snapshot.active_window:
            win = self.window_snapshot.active_window
            parts.append(
                f"[Screen] Active app: {win.process_name} | "
                f"Window: \"{win.title[:60]}\" | "
                f"Category: {win.category}"
            )
            if win.is_distraction:
                parts.append("[Screen] User is currently distracted.")

        if self.ocr_page and self.ocr_page.has_text:
            text_preview = self.ocr_page.full_text[:200].replace("\n", " ")
            parts.append(f"[Screen text] {text_preview}")

        if self.productivity_report:
            r = self.productivity_report
            parts.append(
                f"[Productivity] Score: {r.score}/100 | "
                f"Streak: {r.current_streak_min}m {r.current_streak_type}"
            )

        return "\n".join(parts) if parts else ""


class VisionEngine:
    """
    Phase 2 vision orchestrator.

    Args:
        event_bus:          Shared EventBus.
        event_loop:         Main asyncio loop (for thread-safe publishing).
        poll_interval:      Seconds between analysis cycles.
        ocr_enabled:        Enable OCR text extraction.
        productivity_enabled: Enable productivity tracking.
        capture_interval:   Screen capture interval (can be faster than poll).
    """

    def __init__(
        self,
        event_bus: EventBus,
        event_loop: asyncio.AbstractEventLoop,
        poll_interval: float = 2.0,
        ocr_enabled: bool = True,
        productivity_enabled: bool = True,
        capture_interval: float = 0.5,
    ) -> None:
        self._bus = event_bus
        self._loop = event_loop
        self._poll_interval = poll_interval
        self._ocr_enabled = ocr_enabled
        self._productivity_enabled = productivity_enabled

        # Sub-components
        self._capture = ScreenCapture(
            event_loop=event_loop,
            capture_interval=capture_interval,
            change_threshold=5.0,
            resize_to=(1280, 720),
        )
        self._ocr = OCREngine(use_gpu=True, min_confidence=0.5) if ocr_enabled else None
        self._window_detector = WindowDetector()
        self._productivity = ProductivityAnalyzer() if productivity_enabled else None

        # Current context (updated by analysis loop)
        self._current_context: Optional[VisionContext] = None
        self._context_lock = threading.Lock()

        # Analysis thread
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        logger.info(
            f"VisionEngine: poll={poll_interval}s "
            f"ocr={ocr_enabled} productivity={productivity_enabled}"
        )

    # ── Public API ──────────────────────────────────────────

    def start(self) -> None:
        """Load models and start background analysis."""
        if self._ocr_enabled and self._ocr:
            self._ocr.load()

        self._capture.start()

        self._thread = threading.Thread(
            target=self._analysis_loop,
            name="vision-analysis-thread",
            daemon=True,
        )
        self._thread.start()
        logger.info("VisionEngine: started")

        asyncio.run_coroutine_threadsafe(
            self._bus.publish(SystemStatusEvent("vision", "ready")),
            self._loop,
        )

    def stop(self) -> None:
        """Stop all vision components."""
        self._stop_event.set()
        self._capture.stop()
        if self._thread:
            self._thread.join(timeout=5.0)
        logger.info("VisionEngine: stopped")

    def get_context(self) -> Optional[VisionContext]:
        """Thread-safe access to the latest vision context."""
        with self._context_lock:
            return self._current_context

    def get_llm_context_string(self) -> str:
        """Returns a compact string suitable for prepending to LLM prompts."""
        ctx = self.get_context()
        if ctx:
            return ctx.to_llm_context()
        return ""

    def get_productivity_report(self) -> Optional[ProductivityReport]:
        if self._productivity:
            return self._productivity.get_report()
        return None

    # ── Analysis loop ────────────────────────────────────────

    def _analysis_loop(self) -> None:
        """
        Background thread: periodically analyzes the latest screen frame.
        Runs at poll_interval (default 2s) — slower than capture (0.5s).
        """
        logger.debug("VisionEngine: analysis loop started")

        while not self._stop_event.is_set():
            t0 = time.perf_counter()

            try:
                self._run_analysis_cycle()
            except Exception as e:
                logger.error(f"VisionEngine: analysis cycle error: {e}", exc_info=True)

            elapsed = time.perf_counter() - t0
            sleep_time = max(0, self._poll_interval - elapsed)
            time.sleep(sleep_time)

        logger.debug("VisionEngine: analysis loop exited")

    def _run_analysis_cycle(self) -> None:
        """One analysis cycle: capture → OCR → window → productivity → context."""

        # 1. Get latest frame
        frame = self._capture.get_latest_frame()

        # 2. Window detection (fast — pure Win32 API)
        window_snapshot = self._window_detector.get_snapshot()

        # 3. OCR (optional — slower)
        ocr_page: Optional[OCRPage] = None
        if self._ocr_enabled and self._ocr and frame is not None:
            # Only OCR title bar area for speed; full OCR on demand
            ocr_page = self._ocr.read_window_titles(frame.image)

        # 4. Productivity analysis
        intervention: Optional[str] = None
        report: Optional[ProductivityReport] = None
        if self._productivity_enabled and self._productivity:
            intervention = self._productivity.ingest(window_snapshot)
            report = self._productivity.get_report()

        # 5. Update context
        ctx = VisionContext(
            window_snapshot=window_snapshot,
            ocr_page=ocr_page,
            productivity_report=report,
            timestamp=time.time(),
        )
        with self._context_lock:
            self._current_context = ctx

        # 6. Publish intervention if needed
        if intervention:
            logger.info(f"VisionEngine: intervention triggered: {intervention[:80]}")
            asyncio.run_coroutine_threadsafe(
                self._publish_intervention(intervention),
                self._loop,
            )

    async def _publish_intervention(self, message: str) -> None:
        """
        Route an intervention message through TTS via a direct stream chunk event.
        This bypasses the LLM for speed (the intervention message is pre-written).
        """
        await self._bus.publish(LLMStreamChunkEvent(chunk=message, sequence=0))

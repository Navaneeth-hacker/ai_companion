"""
vision/multimodal_engine.py
============================
Phase 6 — Multimodal vision understanding using Qwen2-VL.

When the user asks "what do you see on my screen?", "analyse this screen",
or describes something visual, this engine captures a screenshot and sends
it to the Qwen2-VL vision-language model for rich semantic understanding.

Two deployment paths:
  PATH A — Ollama (preferred if qwen2-vl is available in Ollama):
    ollama pull qwen2-vl:7b
    Uses the same Ollama REST API as the text LLM, just with image input.
    Much simpler, no separate model management.

  PATH B — Transformers (if Ollama qwen2-vl not available):
    Uses HuggingFace transformers to load Qwen2-VL locally.
    Requires more VRAM (~14GB for 7B in float16).
    Loaded on demand to avoid holding VRAM when not in use.

Query routing:
  The pipeline detects visual intent keywords in the user's transcription
  and routes to this engine rather than the text LLM.
  Visual intent keywords: ["see", "look", "screen", "showing", "display",
                           "window", "read this", "what's on", "analyse"]

Output: a natural language description of the screen, fed back into TTS.
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from pathlib import Path
from typing import Optional

import httpx
import numpy as np
from loguru import logger

# Screen capture — reuse existing engine
from vision.screen_capture import ScreenCapture, ScreenFrame

# Visual intent trigger keywords
VISUAL_INTENT_KEYWORDS = {
    "see", "look", "screen", "showing", "display", "window",
    "read this", "what's on", "analyse", "analyze", "describe",
    "what am i", "what do you", "what does", "what is on",
    "what's visible", "what can you", "current page",
}


def has_visual_intent(text: str) -> bool:
    """Return True if the user's text likely requests screen analysis."""
    text_lower = text.lower()
    return any(kw in text_lower for kw in VISUAL_INTENT_KEYWORDS)


class MultimodalEngine:
    """
    Vision-language model interface for screen understanding.

    Args:
        ollama_base_url:  Ollama API URL.
        vision_model:     Vision model tag in Ollama.
        screen_capture:   Shared ScreenCapture instance.
        prefer_ollama:    Try Ollama first before falling back to transformers.
        max_image_tokens: Cap on image token budget (controls quality vs. speed).
    """

    def __init__(
        self,
        ollama_base_url: str = "http://localhost:11434",
        vision_model: str = "qwen2-vl:7b",
        screen_capture: Optional[ScreenCapture] = None,
        prefer_ollama: bool = True,
        max_image_tokens: int = 1280,
    ) -> None:
        self._ollama_url = ollama_base_url.rstrip("/")
        self._vision_model = vision_model
        self._screen_capture = screen_capture
        self._prefer_ollama = prefer_ollama
        self._max_image_tokens = max_image_tokens

        self._client = httpx.AsyncClient(timeout=120.0)
        self._ollama_available = False
        self._transformers_model = None

        logger.info(
            f"MultimodalEngine: model={vision_model} "
            f"prefer_ollama={prefer_ollama}"
        )

    # ── Lifecycle ────────────────────────────────────────────

    async def initialize(self) -> None:
        """Check Ollama vision model availability."""
        try:
            resp = await self._client.get(f"{self._ollama_url}/api/tags", timeout=5.0)
            if resp.status_code == 200:
                models = [m["name"] for m in resp.json().get("models", [])]
                self._ollama_available = self._vision_model in models
                if not self._ollama_available:
                    logger.warning(
                        f"MultimodalEngine: '{self._vision_model}' not in Ollama. "
                        f"Run: ollama pull {self._vision_model}\n"
                        f"Available: {models}"
                    )
                else:
                    logger.info(f"MultimodalEngine: Ollama vision model ready")
        except httpx.ConnectError:
            logger.warning("MultimodalEngine: Ollama not reachable")

    async def close(self) -> None:
        await self._client.aclose()

    # ── Main API ─────────────────────────────────────────────

    async def analyse_screen(
        self,
        user_query: str = "What do you see on the screen? Describe it concisely.",
        frame: Optional[ScreenFrame] = None,
    ) -> str:
        """
        Capture the current screen (or use provided frame) and ask the
        vision LLM to describe / analyse it.

        Returns natural language description suitable for TTS output.
        """
        # Get or capture frame
        if frame is None:
            if self._screen_capture:
                frame = self._screen_capture.capture_once()
            else:
                # Fallback: one-shot capture
                from vision.screen_capture import ScreenCapture as SC
                temp_cap = SC.__new__(SC)
                frame = temp_cap._capture_frame()

        if frame is None:
            return "I couldn't capture your screen. Make sure screen capture is enabled."

        # Encode frame as base64 JPEG
        image_b64 = ScreenCapture.frame_to_base64(frame)

        # Route to appropriate backend
        if self._prefer_ollama and self._ollama_available:
            return await self._query_ollama(user_query, image_b64)
        else:
            return await self._query_transformers(user_query, frame)

    async def answer_visual_question(self, question: str) -> str:
        """
        High-level entry point: capture screen and answer the user's
        visual question about it.
        """
        prompt = (
            f"The user is asking about what's on their screen: '{question}'. "
            "Describe what you see clearly and concisely. "
            "Focus on what's most relevant to their question. "
            "Be specific — mention app names, visible text, UI elements. "
            "Keep your answer under 3 sentences for voice output."
        )
        return await self.analyse_screen(user_query=prompt)

    # ── Ollama backend ───────────────────────────────────────

    async def _query_ollama(self, prompt: str, image_b64: str) -> str:
        """
        Send image + prompt to Ollama vision model.
        Uses /api/generate with images field (Ollama multimodal API).
        """
        payload = {
            "model": self._vision_model,
            "prompt": prompt,
            "images": [image_b64],
            "stream": False,
            "options": {
                "temperature": 0.3,    # Lower temp for factual description
                "num_predict": 300,    # Cap response length for TTS
            },
        }

        t0 = time.time()
        try:
            resp = await self._client.post(
                f"{self._ollama_url}/api/generate",
                json=payload,
                timeout=90.0,
            )
            resp.raise_for_status()
            data = resp.json()
            text = data.get("response", "").strip()
            elapsed = time.time() - t0
            logger.info(
                f"MultimodalEngine: Ollama response in {elapsed:.1f}s | "
                f"{len(text.split())} words"
            )
            return text or "I analysed your screen but couldn't generate a description."

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning(
                    f"MultimodalEngine: model {self._vision_model} not found. "
                    "Falling back to text-only description."
                )
                return await self._text_only_fallback(prompt)
            raise

    # ── Transformers backend ─────────────────────────────────

    async def _query_transformers(self, prompt: str, frame: ScreenFrame) -> str:
        """
        Load Qwen2-VL via HuggingFace transformers.
        Heavy — loads ~14GB VRAM for 7B. Unloads after each query.
        """
        try:
            return await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._transformers_inference(prompt, frame),
            )
        except ImportError:
            return (
                "Vision model not available. "
                "Install transformers: pip install transformers qwen-vl-utils. "
                "Or pull the Ollama model: ollama pull qwen2-vl:7b"
            )
        except Exception as e:
            logger.error(f"MultimodalEngine: transformers error: {e}")
            return f"Vision analysis failed: {e}"

    def _transformers_inference(self, prompt: str, frame: ScreenFrame) -> str:
        """Synchronous transformers inference (runs in executor)."""
        from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
        from PIL import Image
        import torch

        logger.info("MultimodalEngine: loading Qwen2-VL via transformers...")

        pil_image = ScreenCapture.frame_to_pil(frame)

        model = Qwen2VLForConditionalGeneration.from_pretrained(
            "Qwen/Qwen2-VL-7B-Instruct",
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto",
        )
        processor = AutoProcessor.from_pretrained("Qwen/Qwen2-VL-7B-Instruct")

        messages = [{
            "role": "user",
            "content": [
                {"type": "image", "image": pil_image},
                {"type": "text", "text": prompt},
            ],
        }]

        text_input = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = processor(
            text=[text_input], images=[pil_image],
            padding=True, return_tensors="pt"
        ).to(model.device)

        with torch.no_grad():
            output_ids = model.generate(**inputs, max_new_tokens=256)

        generated = output_ids[:, inputs.input_ids.shape[1]:]
        result = processor.batch_decode(
            generated, skip_special_tokens=True, clean_up_tokenization_spaces=True
        )[0]

        # Unload to free VRAM
        del model, processor
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return result.strip()

    async def _text_only_fallback(self, prompt: str) -> str:
        """If vision model unavailable, return an honest message."""
        return (
            "I don't have the vision model loaded. "
            "To enable screen reading, run: ollama pull qwen2-vl:7b"
        )

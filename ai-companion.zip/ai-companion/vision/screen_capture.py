"""
vision/screen_capture.py
========================
High-performance screen capture using mss (multi-screen shot).

Why mss over PIL/screenshot?
  - mss uses Windows GDI directly — no subprocess overhead.
  - Captures at 30+ fps on modern hardware.
  - Returns raw BGRA numpy arrays, zero-copy into OpenCV/Pillow.

Architecture:
  - Runs in a dedicated background thread.
  - Posts ScreenFrameEvent to EventBus at configurable interval.
  - Maintains a rolling 1-frame cache (latest_frame) for on-demand access.
  - Supports full-screen and region capture.
  - Change detection: only posts events when screen content changes
    above a configurable threshold (avoids flooding downstream when idle).
"""

from __future__ import annotations

import asyncio
import threading
import time
from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np
from loguru import logger

try:
    import mss
    import mss.tools
    MSS_AVAILABLE = True
except ImportError:
    MSS_AVAILABLE = False

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


@dataclass
class ScreenFrame:
    """A captured screen frame with metadata."""
    image: np.ndarray          # BGR uint8 numpy array
    timestamp: float
    width: int
    height: int
    monitor_index: int = 1     # 1 = primary monitor


class ScreenCapture:
    """
    Continuous screen capture engine.

    Args:
        event_loop:         Main asyncio loop for thread-safe event publishing.
        capture_interval:   Seconds between captures (0.5 = 2fps, 0.1 = 10fps).
        monitor_index:      Monitor to capture (1 = primary, 0 = all monitors).
        change_threshold:   Minimum mean pixel change to publish event (0–255).
                            Set to 0 to publish every frame regardless.
        resize_to:          Downsample to (width, height) before analysis.
                            None = no resize (original resolution).
                            Recommended: (1280, 720) for LLM vision input.
    """

    def __init__(
        self,
        event_loop: asyncio.AbstractEventLoop,
        capture_interval: float = 0.5,
        monitor_index: int = 1,
        change_threshold: float = 5.0,
        resize_to: Optional[Tuple[int, int]] = (1280, 720),
    ) -> None:
        if not MSS_AVAILABLE:
            raise ImportError("mss not installed. Run: pip install mss")

        self._loop = event_loop
        self._interval = capture_interval
        self._monitor_index = monitor_index
        self._change_threshold = change_threshold
        self._resize_to = resize_to

        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._latest_frame: Optional[ScreenFrame] = None
        self._prev_gray: Optional[np.ndarray] = None
        self._frame_lock = threading.Lock()

        # Callbacks registered by other components
        self._on_frame_callbacks = []

        logger.info(
            f"ScreenCapture: interval={capture_interval}s "
            f"monitor={monitor_index} resize={resize_to}"
        )

    # ── Public API ──────────────────────────────────────────

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._capture_loop,
            name="screen-capture-thread",
            daemon=True,
        )
        self._thread.start()
        logger.info("ScreenCapture: started")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3.0)
        logger.info("ScreenCapture: stopped")

    def get_latest_frame(self) -> Optional[ScreenFrame]:
        """Thread-safe access to the most recent captured frame."""
        with self._frame_lock:
            return self._latest_frame

    def capture_once(self) -> Optional[ScreenFrame]:
        """Capture a single frame synchronously (blocking call)."""
        return self._capture_frame()

    def register_callback(self, fn) -> None:
        """Register a callback: fn(frame: ScreenFrame) — called in capture thread."""
        self._on_frame_callbacks.append(fn)

    # ── Capture loop ─────────────────────────────────────────

    def _capture_loop(self) -> None:
        logger.debug("ScreenCapture: capture loop started")
        while not self._stop_event.is_set():
            t0 = time.perf_counter()

            frame = self._capture_frame()
            if frame is not None:
                changed = self._has_changed(frame)
                if changed:
                    with self._frame_lock:
                        self._latest_frame = frame

                    for cb in self._on_frame_callbacks:
                        try:
                            cb(frame)
                        except Exception as e:
                            logger.warning(f"ScreenCapture: callback error: {e}")

            # Sleep for the remainder of the interval
            elapsed = time.perf_counter() - t0
            sleep_time = max(0, self._interval - elapsed)
            time.sleep(sleep_time)

        logger.debug("ScreenCapture: capture loop exited")

    def _capture_frame(self) -> Optional[ScreenFrame]:
        """Capture one frame using mss."""
        try:
            with mss.mss() as sct:
                monitor = sct.monitors[self._monitor_index]
                screenshot = sct.grab(monitor)

                # mss returns BGRA; convert to BGR for OpenCV
                bgra = np.frombuffer(screenshot.bgra, dtype=np.uint8)
                bgra = bgra.reshape((screenshot.height, screenshot.width, 4))
                bgr = cv2.cvtColor(bgra, cv2.COLOR_BGRA2BGR)

                # Resize if configured
                if self._resize_to:
                    bgr = cv2.resize(bgr, self._resize_to, interpolation=cv2.INTER_AREA)

                return ScreenFrame(
                    image=bgr,
                    timestamp=time.time(),
                    width=bgr.shape[1],
                    height=bgr.shape[0],
                    monitor_index=self._monitor_index,
                )
        except Exception as e:
            logger.warning(f"ScreenCapture: capture error: {e}")
            return None

    def _has_changed(self, frame: ScreenFrame) -> bool:
        """Return True if this frame is sufficiently different from the previous."""
        if self._change_threshold == 0:
            return True

        gray = cv2.cvtColor(frame.image, cv2.COLOR_BGR2GRAY)

        if self._prev_gray is None:
            self._prev_gray = gray
            return True

        # Mean absolute difference
        diff = cv2.absdiff(gray, self._prev_gray)
        mean_diff = float(diff.mean())
        self._prev_gray = gray

        return mean_diff >= self._change_threshold

    # ── Utility methods ──────────────────────────────────────

    @staticmethod
    def frame_to_pil(frame: ScreenFrame):
        """Convert a ScreenFrame to a PIL Image (for Piper VL / EasyOCR)."""
        if not PIL_AVAILABLE:
            raise ImportError("Pillow not installed. Run: pip install Pillow")
        rgb = cv2.cvtColor(frame.image, cv2.COLOR_BGR2RGB)
        return Image.fromarray(rgb)

    @staticmethod
    def frame_to_base64(frame: ScreenFrame) -> str:
        """Encode frame as base64 JPEG string (for vision LLM API calls)."""
        import base64
        _, buf = cv2.imencode(".jpg", frame.image, [cv2.IMWRITE_JPEG_QUALITY, 85])
        return base64.b64encode(buf.tobytes()).decode("utf-8")

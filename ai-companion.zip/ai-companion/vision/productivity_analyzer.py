"""
vision/productivity_analyzer.py
================================
Analyzes window activity and screen content to score productivity
and trigger proactive interventions.

Tracks:
  - Time spent per category (coding, browsing, social, gaming...)
  - Distraction streaks (how long on YouTube without returning to work)
  - Productivity score (rolling 30-min window)
  - Context switches per hour (fragmented focus indicator)
  - Work session detection (30+ min on productive apps)

Intervention triggers:
  - Distraction > N minutes → LLM generates a focus message
  - Context switches > threshold → fragmentation warning
  - Long idle period → check-in prompt
  - Long work sprint → break suggestion

Designed as a pure analysis layer — no UI or audio output directly.
Publishes ProductivityEvent to EventBus; the pipeline decides what to do.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

from loguru import logger

from vision.window_detector import WindowInfo, WindowSnapshot


@dataclass
class ActivitySample:
    timestamp: float
    category: str
    process_name: str
    window_title: str
    is_distraction: bool
    is_productive: bool


@dataclass
class ProductivityReport:
    """Generated on demand or periodically."""
    score: float                        # 0–100; higher = more productive
    session_duration_min: float
    productive_pct: float
    distraction_pct: float
    current_streak_min: float           # Current unbroken streak (good or bad)
    current_streak_type: str            # "productive" | "distraction" | "idle"
    category_breakdown: Dict[str, float]  # category → minutes
    context_switches_per_hour: float
    recommendations: List[str]
    timestamp: float = field(default_factory=time.time)

    @property
    def needs_intervention(self) -> bool:
        return (
            (self.current_streak_type == "distraction" and self.current_streak_min >= 5)
            or self.context_switches_per_hour > 20
            or self.score < 30
        )


class ProductivityAnalyzer:
    """
    Real-time productivity analysis from window activity.

    Args:
        sample_window_minutes:  Rolling window size for scoring.
        distraction_threshold:  Minutes before triggering distraction alert.
        work_sprint_threshold:  Minutes of focus before suggesting a break.
        context_switch_warn:    Context switches/hour before fragmentation warning.
    """

    def __init__(
        self,
        sample_window_minutes: int = 30,
        distraction_threshold: float = 5.0,
        work_sprint_threshold: float = 90.0,
        context_switch_warn: int = 20,
    ) -> None:
        self._window_sec = sample_window_minutes * 60
        self._distraction_threshold = distraction_threshold * 60  # → seconds
        self._sprint_threshold = work_sprint_threshold * 60
        self._cs_warn = context_switch_warn

        # Rolling sample buffer (deque with maxlen keeps memory bounded)
        self._samples: Deque[ActivitySample] = deque(maxlen=10_000)

        # State tracking
        self._last_process: Optional[str] = None
        self._streak_start: float = time.time()
        self._streak_type: str = "idle"
        self._context_switch_times: Deque[float] = deque(maxlen=200)
        self._session_start: float = time.time()

        # Intervention tracking (prevent spam)
        self._last_distraction_alert: float = 0.0
        self._last_break_suggestion: float = 0.0
        self._distraction_alert_cooldown = 300.0    # 5 min between alerts
        self._break_suggestion_cooldown = 1800.0    # 30 min between break suggestions

        logger.info(
            f"ProductivityAnalyzer: window={sample_window_minutes}m "
            f"distraction_threshold={distraction_threshold}m"
        )

    # ── Public API ──────────────────────────────────────────

    def ingest(self, snapshot: WindowSnapshot) -> Optional[str]:
        """
        Process a new window snapshot.
        Returns an intervention message string if one should be delivered,
        or None if no intervention is needed.
        """
        now = time.time()
        win = snapshot.active_window

        if win is None:
            return None

        sample = ActivitySample(
            timestamp=now,
            category=win.category,
            process_name=win.process_name,
            window_title=win.title,
            is_distraction=win.is_distraction,
            is_productive=win.is_productive,
        )
        self._samples.append(sample)

        # Track context switches
        if self._last_process and win.process_name != self._last_process:
            self._context_switch_times.append(now)
        self._last_process = win.process_name

        # Update streak
        new_streak_type = (
            "productive" if win.is_productive
            else "distraction" if win.is_distraction
            else "neutral"
        )
        if new_streak_type != self._streak_type:
            self._streak_start = now
            self._streak_type = new_streak_type

        streak_duration = now - self._streak_start

        # Check for interventions
        return self._check_interventions(streak_duration, now)

    def get_report(self) -> ProductivityReport:
        """Generate a full productivity report from the rolling window."""
        now = time.time()
        cutoff = now - self._window_sec

        # Filter to window
        recent = [s for s in self._samples if s.timestamp >= cutoff]

        if not recent:
            return ProductivityReport(
                score=50.0, session_duration_min=0,
                productive_pct=0, distraction_pct=0,
                current_streak_min=0, current_streak_type="idle",
                category_breakdown={}, context_switches_per_hour=0,
                recommendations=["Start working to begin tracking."],
            )

        total = len(recent)
        productive_count = sum(1 for s in recent if s.is_productive)
        distraction_count = sum(1 for s in recent if s.is_distraction)

        productive_pct = (productive_count / total) * 100
        distraction_pct = (distraction_count / total) * 100

        # Score: weight productive time heavily, penalize distraction
        score = min(100, max(0,
            productive_pct * 0.8
            - distraction_pct * 0.5
            + (100 - distraction_pct) * 0.2
        ))

        # Category breakdown (minutes)
        cat_counts: Dict[str, int] = {}
        for s in recent:
            cat_counts[s.category] = cat_counts.get(s.category, 0) + 1
        # Each sample ≈ 0.5s (capture interval); convert counts to minutes
        sample_interval = 0.5
        cat_minutes = {k: (v * sample_interval) / 60 for k, v in cat_counts.items()}

        # Context switches per hour
        hour_ago = now - 3600
        recent_switches = [t for t in self._context_switch_times if t >= hour_ago]
        cs_per_hour = len(recent_switches)

        session_min = (now - self._session_start) / 60
        streak_min = (now - self._streak_start) / 60

        recommendations = self._generate_recommendations(
            score, productive_pct, distraction_pct, cs_per_hour, streak_min
        )

        return ProductivityReport(
            score=round(score, 1),
            session_duration_min=round(session_min, 1),
            productive_pct=round(productive_pct, 1),
            distraction_pct=round(distraction_pct, 1),
            current_streak_min=round(streak_min, 1),
            current_streak_type=self._streak_type,
            category_breakdown=cat_minutes,
            context_switches_per_hour=cs_per_hour,
            recommendations=recommendations,
        )

    def get_context_summary(self) -> str:
        """
        Brief text summary of current activity for LLM context injection.
        """
        if not self._samples:
            return "No activity recorded yet."

        latest = self._samples[-1]
        report = self.get_report()
        streak_min = round((time.time() - self._streak_start) / 60, 1)

        return (
            f"User is currently on: {latest.process_name} ({latest.window_title[:50]}). "
            f"Category: {latest.category}. "
            f"{'Currently distracted.' if latest.is_distraction else 'Working productively.' if latest.is_productive else 'Neutral activity.'} "
            f"Productivity score: {report.score}/100. "
            f"Current streak: {streak_min}m of {self._streak_type}. "
            f"Context switches/hour: {report.context_switches_per_hour}."
        )

    # ── Intervention logic ───────────────────────────────────

    def _check_interventions(self, streak_duration: float, now: float) -> Optional[str]:
        """Return an intervention message if threshold is crossed."""

        # Distraction alert
        if (
            self._streak_type == "distraction"
            and streak_duration >= self._distraction_threshold
            and now - self._last_distraction_alert >= self._distraction_alert_cooldown
        ):
            self._last_distraction_alert = now
            mins = round(streak_duration / 60, 1)
            latest = self._samples[-1] if self._samples else None
            app = latest.process_name if latest else "that app"
            return (
                f"You've been on {app} for {mins} minutes. "
                f"That's a distraction. Get back to work."
            )

        # Break suggestion after long sprint
        if (
            self._streak_type == "productive"
            and streak_duration >= self._sprint_threshold
            and now - self._last_break_suggestion >= self._break_suggestion_cooldown
        ):
            self._last_break_suggestion = now
            hours = round(streak_duration / 3600, 1)
            return (
                f"You've been heads-down for {hours} hours straight. "
                f"Take a 10-minute break. Your focus will thank you."
            )

        return None

    @staticmethod
    def _generate_recommendations(
        score: float,
        productive_pct: float,
        distraction_pct: float,
        cs_per_hour: int,
        streak_min: float,
    ) -> List[str]:
        recs = []

        if distraction_pct > 30:
            recs.append(
                f"Distraction at {distraction_pct:.0f}% — "
                "try closing social media tabs before starting work."
            )
        if cs_per_hour > 20:
            recs.append(
                f"{cs_per_hour} context switches/hour is too high. "
                "Work in 25-minute focused blocks."
            )
        if productive_pct > 70 and streak_min > 90:
            recs.append("Great focus session. Consider a short break.")
        if score < 40:
            recs.append(
                "Productivity is low. "
                "Close distractions and set a specific task goal."
            )

        return recs or ["Keep it up."]

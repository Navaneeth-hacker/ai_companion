"""
vision/window_detector.py
==========================
Active window and process detection using Windows API.

Detects:
  - Currently focused window title and process name
  - All visible window titles + positions
  - Process category (browser, IDE, game, social media, video, etc.)

Uses pywin32 (win32gui, win32process) for direct Windows API access.
Falls back to psutil for process info on non-Windows systems.

Productivity categories:
  We classify each active application into a productivity bucket.
  This feeds the ProductivityAnalyzer in Phase 2.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from loguru import logger

# Windows-specific imports with graceful fallback
try:
    import win32gui
    import win32process
    import win32con
    import psutil
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
    try:
        import psutil
        PSUTIL_AVAILABLE = True
    except ImportError:
        PSUTIL_AVAILABLE = False


# ── Productivity classification rules ───────────────────────

CATEGORY_RULES: Dict[str, List[str]] = {
    # Process name patterns → category
    "coding": [
        r"code\.exe", r"cursor\.exe", r"pycharm", r"idea", r"clion",
        r"webstorm", r"rider", r"eclipse", r"netbeans", r"vim", r"nvim",
        r"sublime_text", r"atom", r"notepad\+\+",
    ],
    "browser": [
        r"chrome\.exe", r"firefox\.exe", r"msedge\.exe",
        r"opera\.exe", r"brave\.exe", r"vivaldi\.exe",
    ],
    "document": [
        r"winword\.exe", r"excel\.exe", r"powerpnt\.exe",
        r"onenote\.exe", r"acrobat\.exe", r"reader_sl\.exe",
        r"notepad\.exe", r"wordpad\.exe",
    ],
    "terminal": [
        r"windowsterminal\.exe", r"cmd\.exe", r"powershell\.exe",
        r"wt\.exe", r"conhost\.exe", r"wezterm\.exe",
    ],
    "communication": [
        r"slack\.exe", r"teams\.exe", r"discord\.exe",
        r"zoom\.exe", r"outlook\.exe", r"thunderbird\.exe",
        r"telegram\.exe", r"whatsapp\.exe",
    ],
    "video_streaming": [
        r"vlc\.exe", r"mpv\.exe", r"mpc-hc\.exe", r"mpc-be\.exe",
        r"wmplayer\.exe",
    ],
    "gaming": [
        r"steam\.exe", r"epicgameslauncher\.exe", r"battle\.net\.exe",
        r"gameoverlay", r"gog", r"itch\.exe",
    ],
    "social_media": [
        r"twitter", r"instagram", r"tiktok", r"reddit",
    ],
    "system": [
        r"explorer\.exe", r"taskmgr\.exe", r"regedit\.exe",
        r"mmc\.exe", r"services\.exe",
    ],
}

# Window title patterns that indicate distracting content IN browsers
DISTRACTION_TITLE_PATTERNS = [
    r"youtube\.com",
    r"twitch\.tv",
    r"netflix\.com",
    r"tiktok\.com",
    r"reddit\.com/r/",
    r"twitter\.com",
    r"instagram\.com",
    r"facebook\.com",
    r"- YouTube$",
    r"- Twitch$",
]

PRODUCTIVE_TITLE_PATTERNS = [
    r"github\.com",
    r"stackoverflow\.com",
    r"docs\.",
    r"localhost",
    r"127\.0\.0\.1",
    r"jupyter",
    r"colab",
    r"linear\.app",
    r"jira",
    r"confluence",
    r"notion\.so",
]


@dataclass
class WindowInfo:
    hwnd: int                    # Windows handle
    title: str
    process_name: str
    process_id: int
    category: str
    is_distraction: bool
    is_productive: bool
    timestamp: float = field(default_factory=time.time)

    def __str__(self) -> str:
        return (
            f"[{self.category}] {self.process_name} — {self.title[:60]}"
            + (" [DISTRACTION]" if self.is_distraction else "")
        )


@dataclass
class WindowSnapshot:
    active_window: Optional[WindowInfo]
    all_windows: List[WindowInfo]
    timestamp: float = field(default_factory=time.time)

    @property
    def active_category(self) -> str:
        if self.active_window:
            return self.active_window.category
        return "unknown"

    @property
    def is_distracted(self) -> bool:
        if self.active_window:
            return self.active_window.is_distraction
        return False


class WindowDetector:
    """
    Detects and classifies active Windows application windows.

    Usage:
        detector = WindowDetector()
        snapshot = detector.get_snapshot()
        print(snapshot.active_window)
    """

    def __init__(self) -> None:
        if not WIN32_AVAILABLE:
            logger.warning(
                "WindowDetector: pywin32 not available. "
                "Some features limited. Install: pip install pywin32"
            )
        logger.info("WindowDetector: initialized")

    def get_active_window(self) -> Optional[WindowInfo]:
        """Get info about the currently focused window."""
        if WIN32_AVAILABLE:
            return self._get_active_win32()
        return None

    def get_snapshot(self) -> WindowSnapshot:
        """Get a snapshot of the active window and all visible windows."""
        active = self.get_active_window()
        all_wins = self._enumerate_windows() if WIN32_AVAILABLE else []
        return WindowSnapshot(
            active_window=active,
            all_windows=all_wins,
        )

    # ── Windows API implementation ───────────────────────────

    def _get_active_win32(self) -> Optional[WindowInfo]:
        try:
            hwnd = win32gui.GetForegroundWindow()
            if not hwnd:
                return None
            return self._build_window_info(hwnd)
        except Exception as e:
            logger.warning(f"WindowDetector: get_active error: {e}")
            return None

    def _enumerate_windows(self) -> List[WindowInfo]:
        """Get all visible top-level windows."""
        results = []

        def callback(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if title:
                    info = self._build_window_info(hwnd)
                    if info:
                        results.append(info)

        try:
            win32gui.EnumWindows(callback, None)
        except Exception as e:
            logger.warning(f"WindowDetector: enumerate error: {e}")

        return results

    def _build_window_info(self, hwnd: int) -> Optional[WindowInfo]:
        try:
            title = win32gui.GetWindowText(hwnd)
            _, pid = win32process.GetWindowThreadProcessId(hwnd)

            try:
                proc = psutil.Process(pid)
                process_name = proc.name().lower()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                process_name = "unknown"

            category = self._classify_process(process_name, title)
            is_distraction = self._check_distraction(process_name, title, category)
            is_productive = self._check_productive(process_name, title, category)

            return WindowInfo(
                hwnd=hwnd,
                title=title,
                process_name=process_name,
                process_id=pid,
                category=category,
                is_distraction=is_distraction,
                is_productive=is_productive,
            )
        except Exception as e:
            logger.debug(f"WindowDetector: build_info error for hwnd {hwnd}: {e}")
            return None

    # ── Classification ───────────────────────────────────────

    @staticmethod
    def _classify_process(process_name: str, title: str) -> str:
        for category, patterns in CATEGORY_RULES.items():
            for pat in patterns:
                if re.search(pat, process_name, re.IGNORECASE):
                    return category
        return "other"

    @staticmethod
    def _check_distraction(process_name: str, title: str, category: str) -> bool:
        # Gaming and social are always distracting
        if category in ("gaming", "social_media", "video_streaming"):
            return True

        # Check window title against known distraction sites
        combined = f"{process_name} {title}".lower()
        for pat in DISTRACTION_TITLE_PATTERNS:
            if re.search(pat, combined, re.IGNORECASE):
                return True

        return False

    @staticmethod
    def _check_productive(process_name: str, title: str, category: str) -> bool:
        if category in ("coding", "document", "terminal"):
            return True

        combined = f"{process_name} {title}".lower()
        for pat in PRODUCTIVE_TITLE_PATTERNS:
            if re.search(pat, combined, re.IGNORECASE):
                return True

        return False

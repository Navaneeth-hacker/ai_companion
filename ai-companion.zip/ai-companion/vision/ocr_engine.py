"""
vision/ocr_engine.py
====================
OCR engine using EasyOCR for reading screen text.

Why EasyOCR over Tesseract?
  - Python-native, no system binary required.
  - GPU-accelerated with CUDA.
  - Better accuracy on low-contrast UI text.
  - Handles multiple languages natively.

Architecture:
  - EasyOCR model is loaded once and reused (expensive to load).
  - Exposes sync `read_frame()` for use from thread executors.
  - Result is a list of OCRResult with text, bounding box, confidence.
  - Region-of-interest (ROI) support: only OCR a portion of the screen.

Performance notes:
  - GPU: ~200ms per full 1080p frame
  - CPU: ~2–5s per full frame
  - With ROI (top 1/3 for window titles, taskbar): ~80ms GPU
  - Pre-filter with change detection to avoid redundant OCR calls.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import cv2
import numpy as np
from loguru import logger

try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False


@dataclass
class OCRResult:
    text: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    timestamp: float = field(default_factory=time.time)

    @property
    def is_reliable(self) -> bool:
        return self.confidence >= 0.7


@dataclass
class OCRPage:
    """All OCR results from a single frame."""
    results: List[OCRResult]
    full_text: str              # All reliable text concatenated
    timestamp: float
    duration_sec: float

    @property
    def has_text(self) -> bool:
        return bool(self.full_text.strip())


class OCREngine:
    """
    EasyOCR-based screen text reader.

    Args:
        languages:    List of language codes (e.g. ["en", "fr"]).
        use_gpu:      Use CUDA if available.
        min_confidence: Minimum confidence to include in results.
    """

    def __init__(
        self,
        languages: List[str] = None,
        use_gpu: bool = True,
        min_confidence: float = 0.5,
    ) -> None:
        if not EASYOCR_AVAILABLE:
            raise ImportError("easyocr not installed. Run: pip install easyocr")

        self._languages = languages or ["en"]
        self._use_gpu = use_gpu and self._cuda_available()
        self._min_confidence = min_confidence
        self._reader = None

        logger.info(
            f"OCREngine: languages={self._languages} "
            f"gpu={self._use_gpu} min_conf={min_confidence}"
        )

    # ── Public API ──────────────────────────────────────────

    def load(self) -> None:
        """Load EasyOCR models. Call once at startup (takes ~5s)."""
        logger.info("OCREngine: loading EasyOCR models...")
        t0 = time.time()
        self._reader = easyocr.Reader(
            self._languages,
            gpu=self._use_gpu,
            model_storage_directory="models/ocr",
            download_enabled=True,
            verbose=False,
        )
        elapsed = time.time() - t0
        logger.info(f"OCREngine: models loaded in {elapsed:.1f}s")

    def read_frame(
        self,
        image: np.ndarray,
        roi: Optional[Tuple[int, int, int, int]] = None,
    ) -> OCRPage:
        """
        Run OCR on a BGR image (numpy array).

        Args:
            image: BGR uint8 numpy array.
            roi:   Optional region of interest as (x1, y1, x2, y2).
                   Only this region is OCR'd (much faster for partial reads).

        Returns:
            OCRPage with all detected text and bounding boxes.
        """
        if self._reader is None:
            logger.error("OCREngine: not loaded — call load() first")
            return OCRPage([], "", time.time(), 0.0)

        t0 = time.perf_counter()

        # Crop to ROI if specified
        crop = image
        offset_x, offset_y = 0, 0
        if roi:
            x1, y1, x2, y2 = roi
            crop = image[y1:y2, x1:x2]
            offset_x, offset_y = x1, y1

        # Preprocess: grayscale + mild contrast enhancement
        crop = self._preprocess(crop)

        # Run EasyOCR
        try:
            raw_results = self._reader.readtext(
                crop,
                detail=1,
                paragraph=False,
                batch_size=1,
            )
        except Exception as e:
            logger.error(f"OCREngine: readtext error: {e}")
            return OCRPage([], "", time.time(), 0.0)

        # Parse results
        ocr_results = []
        for bbox_pts, text, conf in raw_results:
            if conf < self._min_confidence:
                continue
            # bbox_pts is [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
            xs = [int(p[0]) + offset_x for p in bbox_pts]
            ys = [int(p[1]) + offset_y for p in bbox_pts]
            ocr_results.append(OCRResult(
                text=text.strip(),
                confidence=float(conf),
                bbox=(min(xs), min(ys), max(xs), max(ys)),
            ))

        full_text = " ".join(
            r.text for r in ocr_results if r.is_reliable
        )

        elapsed = time.perf_counter() - t0
        return OCRPage(
            results=ocr_results,
            full_text=full_text,
            timestamp=time.time(),
            duration_sec=elapsed,
        )

    def read_window_titles(self, image: np.ndarray) -> OCRPage:
        """
        Optimized OCR for window titles and taskbar only.
        Uses top 5% + bottom 5% ROI to catch title bars and taskbar.
        """
        h, w = image.shape[:2]
        title_roi = (0, 0, w, int(h * 0.05))           # Top bar
        taskbar_roi = (0, int(h * 0.95), w, h)         # Bottom taskbar

        title_page = self.read_frame(image, roi=title_roi)
        taskbar_page = self.read_frame(image, roi=taskbar_roi)

        combined = title_page.results + taskbar_page.results
        full_text = " | ".join(
            r.text for r in combined if r.is_reliable
        )

        return OCRPage(
            results=combined,
            full_text=full_text,
            timestamp=time.time(),
            duration_sec=title_page.duration_sec + taskbar_page.duration_sec,
        )

    # ── Preprocessing ────────────────────────────────────────

    @staticmethod
    def _preprocess(image: np.ndarray) -> np.ndarray:
        """
        Mild preprocessing to improve OCR accuracy on UI text.
        - Convert to grayscale
        - CLAHE contrast enhancement
        - Return as RGB (EasyOCR expects RGB or grayscale)
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)
        return cv2.cvtColor(enhanced, cv2.COLOR_GRAY2RGB)

    @staticmethod
    def _cuda_available() -> bool:
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False

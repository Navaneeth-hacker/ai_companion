"""
config/config.py
================
Typed configuration model using Pydantic Settings v2.

Load order (later overrides earlier):
  1. config/settings.toml  (checked-in defaults)
  2. config/local.toml     (gitignored user overrides)
  3. Environment variables  AI_COMPANION_<SECTION>__<KEY>

Example env override:
  AI_COMPANION_LLM__MODEL=qwen2.5:14b
  AI_COMPANION_STT__MODEL=large-v3
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Literal, Optional

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# ── Project root (two levels up from this file) ─────────────────────────
ROOT = Path(__file__).resolve().parent.parent


# ─────────────────────────────────────────────
# Sub-models (one per [section] in TOML)
# ─────────────────────────────────────────────

class AppConfig(BaseSettings):
    name: str = "AI Companion"
    version: str = "0.1.0"
    debug: bool = False
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_dir: Path = ROOT / "logs"
    data_dir: Path = ROOT / "data"


class AudioConfig(BaseSettings):
    sample_rate: int = 16000
    channels: int = 1
    chunk_size: int = 1024
    format: str = "int16"
    input_device: int = -1
    output_device: int = -1
    vad_threshold: float = 0.5
    silence_timeout: float = 2.0
    max_record_sec: float = 30.0


class WakeWordConfig(BaseSettings):
    enabled: bool = True
    model_name: str = "hey_jarvis"
    wake_words: List[str] = ["wake up"]
    threshold: float = 0.5
    inference_rate_hz: int = 20
    vad_enabled: bool = True


class STTConfig(BaseSettings):
    model: str = "base"
    device: Literal["auto", "cpu", "cuda"] = "auto"
    compute_type: str = "auto"
    language: Optional[str] = "en"
    beam_size: int = 5
    vad_filter: bool = True
    word_timestamps: bool = False


class LLMConfig(BaseSettings):
    base_url: str = "http://localhost:11434"
    model: str = "qwen2.5:7b"
    temperature: float = 0.7
    top_p: float = 0.9
    max_tokens: int = 512
    stream: bool = True
    context_window: int = 4096
    request_timeout: float = 60.0
    system_prompt: str = (
        "You are a focused productivity AI companion. "
        "Be direct, concise, and speak naturally without markdown."
    )


class TTSConfig(BaseSettings):
    engine: Literal["piper", "system"] = "piper"
    model_path: Path = ROOT / "models" / "tts" / "en_US-lessac-medium.onnx"
    config_path: Path = ROOT / "models" / "tts" / "en_US-lessac-medium.onnx.json"
    speaking_rate: float = 1.0
    volume: float = 1.0
    sample_rate: int = 22050
    output_device: int = -1


class APIConfig(BaseSettings):
    host: str = "127.0.0.1"
    port: int = 8765
    reload: bool = False
    workers: int = 1


class SecurityConfig(BaseSettings):
    allowed_hosts: List[str] = ["127.0.0.1", "localhost"]
    api_key_required: bool = False
    enable_audit_log: bool = True
    audit_log_path: Path = ROOT / "logs" / "audit.jsonl"


class PersonalityConfig(BaseSettings):
    name: str = "Compass"
    style: str = "strict_coach"
    proactive: bool = True
    proactive_interval_sec: int = 300


# ─────────────────────────────────────────────
# Root settings — merges all sub-configs
# ─────────────────────────────────────────────

def _load_toml(path: Path) -> dict:
    """Load a TOML file. Returns empty dict if file not found."""
    if not path.exists():
        return {}
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_settings() -> "Settings":
    """
    Load and merge config from:
      1. config/settings.toml
      2. config/local.toml  (gitignored)
      3. Environment variables
    """
    base = _load_toml(ROOT / "config" / "settings.toml")
    local = _load_toml(ROOT / "config" / "local.toml")

    # Shallow merge: local overrides base per section
    merged: dict = {}
    for section in set(list(base.keys()) + list(local.keys())):
        merged[section] = {**base.get(section, {}), **local.get(section, {})}

    return Settings(
        app=AppConfig(**merged.get("app", {})),
        audio=AudioConfig(**merged.get("audio", {})),
        wake_word=WakeWordConfig(**merged.get("wake_word", {})),
        stt=STTConfig(**merged.get("stt", {})),
        llm=LLMConfig(**merged.get("llm", {})),
        tts=TTSConfig(**merged.get("tts", {})),
        api=APIConfig(**merged.get("api", {})),
        security=SecurityConfig(**merged.get("security", {})),
        personality=PersonalityConfig(**merged.get("personality", {})),
    )


class Settings(BaseSettings):
    """
    Top-level settings container.
    Env var format: AI_COMPANION_<SECTION>__<KEY>
    e.g.  AI_COMPANION_LLM__MODEL=qwen2.5:14b
    """
    model_config = SettingsConfigDict(
        env_prefix="AI_COMPANION_",
        env_nested_delimiter="__",
        case_sensitive=False,
        extra="ignore",
    )

    app: AppConfig = Field(default_factory=AppConfig)
    audio: AudioConfig = Field(default_factory=AudioConfig)
    wake_word: WakeWordConfig = Field(default_factory=WakeWordConfig)
    stt: STTConfig = Field(default_factory=STTConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    tts: TTSConfig = Field(default_factory=TTSConfig)
    api: APIConfig = Field(default_factory=APIConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    personality: PersonalityConfig = Field(default_factory=PersonalityConfig)

    def ensure_dirs(self) -> None:
        """Create required runtime directories."""
        for d in [self.app.log_dir, self.app.data_dir]:
            d.mkdir(parents=True, exist_ok=True)


# Module-level singleton — import this everywhere
settings = load_settings()

# installer/companion.spec
# ============================================================
# PyInstaller build specification for AI Companion
#
# Build command (from project root):
#   pyinstaller installer/companion.spec --clean
#
# Output:
#   dist/AICompanion/AICompanion.exe   (folder mode, faster startup)
#   dist/AICompanion/                  (all dependencies alongside)
#
# Notes:
#   - We use --onedir (not --onefile) for faster startup and easier updates.
#   - Models are NOT bundled — they are downloaded separately and live in
#     AppData\Local\AICompanion\models\ at runtime.
#   - The installer (Inno Setup) references this dist folder.
# ============================================================

import sys
import os
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_submodules

ROOT = Path(SPECPATH).parent

# ── Data files to bundle ─────────────────────────────────────
# Config, dashboard build, tray icon
datas = [
    (str(ROOT / "config" / "settings.toml"), "config"),
    (str(ROOT / "config" / "settings.toml"), "config"),
]

# Include dashboard build if it exists
dashboard_build = ROOT / "dashboard" / "build"
if dashboard_build.exists():
    datas.append((str(dashboard_build), "dashboard/build"))

# ── Hidden imports ───────────────────────────────────────────
# PyInstaller doesn't find all dynamic imports automatically
hiddenimports = [
    # Config
    "tomli", "pydantic_settings",
    # Audio
    "pyaudio", "sounddevice", "soundfile",
    # OWW
    "openwakeword", "openwakeword.model", "onnxruntime",
    # Whisper
    "faster_whisper", "ctranslate2",
    # Piper
    "piper", "piper.voice",
    # FastAPI
    "fastapi", "uvicorn", "uvicorn.logging", "uvicorn.loops",
    "uvicorn.loops.asyncio", "uvicorn.protocols",
    "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.websockets", "uvicorn.protocols.websockets.auto",
    "uvicorn.lifespan", "uvicorn.lifespan.on",
    # Database
    "sqlalchemy", "aiosqlite", "alembic",
    # Vector store
    "chromadb", "sentence_transformers",
    # Vision
    "mss", "cv2", "easyocr",
    # Windows
    "win32gui", "win32process", "win32con", "win32clipboard",
    "pystray", "pyautogui", "pywinauto",
    # Async
    "asyncio", "aiofiles",
    # Utils
    "loguru", "rich", "psutil", "click",
    # Collect all submodules of key packages
    *collect_submodules("chromadb"),
    *collect_submodules("sentence_transformers"),
    *collect_submodules("openwakeword"),
]

# ── Collect all data for packages that need it ───────────────
binaries = []
for pkg in ["easyocr", "openwakeword", "cv2"]:
    try:
        d, b, h = collect_all(pkg)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception:
        pass

# ── Analysis ─────────────────────────────────────────────────
a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[str(ROOT / "installer" / "hooks")],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "matplotlib", "tkinter", "wx", "gi",
        "IPython", "jupyter", "notebook",
        "test", "unittest",
    ],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=None)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AICompanion",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,           # UPX compression — reduces size ~30%
    console=False,      # No console window (tray app)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(ROOT / "installer" / "icon.ico") if (ROOT / "installer" / "icon.ico").exists() else None,
    version=str(ROOT / "installer" / "version.txt") if (ROOT / "installer" / "version.txt").exists() else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="AICompanion",
)

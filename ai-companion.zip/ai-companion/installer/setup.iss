; ============================================================
; AI Companion — Inno Setup Installer Script
; installer/setup.iss
;
; Prerequisites:
;   1. Build the PyInstaller executable first:
;      pyinstaller installer/companion.spec --clean
;   2. Install Inno Setup 6 from https://jrsoftware.org/isinfo.php
;   3. Compile this script:
;      iscc installer/setup.iss
;
; Output: installer/Output/AICompanion_Setup_1.0.0.exe
; ============================================================

#define AppName "AI Companion"
#define AppVersion "1.0.0"
#define AppPublisher "AI Companion Project"
#define AppURL "http://localhost:8765"
#define AppExeName "AICompanion.exe"
#define AppId "{{A7B3C9D2-E4F5-4A6B-8C7D-9E0F1A2B3C4D}"

[Setup]
AppId={#AppId}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}
AppUpdatesURL={#AppURL}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
AllowNoIcons=yes
LicenseFile=..\LICENSE
OutputDir=.\Output
OutputBaseFilename=AICompanion_Setup_{#AppVersion}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
DisableWelcomePage=no
DisableDirPage=no
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#AppExeName}
MinVersion=10.0.19041     ; Windows 10 20H1 minimum

; Installer icon
; SetupIconFile=icon.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";     Description: "{cm:CreateDesktopIcon}";     GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startupentry";    Description: "Start AI Companion when Windows starts"; GroupDescription: "Startup:"; Flags: unchecked
Name: "installdeps";     Description: "Download AI models after installation (requires internet)"; GroupDescription: "Setup:";

[Files]
; Main application (PyInstaller output)
Source: "..\dist\AICompanion\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

; Config files
Source: "..\config\settings.toml"; DestDir: "{app}\config"; Flags: ignoreversion onlyifdoesntexist

; Scripts
Source: "..\scripts\download_models.py"; DestDir: "{app}\scripts"; Flags: ignoreversion
Source: "..\scripts\setup_windows.py";   DestDir: "{app}\scripts"; Flags: ignoreversion

; Documentation
Source: "..\docs\*"; DestDir: "{app}\docs"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: DirExists('..\docs')

[Dirs]
Name: "{app}\logs";    Permissions: users-modify
Name: "{app}\data";    Permissions: users-modify
Name: "{app}\models";  Permissions: users-modify
Name: "{app}\models\stt"
Name: "{app}\models\tts"
Name: "{app}\config";  Permissions: users-modify

[Icons]
Name: "{autoprograms}\{#AppName}";          Filename: "{app}\{#AppExeName}"
Name: "{autoprograms}\{#AppName}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}";           Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Registry]
; Startup registry entry (only if task selected)
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; \
    ValueType: string; ValueName: "AICompanion"; \
    ValueData: """{app}\{#AppExeName}"""; \
    Flags: uninsdeletevalue; Tasks: startupentry

[Run]
; After install: run model downloader if selected
Filename: "{app}\{#AppExeName}"; \
    Parameters: "--help"; \
    Description: "Launch {#AppName}"; \
    Flags: nowait postinstall skipifsilent unchecked

; Model download
Filename: "{sys}\cmd.exe"; \
    Parameters: "/c cd ""{app}"" && python scripts\download_models.py --no-ollama"; \
    Description: "Download AI voice and speech models"; \
    Flags: nowait postinstall skipifsilent unchecked; \
    Tasks: installdeps

[UninstallRun]
; Stop service before uninstall
Filename: "{sys}\cmd.exe"; Parameters: "/c sc stop AICompanion"; Flags: runhidden

[Code]
// ── Pre-install checks ──────────────────────────────────────

function InitializeSetup(): Boolean;
var
  Version: TWindowsVersion;
begin
  GetWindowsVersionEx(Version);
  if Version.Major < 10 then
  begin
    MsgBox('AI Companion requires Windows 10 or later.', mbError, MB_OK);
    Result := False;
    Exit;
  end;
  Result := True;
end;

// Check if Ollama is installed and warn if not
procedure CurStepChanged(CurStep: TSetupStep);
var
  OllamaPath: String;
begin
  if CurStep = ssPostInstall then
  begin
    if not FileExists(ExpandConstant('{pf}\Ollama\ollama.exe')) then
    begin
      if MsgBox(
        'Ollama is not detected on this system.' + #13#10 +
        'AI Companion requires Ollama for local LLM inference.' + #13#10#13#10 +
        'Download Ollama from https://ollama.ai/download' + #13#10 +
        'After installing Ollama, run: ollama pull qwen2.5:7b' + #13#10#13#10 +
        'Open the Ollama download page now?',
        mbConfirmation, MB_YESNO) = IDYES then
      begin
        ShellExec('open', 'https://ollama.ai/download', '', '', SW_SHOW, ewNoWait, 0);
      end;
    end;
  end;
end;

// ── Uninstall cleanup ───────────────────────────────────────
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then
  begin
    // Ask user whether to keep data files
    if MsgBox(
      'Do you want to keep your AI Companion data (conversation history, memories, settings)?',
      mbConfirmation, MB_YESNO) = IDNO then
    begin
      DelTree(ExpandConstant('{app}\data'), True, True, True);
      DelTree(ExpandConstant('{app}\models'), True, True, True);
      DelTree(ExpandConstant('{app}\logs'), True, True, True);
    end;
  end;
end;
